#pragma once
#include "pch.h"
#include "Core.h"

// ===================== Store: persistence + data + session + economy =====================
public ref class Store abstract sealed
{
public:
    static Dictionary<String^, Object^>^ Data;   // root data object (same schema as web version)
    static String^ Me;                           // current logged-in username
    static String^ DataPath;
    static String^ SettingsPath;
    static Dictionary<String^, Object^>^ Settings;

    static void Load();
    static void Save();
    static String^ ExportJson();
    static bool ImportJson(String^ json, String^% err);
    static String^ DataDir();

    // ---------- collections (root children) ----------
    static Dictionary<String^, Object^>^ Users();
    static ArrayList^ Posts();
    static Dictionary<String^, Object^>^ Msgs();
    static Dictionary<String^, Object^>^ Rd();
    static Dictionary<String^, Object^>^ NotifsDict();
    static Dictionary<String^, Object^>^ Friends();
    static Dictionary<String^, Object^>^ EventCfg();
    static Dictionary<String^, Object^>^ McCfg();
    static Dictionary<String^, Object^>^ EvItems();

    // ---------- users / session ----------
    static Dictionary<String^, Object^>^ User(String^ u);
    static Dictionary<String^, Object^>^ MeObj();
    static bool Exists(String^ u);
    static int UserCount();
    static String^ Register(String^ u, String^ pw, String^ d, int av, String^% err);
    static String^ Login(String^ u, String^ pw, String^% err);
    static void SetSession(String^ u);
    static void ClearSession();
    static bool HasSession();
    static long long NextId();

    // ---------- profile ----------
    static bool ChangePw(String^ oldPw, String^ newPw, String^% err);
    static void SetCosmetic(String^ kind, int val);

    // ---------- posts ----------
    static Dictionary<String^, Object^>^ PostById(long long id);
    static Dictionary<String^, Object^>^ AddPost(String^ text, ArrayList^ imgs, bool ns, long long% newId);
    static bool DeletePost(long long id);
    static bool EditPost(long long id, String^ text);
    static Dictionary<String^, Object^>^ AddComment(long long pid, String^ text, long long% cid);
    static bool DeleteComment(long long pid, long long cid);
    static bool ToggleReact(long long pid, String^ emo);
    static bool ToggleSave(long long pid);
    static ArrayList^ SavedPosts();
    static bool IsMod(String^ u);

    // ---------- chat ----------
    static ArrayList^ GetConvs();
    static ArrayList^ GetMsgs(String^ other);
    static bool SendMsg(String^ to, String^ text);
    static int UnreadTotal();

    // ---------- notifications ----------
    static ArrayList^ Notifs();
    static void Notify(String^ u, Dictionary<String^, Object^>^ n);
    static void MarkNotifsSeen();
    static int UnreadNotifs();

    // ---------- friends ----------
    static bool SendReq(String^ to);
    static bool AcceptReq(String^ from);
    static bool RejectReq(String^ from);
    static bool RemoveFriend(String^ u);
    static String^ Rel(String^ a, String^ b);

    // ---------- economy (gems / plus / mooncake / draw) ----------
    static long long Gems(String^ u);
    static bool Owns(String^ u, String^ id);
    static void Grant(String^ u, String^ id);
    static bool BuyItem(String^ id, String^% err);
    static bool BuyMcItem(String^ id, String^% err);
    static bool McPick(int tier, String^ targetId, String^% err);
    static Dictionary<String^, Object^>^ DrawLucky(String^% err);
    static Dictionary<String^, Object^>^ TryQuest(String^ qk, int add);
    static long long McBalance(String^ u);
    static Dictionary<String^, Object^>^ McDailyLogin(String^% msg);
    static bool PlusOn(String^ u);
    static long long PlusEndMs(String^ u);
    static void GrantPlus(String^ u, int days);
    static bool UserPlus(Dictionary<String^, Object^>^ u);
    static int DisplayDec(Dictionary<String^, Object^>^ u);
    static int DisplayPf(Dictionary<String^, Object^>^ u);
    static bool EventEnabled();
    static bool DrawEnabled();
    static bool McEnabled();

    // ---------- admin ----------
    static void SetBanned(String^ u, bool b);
    static void AddGems(String^ u, long long amt);
    static void ToggleEvent(bool on);
    static void ToggleDraw(bool on);
    static void ToggleMc(bool on);
    static void SetItemOn(String^ id, bool on);
    static void SetItemCost(String^ id, int cost);
    static long long GiveMcDirect(String^ u, long long n, String^ key, int cap);

private:
    static void Seed();
    static void EnsureUser(Dictionary<String^, Object^>^ u);
    static void SaveSettings();
};
