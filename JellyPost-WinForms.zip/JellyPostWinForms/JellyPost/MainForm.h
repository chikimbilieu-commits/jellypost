#pragma once
#include "pch.h"
#include "Core.h"

ref class FeedView;
ref class ChatView;
ref class ProfileView;
ref class ShopView;
ref class EventView;
ref class UsersView;
ref class AdminView;

public ref class MainForm : public Form
{
public:
    MainForm();
    void GoTo(String^ view, Object^ arg);
    void RefreshAll();
    void RefreshTopbar();
    void OpenChat(String^ other);
private:
    void BuildShell();
    Button^ MakeNav(String^ key, String^ text);
    void OnNavClick(Object^ s, EventArgs^ e);
    void ShowNotifs();
    void ToggleTheme();
    void Logout();
    void HighlightNav(String^ key);
    void ApplyBadges();
    void EnsureFeed();
    void EnsureChat();
    void EnsureProfile();
    void EnsureShop();
    void EnsureEvent();
    void EnsureUsers();
    void EnsureAdmin();
    void Show(Control^ v);

    Panel^ _topbar;
    Label^ _gemsLbl;
    Label^ _chatBadge;
    Label^ _bellBadge;
    Panel^ _sidebar;
    Panel^ _content;
    Dictionary<String^, Button^>^ _navBtns;
    String^ _current;
    AvatarControl^ _meAv;
    Label^ _meName;
    Label^ _mePlus;

    FeedView^ _feed;
    ChatView^ _chat;
    ProfileView^ _profile;
    ShopView^ _shop;
    EventView^ _event;
    UsersView^ _users;
    AdminView^ _admin;
};
