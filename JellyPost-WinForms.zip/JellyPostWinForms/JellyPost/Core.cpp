#include "pch.h"
#include "Core.h"

// ===================== J =====================
Dictionary<String^, Object^>^ J::D(Object^ o) { return dynamic_cast<Dictionary<String^, Object^>^>(o); }
ArrayList^ J::A(Object^ o) { return dynamic_cast<ArrayList^>(o); }
bool J::H(Dictionary<String^, Object^>^ d, String^ k) { return d != nullptr && k != nullptr && d->ContainsKey(k); }
Object^ J::G(Dictionary<String^, Object^>^ d, String^ k) { Object^ v = nullptr; if (d != nullptr && d->TryGetValue(k, v)) return v; return nullptr; }
String^ J::S(Dictionary<String^, Object^>^ d, String^ k) { Object^ v = J::G(d, k); return v == nullptr ? "" : v->ToString(); }
long long J::N(Dictionary<String^, Object^>^ d, String^ k) { Object^ v = J::G(d, k); if (v == nullptr) return 0; try { return (long long)Convert::ToInt64(v); } catch (Exception^) { return 0; } }
bool J::B(Dictionary<String^, Object^>^ d, String^ k) { Object^ v = J::G(d, k); if (v == nullptr) return false; try { return Convert::ToBoolean(v); } catch (Exception^) { return false; } }
void J::P(Dictionary<String^, Object^>^ d, String^ k, Object^ v) { if (d != nullptr) d[k] = v; }
void J::PN(Dictionary<String^, Object^>^ d, String^ k, long long v) { if (d != nullptr) d[k] = v; }
Dictionary<String^, Object^>^ J::M(Dictionary<String^, Object^>^ d, String^ k)
{
    Object^ v = J::G(d, k);
    Dictionary<String^, Object^>^ m = dynamic_cast<Dictionary<String^, Object^>^>(v);
    if (m == nullptr) { m = gcnew Dictionary<String^, Object^>(); d[k] = m; }
    return m;
}
ArrayList^ J::L(Dictionary<String^, Object^>^ d, String^ k)
{
    Object^ v = J::G(d, k);
    ArrayList^ a = dynamic_cast<ArrayList^>(v);
    if (a == nullptr) { a = gcnew ArrayList(); d[k] = a; }
    return a;
}
long long J::Count(ArrayList^ a) { return a == nullptr ? 0 : (long long)a->Count; }

// ===================== Utils =====================
String^ Utils::Sha256(String^ s)
{
    if (s == nullptr) s = "";
    array<Byte>^ bytes = Encoding::UTF8->GetBytes(s);
    SHA256Managed^ sha = gcnew SHA256Managed();
    array<Byte>^ hash = sha->ComputeHash(bytes);
    StringBuilder^ sb = gcnew StringBuilder();
    for (int i = 0; i < hash->Length; i++) sb->Append(hash[i].ToString("x2"));
    return sb->ToString();
}
String^ Utils::HashPw(String^ pw, String^ salt) { return Utils::Sha256(String::Concat(pw, salt)); }
String^ Utils::RandSalt()
{
    String^ c = "abcdefghijklmnopqrstuvwxyz0123456789";
    Random^ r = gcnew Random();
    StringBuilder^ sb = gcnew StringBuilder();
    for (int i = 0; i < 16; i++) sb->Append(c[r->Next(c->Length)]);
    return sb->ToString();
}
String^ Utils::NewToken()
{
    String^ c = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    Random^ r = gcnew Random();
    StringBuilder^ sb = gcnew StringBuilder();
    for (int i = 0; i < 48; i++) sb->Append(c[r->Next(c->Length)]);
    return sb->ToString();
}
long long Utils::Now()
{
    TimeSpan ts = DateTime::UtcNow.Subtract(DateTime(1970, 1, 1));
    return (long long)ts.TotalMilliseconds;
}
String^ Utils::TimeAgo(long long ms)
{
    long long diff = Utils::Now() - ms;
    if (diff < 60000) return "vừa xong";
    long long m = diff / 60000;
    if (m < 60) return String::Format("{0} phút trước", m);
    long long h = m / 60;
    if (h < 24) return String::Format("{0} giờ trước", h);
    long long d = h / 24;
    if (d < 30) return String::Format("{0} ngày trước", d);
    return Utils::TimeFull(ms);
}
String^ Utils::TimeFull(long long ms)
{
    DateTime dt = DateTime(1970, 1, 1).AddMilliseconds(ms).ToLocalTime();
    return dt.ToString("dd/MM/yyyy HH:mm");
}
String^ Utils::Clean(String^ s, int max)
{
    if (s == nullptr) return "";
    s = s->Trim();
    if (s->Length > max) s = s->Substring(0, max);
    return s;
}
String^ Utils::NormVn(String^ s)
{
    String^ lo = (s == nullptr ? "" : s->ToLowerInvariant());
    String^ src = "áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ";
    String^ dst = "aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiioooooooooooooooouuuuuuuuuuuyyyyyd";
    StringBuilder^ sb = gcnew StringBuilder();
    for (int i = 0; i < lo->Length; i++)
    {
        Char c = lo[i];
        int idx = src->IndexOf(c);
        sb->Append(idx >= 0 ? dst[idx] : c);
    }
    return sb->ToString();
}
bool Utils::ValidUsername(String^ u)
{
    if (u == nullptr || u->Length < 3 || u->Length > 20) return false;
    for (int i = 0; i < u->Length; i++)
    {
        Char c = u[i];
        if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '.')) return false;
    }
    return true;
}

// ===================== Theme =====================
bool Theme::Dark = true;
Color Theme::Bg, Theme::Card, Theme::Card2, Theme::Border, Theme::Text, Theme::Muted, Theme::Accent, Theme::AccentSoft, Theme::Hover, Theme::Soft, Theme::Danger, Theme::Green, Theme::Pink;
void Theme::Set(bool dark)
{
    Theme::Dark = dark;
    if (dark)
    {
        Theme::Bg = Color::FromArgb(17, 17, 23);
        Theme::Card = Color::FromArgb(26, 26, 34);
        Theme::Card2 = Color::FromArgb(33, 33, 43);
        Theme::Border = Color::FromArgb(48, 48, 60);
        Theme::Text = Color::FromArgb(236, 238, 243);
        Theme::Muted = Color::FromArgb(148, 151, 164);
        Theme::Accent = Color::FromArgb(59, 130, 246);
        Theme::AccentSoft = Color::FromArgb(30, 64, 150);
        Theme::Hover = Color::FromArgb(42, 42, 54);
        Theme::Soft = Color::FromArgb(31, 31, 41);
        Theme::Danger = Color::FromArgb(239, 68, 68);
        Theme::Green = Color::FromArgb(16, 185, 129);
        Theme::Pink = Color::FromArgb(236, 72, 153);
    }
    else
    {
        Theme::Bg = Color::FromArgb(240, 242, 247);
        Theme::Card = Color::White;
        Theme::Card2 = Color::FromArgb(248, 249, 252);
        Theme::Border = Color::FromArgb(226, 229, 236);
        Theme::Text = Color::FromArgb(20, 20, 28);
        Theme::Muted = Color::FromArgb(118, 121, 134);
        Theme::Accent = Color::FromArgb(24, 119, 242);
        Theme::AccentSoft = Color::FromArgb(231, 243, 255);
        Theme::Hover = Color::FromArgb(242, 243, 247);
        Theme::Soft = Color::FromArgb(240, 242, 246);
        Theme::Danger = Color::FromArgb(220, 38, 38);
        Theme::Green = Color::FromArgb(5, 150, 105);
        Theme::Pink = Color::FromArgb(219, 39, 119);
    }
}

// ===================== Ui =====================
Font^ Ui::F(float size, bool bold)
{
    return gcnew Font("Segoe UI", size, bold ? FontStyle::Bold : FontStyle::Regular);
}
Button^ Ui::Btn(String^ t, int w, int h, Color back, Color fore, bool bold)
{
    Button^ b = gcnew Button();
    b->Text = t; b->Width = w; b->Height = h;
    b->BackColor = back; b->ForeColor = fore;
    b->FlatStyle = FlatStyle::Flat;
    b->FlatAppearance->BorderSize = 0;
    b->Font = Ui::F(9.5f, bold);
    b->Cursor = Cursors::Hand;
    b->TabStop = false;
    return b;
}
Button^ Ui::AccentBtn(String^ t, int w, int h)
{
    return Ui::Btn(t, w, h, Theme::Accent, Color::White, true);
}
Button^ Ui::GhostBtn(String^ t, int w, int h)
{
    Button^ b = Ui::Btn(t, w, h, Theme::Card2, Theme::Text, false);
    b->FlatAppearance->BorderSize = 1;
    b->FlatAppearance->BorderColor = Theme::Border;
    return b;
}
Label^ Ui::Lbl(String^ t, float size, bool bold, Color c)
{
    Label^ l = gcnew Label();
    l->Text = t; l->Font = Ui::F(size, bold); l->ForeColor = c;
    l->AutoSize = true;
    l->BackColor = Color::Transparent;
    return l;
}
int Ui::MeasureText(String^ t, Font^ f, int width)
{
    if (String::IsNullOrEmpty(t)) return (int)f->GetHeight() + 6;
    Bitmap^ bmp = gcnew Bitmap(1, 1);
    Graphics^ g = Graphics::FromImage(bmp);
    SizeF sz = g->MeasureString(t, f, width);
    delete g;
    delete bmp;
    return (int)Math::Ceiling(sz.Height) + 6;
}
void Ui::Style(Control^ c)
{
    c->BackColor = Theme::Bg;
    c->ForeColor = Theme::Text;
    c->Font = Ui::F(9.5f, false);
    for each (Control^ ch in c->Controls) Ui::Style(ch);
}
void Ui::Clear(Control^ c) { c->Controls->Clear(); }
String^ Ui::Fmt(long long n) { return n.ToString("N0"); }
String^ Ui::Str(long long v) { return v.ToString(); }
bool Ui::Confirm(String^ msg) { return MessageBox::Show(msg, "Jelly Post", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == DialogResult::Yes; }
void Ui::Info(String^ msg) { MessageBox::Show(msg, "Jelly Post", MessageBoxButtons::OK, MessageBoxIcon::Information); }
void Ui::Warn(String^ msg) { MessageBox::Show(msg, "Jelly Post", MessageBoxButtons::OK, MessageBoxIcon::Warning); }

// ===================== Prompt dialog =====================
ref class PromptForm : public Form
{
public:
    TextBox^ Box;
    PromptForm(String^ title, String^ label, String^ def)
    {
        this->Text = title;
        this->FormBorderStyle = FormBorderStyle::FixedDialog;
        this->MaximizeBox = false;
        this->MinimizeBox = false;
        this->StartPosition = FormStartPosition::CenterParent;
        this->ClientSize = Drawing::Size(420, 130);
        this->BackColor = Theme::Bg;
        this->ForeColor = Theme::Text;
        this->Font = Ui::F(9.5f, false);
        Label^ l = Ui::Lbl(label, 9.5f, false, Theme::Text);
        l->Location = Drawing::Point(14, 12);
        this->Controls->Add(l);
        Box = gcnew TextBox();
        Box->Text = def;
        Box->BackColor = Theme::Card2;
        Box->ForeColor = Theme::Text;
        Box->BorderStyle = BorderStyle::FixedSingle;
        Box->Location = Drawing::Point(14, 38);
        Box->Width = 392;
        Box->Height = 28;
        this->Controls->Add(Box);
        Button^ ok = Ui::AccentBtn("OK", 80, 30);
        ok->Location = Drawing::Point(14, 84);
        ok->DialogResult = DialogResult::OK;
        this->Controls->Add(ok);
        Button^ cancel = Ui::GhostBtn("Hủy", 80, 30);
        cancel->Location = Drawing::Point(102, 84);
        cancel->DialogResult = DialogResult::Cancel;
        this->Controls->Add(cancel);
        this->AcceptButton = ok;
        this->CancelButton = cancel;
    }
};
String^ Ui::Prompt(String^ title, String^ label, String^ def)
{
    PromptForm^ f = gcnew PromptForm(title, label, def);
    if (f->ShowDialog() != DialogResult::OK) return nullptr;
    return f->Box->Text;
}

// ===================== Toast =====================
ref class ToastForm : public Form
{
public:
    ToastForm(String^ msg, bool ok)
    {
        this->FormBorderStyle = FormBorderStyle::None;
        this->StartPosition = FormStartPosition::Manual;
        this->ShowInTaskbar = false;
        this->TopMost = true;
        this->ControlBox = false;
        int w = 340, h = 46;
        this->Size = Drawing::Size(w, h);
        Screen^ scr = Screen::PrimaryScreen;
        this->Location = Drawing::Point(scr->WorkingArea.Right - w - 24, scr->WorkingArea.Bottom - h - 72);
        this->BackColor = ok ? Color::FromArgb(16, 185, 129) : Color::FromArgb(220, 38, 38);
        Label^ l = gcnew Label();
        l->Text = msg;
        l->ForeColor = Color::White;
        l->Font = Ui::F(9.5f, true);
        l->Dock = DockStyle::Fill;
        l->TextAlign = ContentAlignment::MiddleCenter;
        this->Controls->Add(l);
        Timer^ t = gcnew Timer();
        t->Interval = 2400;
        t->Tick += gcnew EventHandler(this, &ToastForm::OnClose);
        t->Start();
    }
private:
    void OnClose(Object^, EventArgs^) { this->Close(); }
};
void Toast::Show(String^ msg, bool ok) { (gcnew ToastForm(msg, ok))->Show(); }

// ===================== Bus =====================
Action<String^, Object^>^ Bus::H;
void Bus::Emit(String^ action, Object^ arg) { if (Bus::H != nullptr) Bus::H(action, arg); }

// ===================== Img =====================
ref class ImgJob
{
public:
    PictureBox^ Pb;
    String^ Src;
    int MaxW, MaxH;
    Object^ Keep;
};

void Img::Do(Object^ o)
{
    ImgJob^ job = (ImgJob^)o;
    try
    {
        Image^ img = nullptr;
        Object^ keep = nullptr;
        String^ s = job->Src;
        if (s->StartsWith("http://") || s->StartsWith("https://"))
        {
            WebClient^ wc = gcnew WebClient();
            array<Byte>^ bytes = wc->DownloadData(s);
            MemoryStream^ ms = gcnew MemoryStream(bytes);
            img = Image::FromStream(ms);
            keep = ms;
        }
        else if (File::Exists(s))
        {
            array<Byte>^ bytes = File::ReadAllBytes(s);
            MemoryStream^ ms = gcnew MemoryStream(bytes);
            img = Image::FromStream(ms);
            keep = ms;
        }
        if (img != nullptr)
        {
            if (img->Width > job->MaxW || img->Height > job->MaxH)
            {
                float ratio = Math::Min((float)job->MaxW / img->Width, (float)job->MaxH / img->Height);
                int w = Math::Max(1, (int)(img->Width * ratio));
                int h = Math::Max(1, (int)(img->Height * ratio));
                Bitmap^ scaled = gcnew Bitmap(w, h);
                Graphics^ g = Graphics::FromImage(scaled);
                g->InterpolationMode = InterpolationMode::HighQualityBicubic;
                g->DrawImage(img, 0, 0, w, h);
                delete g;
                delete img;
                img = scaled;
            }
            Apply(job->Pb, img, keep);
        }
    }
    catch (Exception^) { }
}
void Img::Apply(PictureBox^ pb, Image^ img, Object^ keepAlive)
{
    try { pb->Invoke(gcnew Action<PictureBox^, Image^, Object^>(&Img::SetImg), pb, img, keepAlive); }
    catch (Exception^) { }
}
void Img::SetImg(PictureBox^ pb, Image^ img, Object^ keepAlive)
{
    if (pb->IsDisposed) return;
    pb->Tag = keepAlive;
    pb->Image = img;
    pb->SizeMode = PictureBoxSizeMode::Zoom;
}
void Img::LoadAsync(PictureBox^ pb, String^ src, int maxW, int maxH)
{
    if (pb == nullptr || String::IsNullOrEmpty(src)) return;
    ImgJob^ job = gcnew ImgJob();
    job->Pb = pb; job->Src = src; job->MaxW = maxW; job->MaxH = maxH;
    Thread^ t = gcnew Thread(gcnew ParameterizedThreadStart(&Img::Do));
    t->IsBackground = true;
    t->Start(job);
}

// ===================== AvatarControl =====================
AvatarControl::AvatarControl()
{
    _av = 0; _dec = 0; _sz = 40; _decImg = nullptr; _decLoaded = false; _decLoading = false;
    SetStyle(ControlStyles::UserPaint | ControlStyles::AllPaintingInWmPaint | ControlStyles::OptimizedDoubleBuffer | ControlStyles::ResizeRedraw, true);
    this->Size = Drawing::Size(40, 40);
}
void AvatarControl::SetData(int av, String^ ai, int dec, int sizePx)
{
    _av = av; _dec = dec; _sz = sizePx;
    _decImg = nullptr; _decLoaded = false; _decLoading = false;
    this->Size = Drawing::Size(sizePx, sizePx);
    if (dec > 0) TryLoadDec();
    Invalidate();
}
void AvatarControl::TryLoadDec()
{
    if (_decLoading) return;
    _decLoading = true;
    Thread^ t = gcnew Thread(gcnew ThreadStart(this, &AvatarControl::FetchDec));
    t->IsBackground = true;
    t->Start();
}
void AvatarControl::FetchDec()
{
    try
    {
        String^ url = Catalog::DecImage(_dec);
        if (String::IsNullOrEmpty(url)) { DecFailed(); return; }
        WebClient^ wc = gcnew WebClient();
        array<Byte>^ bytes = wc->DownloadData(url);
        MemoryStream^ ms = gcnew MemoryStream(bytes);
        Bitmap^ bmp = gcnew Bitmap(ms);
        DecLoaded(bmp);
    }
    catch (Exception^) { DecFailed(); }
}
void AvatarControl::DecLoaded(Bitmap^ b)
{
    try { this->Invoke(gcnew Action<Bitmap^>(this, &AvatarControl::ApplyDec), b); }
    catch (Exception^) { }
}
void AvatarControl::ApplyDec(Bitmap^ b)
{
    _decImg = b; _decLoaded = true; _decLoading = false;
    if (!this->IsDisposed) Invalidate();
}
void AvatarControl::DecFailed()
{
    try { this->Invoke(gcnew Action(this, &AvatarControl::MarkFail)); }
    catch (Exception^) { }
}
void AvatarControl::MarkFail() { _decLoading = false; }
void AvatarControl::OnPaint(PaintEventArgs^ e)
{
    Control::OnPaint(e);
    Graphics^ g = e->Graphics;
    g->SmoothingMode = SmoothingMode::AntiAlias;
    int s = Math::Min(this->Width, this->Height);
    if (s <= 0) return;
    RectangleF rc(0.0f, 0.0f, (float)s, (float)s);
    Color bg = Catalog::AvColors[_av % Catalog::AvColors->Length];
    g->FillEllipse(gcnew SolidBrush(bg), rc);
    String^ emo = Catalog::AvEmoji[_av % Catalog::AvEmoji->Length];
    float fs = s * 0.60f;
    Font^ f = gcnew Font("Segoe UI Emoji", fs, FontStyle::Regular, GraphicsUnit::Pixel);
    StringFormat^ sf = gcnew StringFormat();
    sf->Alignment = StringAlignment::Center;
    sf->LineAlignment = StringAlignment::Center;
    RectangleF rcTxt(0.0f, 0.0f, (float)s, (float)s);
    g->DrawString(emo, f, gcnew SolidBrush(Color::White), rcTxt, sf);
    delete sf; delete f;
    if (_dec > 0)
    {
        if (_decImg != nullptr)
        {
            GraphicsPath^ path = gcnew GraphicsPath();
            path->AddEllipse(rc);
            Region^ old = g->Clip;
            g->SetClip(path);
            float inset = -s * 0.18f;
            RectangleF imgRc(inset, inset, s - 2.0f * inset, s - 2.0f * inset);
            g->DrawImage(_decImg, imgRc);
            g->SetClip(old);
            delete path;
        }
        else
        {
            Pen^ p = gcnew Pen(Color::FromArgb(120, Color::White), Math::Max(2.0f, s * 0.055f));
            p->DashStyle = DashStyle::Dash;
            g->DrawEllipse(p, 1.5f, 1.5f, s - 3.0f, s - 3.0f);
            delete p;
        }
    }
}
void AvatarControl::OnResize(EventArgs^ e) { Control::OnResize(e); Invalidate(); }
