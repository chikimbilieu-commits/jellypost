#pragma once
#include "pch.h"
#include "PostCard.h"

public ref class FeedView : public UserControl
{
public:
    FeedView();
    void ShowFeed();
    void ShowSaved();
    void RefreshView();
    void RefreshList();
private:
    void BuildComposer();
    void OnPost(Object^ s, EventArgs^ e);
    void OnAttach(Object^ s, EventArgs^ e);
    void OnRemoveImg(Object^ s, EventArgs^ e);
    void OnAction(String^ action, Object^ arg);
    void AddCard(Dictionary<String^, Object^>^ p);
    void RebuildCards();
    void SetWidths();
protected:
    virtual void OnResize(EventArgs^ e) override;

    Panel^ _composer;
    TextBox^ _txt;
    FlowLayoutPanel^ _imgPrev;
    Label^ _modeLbl;
    Panel^ _feedWrap;
    Panel^ _list;
    bool _saved;
    ArrayList^ _attach;
    System::Collections::Generic::HashSet<long long>^ _cmtOpen;
};
