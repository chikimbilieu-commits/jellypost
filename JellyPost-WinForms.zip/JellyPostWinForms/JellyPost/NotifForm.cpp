#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "NotifForm.h"

NotifForm::NotifForm()
{
    this->Text = "Thông báo";
    this->StartPosition = FormStartPosition::CenterParent;
    this->ClientSize = Drawing::Size(560, 560);
    this->BackColor = Theme::Bg;
    this->ForeColor = Theme::Text;
    this->Font = Ui::F(9.5f, false);
    this->ShowInTaskbar = false;

    Build();
    Store::MarkNotifsSeen();
}

void NotifForm::Build()
{
    Label^ title = Ui::Lbl("🔔  Thông báo", 13.0f, true, Theme::Text);
    title->Location = Drawing::Point(16, 12);
    this->Controls->Add(title);

    Button^ clear = Ui::Btn("Xóa tất cả", 90, 28, Theme::Card2, Theme::Danger, false);
    clear->FlatAppearance->BorderSize = 1;
    clear->FlatAppearance->BorderColor = Theme::Border;
    clear->Click += gcnew EventHandler(this, &NotifForm::OnClear);
    clear->Location = Drawing::Point(this->ClientSize.Width - 106, 12);
    clear->Anchor = AnchorStyles::Top | AnchorStyles::Right;
    this->Controls->Add(clear);

    _list = gcnew Panel();
    _list->Dock = DockStyle::Fill;
    _list->BackColor = Theme::Bg;
    _list->AutoScroll = true;
    _list->Location = Drawing::Point(0, 48);
    this->Controls->Add(_list);

    ArrayList^ notifs = Store::Notifs();
    int y = 8;
    for (int i = notifs->Count - 1; i >= 0; i--)
    {
        Dictionary<String^, Object^>^ n = dynamic_cast<Dictionary<String^, Object^>^>(notifs[i]);
        if (n == nullptr) continue;
        String^ type = J::S(n, "t");
        String^ f = J::S(n, "f");
        long long pid = J::N(n, "pid");
        String^ emo = J::S(n, "emo");
        String^ txt;
        if (type == "mention") txt = "@" + f + " đã nhắc bạn trong một bài viết: \"" + (J::S(n, "sn") == "" ? "(ảnh)" : J::S(n, "sn")) + "\"";
        else if (type == "cmt") txt = f + " đã bình luận: \"" + J::S(n, "sn") + "\"";
        else if (type == "like") txt = f + " đã bày tỏ cảm xúc " + (emo == "" ? "❤️" : emo) + " bài viết của bạn";
        else if (type == "gem") txt = "🎉 Bạn nhận " + Ui::Str(J::N(n, "n")) + " 💎 hoàn thành nhiệm vụ: " + J::S(n, "lab");
        else if (type == "mc") txt = f + " đã tương tác — bạn nhận " + J::N(n, "n") + " 🥮 Trung thu";
        else if (type == "req") txt = f + " đã gửi lời mời kết bạn";
        else if (type == "reqok") txt = f + " đã chấp nhận lời mời kết bạn 🎉";
        else if (type == "plus") txt = "🎉 Chúc mừng! Bạn đã nâng cấp ⭐ Plus";
        else txt = (emo == "" ? "🔔 " : emo + " ") + J::S(n, "lab") + " " + f;

        Panel^ row = gcnew Panel();
        row->BackColor = Theme::Card;
        row->Width = this->ClientSize.Width - 32;
        row->Height = 52;
        row->Location = Drawing::Point(16, y);
        _list->Controls->Add(row);

        Label^ t = Ui::Lbl(txt, 9.5f, false, Theme::Text);
        t->AutoSize = false;
        t->Width = row->Width - 120;
        t->Height = 34;
        t->Location = Drawing::Point(12, 6);
        row->Controls->Add(t);

        Label^ tm = Ui::Lbl(Utils::TimeAgo(J::N(n, "x")), 8.0f, false, Theme::Muted);
        tm->Location = Drawing::Point(12, 34);
        row->Controls->Add(tm);

        Button^ open = Ui::AccentBtn("Mở", 60, 26);
        open->Tag = n;
        open->Click += gcnew EventHandler(this, &NotifForm::OnOpen);
        open->Location = Drawing::Point(row->Width - 72, 12);
        row->Controls->Add(open);

        y += 58;
    }
    if (notifs->Count == 0)
    {
        Label^ n = Ui::Lbl("Chưa có thông báo nào", 10.0f, false, Theme::Muted);
        n->Location = Drawing::Point(20, 20);
        _list->Controls->Add(n);
    }
}

void NotifForm::OnOpen(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    Dictionary<String^, Object^>^ n = (Dictionary<String^, Object^>^)b->Tag;
    String^ type = J::S(n, "t");
    String^ f = J::S(n, "f");
    this->Close();
    if (type == "req" || type == "reqok") AppCtx::Nav("profile", f);
    else if (type == "gem") AppCtx::Nav("shop", nullptr);
    else AppCtx::Nav("feed", nullptr);
}

void NotifForm::OnClear(Object^ s, EventArgs^)
{
    if (!Ui::Confirm("Xóa toàn bộ thông báo?")) return;
    ClearAll();
    this->Controls->Clear();
    Build();
}

void NotifForm::ClearAll()
{
    Dictionary<String^, Object^>^ nf = Store::NotifsDict();
    if (nf->ContainsKey(Store::Me)) nf->Remove(Store::Me);
    Store::Save();
}
