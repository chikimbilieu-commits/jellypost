#include "pch.h"
#include "Core.h"

array<String^>^ Catalog::AvEmoji;
array<String^>^ Catalog::AvColors;
array<String^>^ Catalog::Reactions;
List<ShopItem^>^ Catalog::Items;
List<ShopItem^>^ Catalog::PlusItems;
List<ShopItem^>^ Catalog::McShop;
List<Quest^>^ Catalog::Quests;
String^ Catalog::GemUrl = "https://user.uploads.dev/file/887317a58299a336cf4a8a7c51289702.png";

static Dictionary<int, String^>^ g_decImg;

String^ Catalog::DecImage(int idx)
{
    if (g_decImg == nullptr) return nullptr;
    String^ url = nullptr;
    if (g_decImg->TryGetValue(idx, url)) return url;
    return nullptr;
}

ShopItem^ Catalog::FindItem(String^ id)
{
    for each (ShopItem^ it in Catalog::Items) if (it->Id == id) return it;
    for each (ShopItem^ it in Catalog::PlusItems) if (it->Id == id) return it;
    return nullptr;
}

static ShopItem^ Mk(String^ id, String^ type, int idx, int cost, String^ emo, String^ name, bool limited, bool on, bool ev, int pickT)
{
    ShopItem^ it = gcnew ShopItem();
    it->Id = id; it->Type = type; it->Idx = idx; it->Cost = cost; it->Emo = emo; it->Name = name;
    it->Limited = limited; it->On = on; it->Ev = ev; it->PickT = pickT; it->Image = "";
    return it;
}

void Catalog::Init()
{
    if (Catalog::Items != nullptr) return;

    Catalog::AvEmoji = gcnew array<String^> {
        "🦊","🐱","🐶","🐼","🐸","🐰","🐨","🐯","🦁","🐮","🐷","🐹","🐻","🐵","🐔","🐧","🐙","🦄","🐳","🦋","🐝",
        "🌸","⭐","🌈","🍓","🍩","🍕","🍉","⚽","🎧","🎮","🚀","🌙","🔥","💎","🎀","🍀","🌻","🍄","🫧","🧁","🍭","🧸","👻","🤖","👑","😎","🥑"
    };
    Catalog::AvColors = gcnew array<String^> { "#ffd6e0", "#d6e9ff", "#d9f7e3", "#fff3c9", "#e6ddff", "#ffdccc", "#d8f5f5", "#f5e0ff" };
    Catalog::Reactions = gcnew array<String^> { "👍", "❤️", "😂", "😮", "😢", "😡" };

    Catalog::Quests = gcnew List<Quest^>();
    Quest^ q1 = gcnew Quest(); q1->K = "p"; q1->Emo = "📝"; q1->Label = "Đăng bài viết"; q1->Need = 3; q1->Reward = 30; Catalog::Quests->Add(q1);
    Quest^ q2 = gcnew Quest(); q2->K = "r"; q2->Emo = "💬"; q2->Label = "Tương tác (react hoặc bình luận)"; q2->Need = 10; q2->Reward = 20; Catalog::Quests->Add(q2);
    Quest^ q3 = gcnew Quest(); q3->K = "g"; q3->Emo = "⭐"; q3->Label = "Nhận react từ người khác"; q3->Need = 5; q3->Reward = 25; Catalog::Quests->Add(q3);

    Catalog::Items = gcnew List<ShopItem^>();
    Catalog::Items->Add(Mk("dec7",  "dec",  7,  80,  "🔵", "Vòng Doraemon", false, true, false, 0));
    Catalog::Items->Add(Mk("dec16", "dec", 16, 250,  "🎀", "Vòng tay NJZ", false, true, false, 0));
    Catalog::Items->Add(Mk("dec17", "dec", 17, 250,  "🐰", "Newjeans Lightstick", false, true, false, 0));
    Catalog::Items->Add(Mk("dec18", "dec", 18, 200,  "💗", "ILLIT - NOT CUTE ANYMORE Ver Pink", false, true, false, 0));
    Catalog::Items->Add(Mk("dec19", "dec", 19, 200,  "🍃", "ILLIT - NOT CUTE ANYMORE Ver Mint Green", false, true, false, 0));
    Catalog::Items->Add(Mk("dec20", "dec", 20, 120,  "⚡", "aespa - WHIPLASH", false, true, false, 0));
    Catalog::Items->Add(Mk("dec21", "dec", 21, 280,  "🎶", "NMIXX - Heavy Serenade", false, true, false, 0));
    Catalog::Items->Add(Mk("dec22", "dec", 22, 100,  "📷", "STARLIT SNAP", false, true, false, 0));
    Catalog::Items->Add(Mk("dec23", "dec", 23,  80,  "🌸", "Sakura - 桜", false, true, false, 0));
    Catalog::Items->Add(Mk("dec24", "dec", 24,  80,  "🔔", "Li Meiling - 苺鈴", false, true, false, 0));
    Catalog::Items->Add(Mk("dec25", "dec", 25,  80,  "🎥", "Tomoyo - 知世", false, true, false, 0));
    Catalog::Items->Add(Mk("dec26", "dec", 26,  80,  "🗡️", "Li Syaoran - 李小狼", false, true, false, 0));
    Catalog::Items->Add(Mk("dec27", "dec", 27,  80,  "🐹", "Chiikawa - ちいかわ", false, true, false, 0));
    Catalog::Items->Add(Mk("dec28", "dec", 28,  80,  "🐿️", "Momonga - モモンガ", false, true, false, 0));
    Catalog::Items->Add(Mk("dec29", "dec", 29,  80,  "🐰", "Usagi - うさぎ", false, true, false, 0));
    Catalog::Items->Add(Mk("dec30", "dec", 30,  80,  "🥮", "Kuri-manju - くりまんじゅう", false, true, false, 0));
    Catalog::Items->Add(Mk("dec31", "dec", 31, 100,  "🐾", "Lace & Paw", false, true, false, 0));
    Catalog::Items->Add(Mk("dec33", "dec", 33, 175,  "🐻❄️", "Polar Hoodie - Gấu Bắc Cực", false, true, false, 0));
    Catalog::Items->Add(Mk("dec34", "dec", 34, 175,  "🧛", "Theresa - Luna Kindred", false, true, false, 0));
    Catalog::Items->Add(Mk("dec35", "dec", 35, 175,  "🍃", "Nahida - Thần Tri Thức", false, true, false, 0));
    Catalog::Items->Add(Mk("dec36", "dec", 36, 175,  "✨", "Paimon - Trợ Thủ Du Ngoạn", false, true, false, 0));
    Catalog::Items->Add(Mk("dec37", "dec", 37, 175,  "🐺", "Von Lycaon - Quản Gia Sói", false, true, false, 0));
    Catalog::Items->Add(Mk("dec38", "dec", 38, 175,  "🎧", "Toya - Cat Set", false, true, false, 0));
    Catalog::Items->Add(Mk("dec39", "dec", 39, 175,  "🦊", "Fox Ears - Hồ Ly", false, true, false, 0));
    Catalog::Items->Add(Mk("dec40", "dec", 40, 175,  "💜", "MY HUSBAND", false, true, false, 0));
    Catalog::Items->Add(Mk("dec41", "dec", 41, 150,  "🪽", "Sakura Sparkle", false, true, false, 0));
    Catalog::Items->Add(Mk("dec42", "dec", 42, 325,  "🏮", "Đêm Hội Lồng Đèn", true, true, false, 0));
    Catalog::Items->Add(Mk("dec43", "dec", 43, 325,  "🌊", "Vương Quốc Đại Dương", true, true, false, 0));
    Catalog::Items->Add(Mk("dec44", "dec", 44, 325,  "🐴", "Xe Ngựa Cổ Tích", true, true, false, 0));
    Catalog::Items->Add(Mk("dec45", "dec", 45,  80,  "💙", "ILLIT", false, true, false, 0));
    Catalog::Items->Add(Mk("dec46", "dec", 46,  80,  "❤️", "Babymonster", false, true, false, 0));
    Catalog::Items->Add(Mk("dec47", "dec", 47, 150,  "🌟", "Thiên Đường Mây", false, true, false, 0));
    Catalog::Items->Add(Mk("dec48", "dec", 48, 150,  "📺", "UP Huyền Thoại", false, true, false, 0));
    Catalog::Items->Add(Mk("dec49", "dec", 49, 150,  "🎀", "Thú Cưng Dễ Thương", false, true, false, 0));
    Catalog::Items->Add(Mk("dec50", "dec", 50, 180,  "🖤", "Lisa - Alter Ego", false, true, false, 0));
    Catalog::Items->Add(Mk("dec51", "dec", 51, 180,  "🌹", "Rosé - Rosie", false, true, false, 0));
    Catalog::Items->Add(Mk("dec52", "dec", 52, 180,  "💎", "Jennie - Ruby", false, true, false, 0));
    Catalog::Items->Add(Mk("dec53", "dec", 53, 180,  "🕊️", "Jisoo - Amortage", false, true, false, 0));
    Catalog::Items->Add(Mk("dec54", "dec", 54, 150,  "🍓", "Vòng Dâu Ngọt", false, true, false, 0));
    Catalog::Items->Add(Mk("dec55", "dec", 55, 150,  "🌹", "Vòng Hồng Gai", false, true, false, 0));
    Catalog::Items->Add(Mk("dec56", "dec", 56, 175,  "🦌", "Chopper", false, true, false, 0));
    Catalog::Items->Add(Mk("dec57", "dec", 57,  40,  "📺", "Livestream", false, true, false, 0));
    Catalog::Items->Add(Mk("dec58", "dec", 58, 325,  "🐇", "Thỏ Ngọc Đêm Rằm", true, false, true, 0));
    Catalog::Items->Add(Mk("dec59", "dec", 59, 325,  "🌕", "Trăng Rằm Cổ Tích", true, false, true, 0));
    Catalog::Items->Add(Mk("pf11", "peff", 11,  55,  "💎", "Hiệu ứng Gems", false, true, false, 0));
    Catalog::Items->Add(Mk("pf12", "peff", 12,  55,  "🦋", "Hiệu ứng Bướm", false, true, false, 0));
    Catalog::Items->Add(Mk("pf13", "peff", 13, 280,  "🌼", "Hiệu ứng Petal", true, true, false, 0));
    Catalog::Items->Add(Mk("pf14", "peff", 14, 650,  "🌸", "Vòng Ma Thuật Sakura", true, true, false, 0));
    Catalog::Items->Add(Mk("pf15", "peff", 15,  20,  "💖", "Trái Tim Phép Thuật", false, true, false, 0));
    Catalog::Items->Add(Mk("pf16", "peff", 16,  70,  "🪄", "Đũa Phép Ma Thuật", false, true, false, 0));

    Catalog::PlusItems = gcnew List<ShopItem^>();
    Catalog::PlusItems->Add(Mk("plus1", "plus", 1, 50, "⭐", "Plus 1 Ngày", false, true, false, 0));
    Catalog::PlusItems->Add(Mk("plus3", "plus", 3, 120, "⭐", "Plus 3 Ngày", false, true, false, 0));
    Catalog::PlusItems->Add(Mk("plus7", "plus", 7, 300, "⭐", "Plus 1 Tuần", false, true, false, 0));
    Catalog::PlusItems->Add(Mk("plus99", "plus", 0, 9999, "👑", "Plus Vĩnh Viễn", false, true, false, 0));
    Catalog::PlusItems[0]->P = 0.0125;
    Catalog::PlusItems[1]->P = 0.0075;
    Catalog::PlusItems[2]->P = 0.0025;
    Catalog::PlusItems[3]->P = 0.001;

    Catalog::McShop = gcnew List<ShopItem^>();
    Catalog::McShop->Add(Mk("dec59", "dec", 59, 300, "🌕", "Trăng Rằm Cổ Tích", false, true, false, 0));
    Catalog::McShop->Add(Mk("dec58", "dec", 58, 300, "🐇", "Thỏ Ngọc Đêm Rằm", false, true, false, 0));
    Catalog::McShop->Add(Mk("dec44", "dec", 44, 500, "🐴", "Xe Ngựa Cổ Tích", false, true, false, 0));
    Catalog::McShop->Add(Mk("dec42", "dec", 42, 450, "🏮", "Đêm Hội Lồng Đèn", false, true, false, 0));
    Catalog::McShop->Add(Mk("dec43", "dec", 43, 500, "🌊", "Vương Quốc Đại Dương", false, true, false, 0));
    Catalog::McShop->Add(Mk("pf14", "peff", 14, 1000, "🌸", "Vòng Ma Thuật Sakura", false, true, false, 0));
    Catalog::McShop->Add(Mk("pf13", "peff", 13, 600, "🌼", "Hiệu Ứng Petal", false, true, false, 0));
    Catalog::McShop->Add(Mk("mcpick1", "pick", 1, 150, "🎁", "Khung Tự Chọn (≤80 Gems)", false, true, false, 1));
    Catalog::McShop->Add(Mk("mcpick2", "pick", 2, 255, "🎁", "Khung Tự Chọn (120–300 Gems)", false, true, false, 2));

    g_decImg = gcnew Dictionary<int, String^>();
#define DECURL(n, f) g_decImg[n] = "https://user.uploads.dev/file/" f
    DECURL(7,  "d3aa2fa250e407fa3625ec0b9a1bdab5.png");
    DECURL(16, "b4bb4e27f13b4c1c8b68e31f8c24a3d3.png");
    DECURL(17, "0fb96f675c5222c1e31e64b40acbb1ee.png");
    DECURL(18, "64e574c411e0ba00967da2b1aeabe160.png");
    DECURL(19, "92ffeed89c3011ba76b6fea290b38a5c.png");
    DECURL(20, "7c85bab668eb545770b4b4ed93e483f4.png");
    DECURL(21, "a037dc127c1ca33f574654436838f005.png");
    DECURL(22, "0ce52d30095c6d7e3acc9f858a4129e4.png");
    DECURL(23, "a08c584148599815554c67f078ec1bc7.png");
    DECURL(24, "6187c4f9c47419853eb1ee6b8471c1b7.png");
    DECURL(25, "52ee3b2a0afe75c6065aafb605a5d555.png");
    DECURL(26, "9ebeece21213cb7027a6fcd0276322f8.png");
    DECURL(27, "f7a07189c429fc79a0e4a675ae194fc6.png");
    DECURL(28, "4ff84005a9fba92a9733e901cf241963.png");
    DECURL(29, "b10399f7620c40beb39a1933007eb6b3.png");
    DECURL(30, "48b9d7fdc042d2eff1e5e33f2ebd9d9e.png");
    DECURL(31, "57131e8f5b5bfef5f19f4d4f9f67e377.png");
    DECURL(33, "6b4ba1c9f5ed83f80968cd2d7e25accf.png");
    DECURL(34, "60e0bdff34b9be7b14c6793103676df8.png");
    DECURL(35, "931624c829dc2a59bbfcdc1c79004a79.png");
    DECURL(36, "d4a5a287fed7fe56641dcb27aca1dbb1.png");
    DECURL(37, "a963a92a77358946c3212100aead9e28.png");
    DECURL(38, "1ecf2c7e5b6ef165e2654c0b279ff708.png");
    DECURL(39, "7428f740c234af1ec24ed588a5a7488e.png");
    DECURL(40, "2def2b2580764ed2dd09492084644014.png");
    DECURL(41, "a322bdee674035467e14bb6ff2f2b8fd.png");
    DECURL(42, "32f2f0c5890819346e2a377a22ba66d6.gif");
    DECURL(43, "3014d3841cd750b3def6db99f0452f16.gif");
    DECURL(44, "ffe4185d8b807ba999ff77ae70cf432f.gif");
    DECURL(45, "421f112a94371e4a409fb23b24366eb7.png");
    DECURL(46, "fc31f45c1f02506d379bdda81957a50f.png");
    DECURL(47, "1f3fe732c799cd49d64f9c1243d8fc2a.png");
    DECURL(48, "76bdff1eba30183ab861ed1119e6a48a.png");
    DECURL(49, "4a29dc9cd90325db344297b63b9f546b.png");
    DECURL(50, "5cbd26caea215735de71dac63e106a68.png");
    DECURL(51, "599573368956beda4a9748c12949eb58.png");
    DECURL(52, "405484956829bb3bc22cfb3ad22529d3.png");
    DECURL(53, "c95e61bffbd2bbe6288ee79edc79edfd.png");
    DECURL(54, "781ffa0dbdbe628c31dcc038ba85661a.png");
    DECURL(55, "7b05996fc22a0f610a317605b0621ad0.png");
    DECURL(56, "99367a192cb6100c871f0899b5f2a6a7.png");
    DECURL(57, "07fda3ca622f47b3a7b864b381af2c33.png");
    DECURL(58, "925b7bf2269e48836c413e6ade40521b.png");
    DECURL(59, "1a16b21fe1c6425a58ff0acf7a7c5a52.png");
#undef DECURL
}
