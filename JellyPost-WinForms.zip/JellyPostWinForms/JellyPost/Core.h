#pragma once
#include "pch.h"

// ===================== Forward declarations =====================
ref class MainForm;

// ===================== J: untyped JSON access helpers =====================
public ref class J abstract sealed
{
public:
    static Dictionary<String^, Object^>^ D(Object^ o);
    static ArrayList^ A(Object^ o);
    static bool H(Dictionary<String^, Object^>^ d, String^ k);
    static Object^ G(Dictionary<String^, Object^>^ d, String^ k);
    static String^ S(Dictionary<String^, Object^>^ d, String^ k);
    static long long N(Dictionary<String^, Object^>^ d, String^ k);
    static bool B(Dictionary<String^, Object^>^ d, String^ k);
    static void P(Dictionary<String^, Object^>^ d, String^ k, Object^ v);
    static void PN(Dictionary<String^, Object^>^ d, String^ k, long long v);
    static Dictionary<String^, Object^>^ M(Dictionary<String^, Object^>^ d, String^ k); // ensure dict child
    static ArrayList^ L(Dictionary<String^, Object^>^ d, String^ k);                    // ensure list child
    static long long Count(ArrayList^ a);
};

// ===================== Utils =====================
public ref class Utils abstract sealed
{
public:
    static String^ Sha256(String^ s);
    static String^ HashPw(String^ pw, String^ salt);
    static String^ RandSalt();
    static String^ NewToken();
    static long long Now();
    static String^ TimeAgo(long long ms);
    static String^ TimeFull(long long ms);
    static String^ Clean(String^ s, int max);
    static String^ NormVn(String^ s);
    static bool ValidUsername(String^ u);
};

// ===================== Theme =====================
public ref class Theme abstract sealed
{
public:
    static bool Dark;
    static Color Bg, Card, Card2, Border, Text, Muted, Accent, AccentSoft, Hover, Soft, Danger, Green, Pink;
    static void Set(bool dark);
};

// ===================== ShopItem / Quest =====================
public ref class ShopItem
{
public:
    String^ Id;
    String^ Type;   // "dec" | "peff" | "plus" | "pick"
    int Idx;
    String^ Emo;
    String^ Name;
    int Cost;
    bool Limited;
    bool On;
    bool Ev;
    int PickT;
    String^ Image;
    double P;       // only for "plus" items: weight in Lucky Draw
};

public ref class Quest
{
public:
    String^ K;
    String^ Emo;
    String^ Label;
    int Need;
    int Reward;
};

// ===================== Catalog: static app data =====================
public ref class Catalog abstract sealed
{
public:
    static array<String^>^ AvEmoji;
    static array<String^>^ AvColors;
    static array<String^>^ Reactions;
    static List<ShopItem^>^ Items;   // EVENT_ITEMS (cua hang gems)
    static List<ShopItem^>^ PlusItems;
    static List<ShopItem^>^ McShop;  // MC_SHOP (su kien trung thu)
    static List<Quest^>^ Quests;
    static String^ GemUrl;
    static void Init();
    static ShopItem^ FindItem(String^ id);
    static String^ DecImage(int idx);
};

// ===================== Ui: control builders =====================
public ref class Ui abstract sealed
{
public:
    static Font^ F(float size, bool bold);
    static Button^ Btn(String^ t, int w, int h, Color back, Color fore, bool bold);
    static Button^ AccentBtn(String^ t, int w, int h);
    static Button^ GhostBtn(String^ t, int w, int h);
    static Label^ Lbl(String^ t, float size, bool bold, Color c);
    static int MeasureText(String^ t, Font^ f, int width);
    static void Style(Control^ c);
    static void Clear(Control^ c);
    static String^ Fmt(long long n);
    static String^ Str(long long v);
    static bool Confirm(String^ msg);
    static void Info(String^ msg);
    static void Warn(String^ msg);
    static String^ Prompt(String^ title, String^ label, String^ def);
};

// ===================== Toast =====================
public ref class Toast abstract sealed
{
public:
    static void Show(String^ msg, bool ok);
};

// ===================== AppCtx =====================
public ref class AppCtx abstract sealed
{
public:
    static MainForm^ Win;
    static void Nav(String^ view, Object^ arg);
};

// ===================== Bus: simple action bus (PostCard -> active view) =====================
public ref class Bus abstract sealed
{
public:
    static Action<String^, Object^>^ H;
    static void Emit(String^ action, Object^ arg);
};

// ===================== Img: async image loading (URL or local path) =====================
public ref class Img abstract sealed
{
public:
    static void LoadAsync(PictureBox^ pb, String^ src, int maxW, int maxH);
private:
    static void Do(Object^ o);
    static void Apply(PictureBox^ pb, Image^ img, Object^ keepAlive);
    static void SetImg(PictureBox^ pb, Image^ img, Object^ keepAlive);
};

// ===================== AvatarControl =====================
public ref class AvatarControl : public Control
{
public:
    AvatarControl();
    void SetData(int av, String^ ai, int dec, int sizePx);
protected:
    virtual void OnPaint(PaintEventArgs^ e) override;
    virtual void OnResize(EventArgs^ e) override;
private:
    int _av;
    int _dec;
    int _sz;
    Bitmap^ _decImg;
    bool _decLoaded;
    bool _decLoading;
    void TryLoadDec();
    void FetchDec();
    void DecLoaded(Bitmap^ b);
    void DecFailed();
};
