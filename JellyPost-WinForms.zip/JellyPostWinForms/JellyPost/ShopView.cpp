#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "ShopView.h"

ShopView::ShopView()
{
    this->BackColor = Theme::Bg;
    _padd = 24;
    _wrap = gcnew Panel();
    _wrap->Dock = DockStyle::Fill;
    _wrap->BackColor = Theme::Bg;
    _wrap->AutoScroll = true;
    this->Controls->Add(_wrap);
    _page = gcnew Panel();
    _page->BackColor = Theme::Bg;
    _wrap->Controls->Add(_page);
}

void ShopView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    _page->Width = Math::Max(400, this->ClientSize.Width - 28);
}

void ShopView::RefreshView()
{
    Rebuild();
}

void ShopView::Rebuild()
{
    _page->Controls->Clear();
    _page->Width = Math::Max(400, this->ClientSize.Width - 28);
    int cw = _page->Width - 2 * _padd;
    int y = 12;

    if (!Store::EventEnabled())
    {
        Label^ off = Ui::Lbl("⛔  Cửa hàng Gems đang tạm đóng cửa", 13.0f, true, Theme::Danger);
        off->Location = Drawing::Point(_padd, y); _page->Controls->Add(off);
        y += 40;
        _page->Height = y;
        return;
    }

    // balance card
    Panel^ bal = gcnew Panel();
    bal->BackColor = Theme::Card;
    bal->Location = Drawing::Point(_padd, y);
    bal->Width = cw;
    bal->Height = 64;
    _page->Controls->Add(bal);
    Label^ b1 = Ui::Lbl("Số dư của bạn", 9.0f, false, Theme::Muted);
    b1->Location = Drawing::Point(16, 12); bal->Controls->Add(b1);
    _gemsLbl = Ui::Lbl("💎 " + Ui::Fmt(Store::Gems(Store::Me)), 18.0f, true, Theme::Accent);
    _gemsLbl->Location = Drawing::Point(16, 28); bal->Controls->Add(_gemsLbl);
    Label^ b2 = Ui::Lbl(Store::PlusOn(Store::Me) ? "Bạn đang dùng ⭐ Plus" : "Mua ⭐ Plus để nhận đặc quyền", 9.0f, false, Store::PlusOn(Store::Me) ? Theme::Green : Theme::Muted);
    b2->Location = Drawing::Point(cw - 240, 22); b2->AutoSize = false; b2->Width = 220; b2->TextAlign = ContentAlignment::MiddleRight;
    bal->Controls->Add(b2);
    y += 76;

    // quests
    Panel^ qc = gcnew Panel();
    qc->BackColor = Theme::Card;
    qc->Location = Drawing::Point(_padd, y);
    qc->Width = cw;
    _page->Controls->Add(qc);
    int qy = 12;
    Label^ t1 = Ui::Lbl("🎯  Nhiệm vụ hằng ngày", 11.0f, true, Theme::Text);
    t1->Location = Drawing::Point(14, qy); qc->Controls->Add(t1); qy += 30;
    Dictionary<String^, Object^>^ qs = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::MeObj(), "qs"));
    long long qday = qs == nullptr ? -1 : J::N(qs, "d");
    long long today = Utils::Now() / 86400000LL;
    for each (Quest^ q in Catalog::Quests)
    {
        long long cur = (qs != nullptr && qday == today) ? J::N(qs, q->K) : 0;
        bool done = qs != nullptr && qday == today && J::B(qs, q->K + "d");
        Label^ line = Ui::Lbl(q->Emo + "  " + q->Label + "   (" + Ui::Str(cur) + "/" + Ui::Str(q->Need) + ")", 9.5f, false, Theme::Text);
        line->Location = Drawing::Point(14, qy); qc->Controls->Add(line); qy += 20;
        // progress bar
        Panel^ bar = gcnew Panel();
        bar->BackColor = Theme::Card2;
        bar->Location = Drawing::Point(14, qy);
        bar->Width = cw - 220;
        bar->Height = 10;
        qc->Controls->Add(bar);
        Panel^ fill = gcnew Panel();
        fill->BackColor = done ? Theme::Green : Theme::Accent;
        fill->Height = 10;
        fill->Width = (int)(bar->Width * Math::Min(1.0, (double)cur / q->Need));
        bar->Controls->Add(fill);
        Label^ rew = Ui::Lbl(done ? "✔ Đã nhận" : "+" + Ui::Str(q->Reward) + " 💎", 9.0f, true, done ? Theme::Green : Theme::Accent);
        rew->TextAlign = ContentAlignment::MiddleRight;
        rew->AutoSize = false;
        rew->Width = 120;
        rew->Location = Drawing::Point(cw - 190, qy - 5);
        qc->Controls->Add(rew);
        qy += 24;
    }
    qy += 6;
    qc->Height = qy + 6;
    y += qc->Height + 12;

    // lucky draw
    Panel^ dr = gcnew Panel();
    dr->BackColor = Theme::Card;
    dr->Location = Drawing::Point(_padd, y);
    dr->Width = cw;
    dr->Height = 96;
    _page->Controls->Add(dr);
    Label^ t2 = Ui::Lbl("🎰  Rút thăm may mắn", 12.0f, true, Theme::Text);
    t2->Location = Drawing::Point(14, 12); dr->Controls->Add(t2);
    Label^ t3 = Ui::Lbl("Trúng khung hiếm hoặc ⭐ Plus! Giải đặc biệt 🍀 5000 💎 (tỉ lệ rất thấp).", 9.0f, false, Theme::Muted);
    t3->Location = Drawing::Point(14, 38); dr->Controls->Add(t3);
    Button^ drawBtn = Ui::AccentBtn("Rút ngay — " + (Store::PlusOn(Store::Me) ? "40 💎" : "50 💎"), 170, 38);
    drawBtn->Click += gcnew EventHandler(this, &ShopView::OnDraw);
    drawBtn->Location = Drawing::Point(cw - 190, 28);
    drawBtn->Enabled = Store::DrawEnabled();
    dr->Controls->Add(drawBtn);
    y += 108;

    // plus purchase
    Panel^ plus = gcnew Panel();
    plus->BackColor = Theme::Card;
    plus->Location = Drawing::Point(_padd, y);
    plus->Width = cw;
    _page->Controls->Add(plus);
    int py = 12;
    Label^ t4 = Ui::Lbl("⭐  Nâng cấp Plus", 11.0f, true, Theme::Text);
    t4->Location = Drawing::Point(14, py); plus->Controls->Add(t4); py += 30;
    for each (ShopItem^ it in Catalog::PlusItems)
    {
        Button^ b = Ui::Btn(it->Emo + "  " + it->Name + " — " + Ui::Str(it->Cost) + " 💎", 240, 34, Theme::Card2, Theme::Text, false);
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = Theme::Border;
        b->Tag = it->Id;
        b->Click += gcnew EventHandler(this, &ShopView::OnBuyPlus);
        b->Location = Drawing::Point(14, py);
        plus->Controls->Add(b);
        py += 40;
    }
    plus->Height = py + 6;
    y += plus->Height + 12;

    // item grid
    Label^ t5 = Ui::Lbl("🛍️  Cửa hàng Gems", 12.0f, true, Theme::Text);
    t5->Location = Drawing::Point(_padd, y); _page->Controls->Add(t5); y += 30;

    FlowLayoutPanel^ grid = gcnew FlowLayoutPanel();
    grid->FlowDirection = FlowDirection::LeftToRight;
    grid->WrapContents = true;
    grid->BackColor = Theme::Bg;
    grid->Location = Drawing::Point(_padd, y);
    grid->Width = cw;
    _page->Controls->Add(grid);
    grid->Controls->Clear();

    for each (ShopItem^ it in Catalog::Items)
    {
        Dictionary<String^, Object^>^ evIt = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::EvItems(), it->Id));
        bool on = it->On;
        if (evIt != nullptr && J::H(evIt, "on")) on = J::B(evIt, "on");
        int cost = it->Cost;
        if (evIt != nullptr && J::H(evIt, "cost")) cost = (int)J::N(evIt, "cost");
        bool owned = Store::Owns(Store::Me, it->Id);

        Panel^ card = gcnew Panel();
        card->BackColor = Theme::Card;
        card->Width = 196;
        card->Height = 132;
        card->Margin = Padding(0, 0, 10, 10);
        grid->Controls->Add(card);

        Label^ emo = Ui::Lbl(it->Emo, 22.0f, false, Theme::Text);
        emo->Location = Drawing::Point(12, 10); card->Controls->Add(emo);
        Label^ nm = Ui::Lbl(it->Name, 9.0f, true, Theme::Text);
        nm->AutoSize = false;
        nm->Width = 176;
        nm->Height = 30;
        nm->Location = Drawing::Point(8, 46); card->Controls->Add(nm);
        Label^ pr = Ui::Lbl(it->Limited ? "🎁 Giới hạn" : (owned ? "Đã sở hữu" : Ui::Str(cost) + " 💎"), 9.0f, true, owned ? Theme::Green : Theme::Accent);
        pr->Location = Drawing::Point(8, 78); card->Controls->Add(pr);
        if (on && !owned)
        {
            Button^ buy = Ui::Btn("Mua", 70, 28, Theme::Accent, Color::White, true);
            buy->Tag = it->Id;
            buy->Click += gcnew EventHandler(this, &ShopView::OnBuy);
            buy->Location = Drawing::Point(116, 96);
            card->Controls->Add(buy);
        }
        else if (owned)
        {
            Label^ have = Ui::Lbl("✅ Đã sở hữu", 8.5f, true, Theme::Green);
            have->Location = Drawing::Point(104, 100); card->Controls->Add(have);
        }
        else
        {
            Label^ so = Ui::Lbl("⛔ Ngừng bán", 8.5f, true, Theme::Danger);
            so->Location = Drawing::Point(108, 100); card->Controls->Add(so);
        }
    }

    int rows = (int)Math::Ceiling((double)Catalog::Items->Count / Math::Max(1, cw / 206));
    int gridH = rows * 142;
    grid->Height = gridH;
    y += gridH + 16;

    _page->Height = y + 12;
}

void ShopView::OnBuy(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ err = "";
    if (!Store::BuyItem((String^)b->Tag, err)) { Ui::Warn(err); return; }
    AppCtx::Win->RefreshTopbar();
    Toast::Show("Đã mua thành công! 🎉", true);
    Rebuild();
}

void ShopView::OnBuyPlus(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    ShopItem^ it = Catalog::FindItem((String^)b->Tag);
    if (it == nullptr) return;
    String^ msg = it->Type == "plus" && it->Idx == 0 ? "Mua ⭐ Plus Vĩnh Viễn với " + Ui::Str(it->Cost) + " 💎?" : "Mua ⭐ Plus " + it->Name + " với " + Ui::Str(it->Cost) + " 💎?";
    if (!Ui::Confirm(msg)) return;
    String^ err = "";
    if (!Store::BuyItem((String^)b->Tag, err)) { Ui::Warn(err); return; }
    AppCtx::Win->RefreshTopbar();
    Toast::Show("Chúc mừng bạn đã lên ⭐ Plus!", true);
    Rebuild();
}

void ShopView::OnDraw(Object^ s, EventArgs^)
{
    String^ err = "";
    Dictionary<String^, Object^>^ r = Store::DrawLucky(err);
    if (r == nullptr) { Ui::Warn(err); return; }
    AppCtx::Win->RefreshTopbar();
    if (J::B(r, "jackpot"))
        Ui::Info("🍀🍀🍀 JACKPOT!!! Bạn nhận được 5000 💎 Gems! 🍀🍀🍀");
    else if (J::B(r, "plus"))
        Ui::Info("⭐ Trúng thưởng: " + J::S(r, "name") + "! Bạn đã lên Plus!");
    else if (J::B(r, "none"))
        Ui::Info("😅 Chưa trúng lần này. Chúc bạn may mắn lần sau!");
    else
        Ui::Info("🎉 Chúc mừng! Bạn nhận được: " + J::S(r, "emo") + "  " + J::S(r, "name"));
    Rebuild();
}
