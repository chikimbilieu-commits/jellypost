#include "pch.h"
#include "Store.h"

Dictionary<String^, Object^>^ Store::Data;
String^ Store::Me;
String^ Store::DataPath;
String^ Store::SettingsPath;
Dictionary<String^, Object^>^ Store::Settings;

// JavaScriptSerializer::DeserializeObject returns JSON arrays as Object[],
// but the app stores arrays as ArrayList -> normalize the whole tree.
static Object^ NormJson(Object^ o)
{
    array<Object^>^ arr = dynamic_cast<array<Object^>^>(o);
    if (arr != nullptr)
    {
        ArrayList^ a = gcnew ArrayList();
        for (int i = 0; i < arr->Length; i++) a->Add(NormJson(arr[i]));
        return a;
    }
    Dictionary<String^, Object^>^ d = dynamic_cast<Dictionary<String^, Object^>^>(o);
    if (d != nullptr)
    {
        array<String^>^ keys = gcnew array<String^>(d->Count);
        d->Keys->CopyTo(keys, 0);
        for (int i = 0; i < keys->Length; i++) d[keys[i]] = NormJson(d[keys[i]]);
        return d;
    }
    return o;
}

// ---------------- file / settings ----------------
String^ Store::DataDir()
{
    return Path::Combine(Environment::GetFolderPath(Environment::SpecialFolder::ApplicationData), "JellyPost");
}

void Store::SaveSettings()
{
    try
    {
        JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
        File::WriteAllText(Store::SettingsPath, ser->Serialize(Store::Settings), Encoding::UTF8);
    }
    catch (Exception^) { }
}

void Store::Save()
{
    try
    {
        JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
        ser->MaxJsonLength = 500 * 1024 * 1024;
        String^ json = ser->Serialize(Store::Data);
        String^ tmp = Store::DataPath + ".tmp";
        File::WriteAllText(tmp, json, Encoding::UTF8);
        if (File::Exists(Store::DataPath)) File::Delete(Store::DataPath);
        File::Move(tmp, Store::DataPath);
    }
    catch (Exception^) { }
}

String^ Store::ExportJson()
{
    JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
    ser->MaxJsonLength = 500 * 1024 * 1024;
    return ser->Serialize(Store::Data);
}

void Store::EnsureUser(Dictionary<String^, Object^>^ u)
{
    if (u == nullptr) return;
    if (!J::H(u, "d")) J::P(u, "d", "");
    if (!J::H(u, "b")) J::P(u, "b", "");
    if (!J::H(u, "a")) J::P(u, "a", 0);
    if (!J::H(u, "ai")) J::P(u, "ai", "");
    if (!J::H(u, "bn")) J::P(u, "bn", "");
    if (!J::H(u, "s")) J::P(u, "s", "");
    if (!J::H(u, "h")) J::P(u, "h", "");
    if (!J::H(u, "m")) J::P(u, "m", false);
    if (!J::H(u, "st")) J::P(u, "st", false);
    if (!J::H(u, "j")) J::P(u, "j", Utils::Now());
    if (!J::H(u, "k")) J::P(u, "k", false);
    if (!J::H(u, "plus")) J::P(u, "plus", false);
    if (!J::H(u, "dec")) J::P(u, "dec", 0);
    if (!J::H(u, "peff")) J::P(u, "peff", 0);
    if (!J::H(u, "nc")) J::P(u, "nc", "");
    if (!J::H(u, "ne")) J::P(u, "ne", 0);
    if (!J::H(u, "nf")) J::P(u, "nf", 0);
    if (!J::H(u, "g")) J::P(u, "g", "");
    if (!J::H(u, "gems")) J::P(u, "gems", 0LL);
    if (!J::H(u, "own")) J::P(u, "own", gcnew Dictionary<String^, Object^>());
    if (!J::H(u, "sv")) J::P(u, "sv", gcnew ArrayList());
}

void Store::Seed()
{
    Dictionary<String^, Object^>^ users = Store::Users();
    if (users->Count == 0)
    {
        String^ salt = Utils::RandSalt();
        Dictionary<String^, Object^>^ adm = gcnew Dictionary<String^, Object^>();
        J::P(adm, "d", "Jelly Post");
        J::P(adm, "b", "Tài khoản chính thức của Jelly Post 💜 (bản Windows)");
        J::P(adm, "a", 1); J::P(adm, "ai", ""); J::P(adm, "bn", "");
        J::P(adm, "pin", gcnew ArrayList()); J::P(adm, "sv", gcnew ArrayList());
        J::P(adm, "s", salt); J::P(adm, "h", Utils::HashPw("jellypost", salt));
        J::P(adm, "m", true); J::P(adm, "st", false);
        J::P(adm, "j", Utils::Now()); J::P(adm, "k", false);
        J::P(adm, "plus", true); J::P(adm, "plusEnd", 0LL); J::P(adm, "trial", false);
        J::P(adm, "dec", 1); J::P(adm, "peff", 1); J::P(adm, "nc", ""); J::P(adm, "ne", 0); J::P(adm, "nf", 0);
        J::P(adm, "g", ""); J::P(adm, "gems", 500LL);
        J::P(adm, "own", gcnew Dictionary<String^, Object^>());
        users["jellypost"] = adm;
    }
    for each (KeyValuePair<String^, Object^> kv in users)
    {
        Dictionary<String^, Object^>^ u = dynamic_cast<Dictionary<String^, Object^>^>(kv.Value);
        Store::EnsureUser(u);
    }
}

void Store::Load()
{
    Catalog::Init();
    Theme::Set(true);
    String^ dir = Store::DataDir();
    Directory::CreateDirectory(dir);
    Store::DataPath = Path::Combine(dir, "data.json");
    Store::SettingsPath = Path::Combine(dir, "settings.json");
    Store::Settings = gcnew Dictionary<String^, Object^>();

    try
    {
        if (File::Exists(Store::SettingsPath))
        {
            JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
            Object^ o = NormJson(ser->DeserializeObject(File::ReadAllText(Store::SettingsPath)));
            Dictionary<String^, Object^>^ s = dynamic_cast<Dictionary<String^, Object^>^>(o);
            if (s != nullptr)
            {
                Store::Settings = s;
                bool dark = J::B(Store::Settings, "dark");
                Theme::Set(dark);
            }
        }
    }
    catch (Exception^) { }

    bool loaded = false;
    try
    {
        if (File::Exists(Store::DataPath))
        {
            JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
            ser->MaxJsonLength = 500 * 1024 * 1024;
            Object^ o = NormJson(ser->DeserializeObject(File::ReadAllText(Store::DataPath)));
            Dictionary<String^, Object^>^ d = dynamic_cast<Dictionary<String^, Object^>^>(o);
            if (d != nullptr) { Store::Data = d; Store::Seed(); loaded = true; }
        }
    }
    catch (Exception^) { }

    if (!loaded)
    {
        Store::Data = gcnew Dictionary<String^, Object^>();
        J::P(Store::Data, "v", 1);
        J::P(Store::Data, "n", 1);
        J::P(Store::Data, "users", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "posts", gcnew ArrayList());
        J::P(Store::Data, "msgs", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "rd", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "notifs", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "friends", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "ev", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "mcEv", gcnew Dictionary<String^, Object^>());
        J::P(Store::Data, "drawLog", gcnew ArrayList());
        J::P(Store::Data, "drawN", 1);
        J::P(Store::Data, "evItems", gcnew Dictionary<String^, Object^>());
        Store::Seed();
        Store::Save();
    }

    // restore session
    String^ u = J::S(Store::Settings, "user");
    if (u != "" && Store::Exists(u) && !J::B(Store::User(u), "k")) Store::Me = u;
}

bool Store::ImportJson(String^ json, String^% err)
{
    try
    {
        JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
        ser->MaxJsonLength = 500 * 1024 * 1024;
        Object^ o = NormJson(ser->DeserializeObject(json));
        Dictionary<String^, Object^>^ d = dynamic_cast<Dictionary<String^, Object^>^>(o);
        if (d == nullptr) { err = "File không đúng định dạng dữ liệu Jelly Post"; return false; }
        Dictionary<String^, Object^>^ srcU = dynamic_cast<Dictionary<String^, Object^>^>(J::G(d, "users"));
        if (srcU != nullptr)
        {
            Dictionary<String^, Object^>^ dstU = Store::Users();
            for each (KeyValuePair<String^, Object^> kv in srcU)
                if (!dstU->ContainsKey(kv.Key)) dstU[kv.Key] = kv.Value;
        }
        ArrayList^ srcP = dynamic_cast<ArrayList^>(J::G(d, "posts"));
        if (srcP != nullptr)
            for each (Object^ p in srcP) Store::Posts()->Add(p);
        Dictionary<String^, Object^>^ srcM = dynamic_cast<Dictionary<String^, Object^>^>(J::G(d, "msgs"));
        if (srcM != nullptr)
        {
            Dictionary<String^, Object^>^ dstM = J::M(Store::Data, "msgs");
            for each (KeyValuePair<String^, Object^> kv in srcM)
                if (!dstM->ContainsKey(kv.Key)) dstM[kv.Key] = kv.Value;
        }
        Dictionary<String^, Object^>^ srcN = dynamic_cast<Dictionary<String^, Object^>^>(J::G(d, "notifs"));
        if (srcN != nullptr)
        {
            Dictionary<String^, Object^>^ dstN = J::M(Store::Data, "notifs");
            for each (KeyValuePair<String^, Object^> kv in srcN)
                if (!dstN->ContainsKey(kv.Key)) dstN[kv.Key] = kv.Value;
        }
        Dictionary<String^, Object^>^ srcF = dynamic_cast<Dictionary<String^, Object^>^>(J::G(d, "friends"));
        if (srcF != nullptr)
        {
            Dictionary<String^, Object^>^ dstF = J::M(Store::Data, "friends");
            for each (KeyValuePair<String^, Object^> kv in srcF)
                if (!dstF->ContainsKey(kv.Key)) dstF[kv.Key] = kv.Value;
        }
        if (J::N(d, "n") > J::N(Store::Data, "n")) J::PN(Store::Data, "n", J::N(d, "n"));
        Store::Seed();
        Store::Save();
        return true;
    }
    catch (Exception^ ex) { err = ex->Message; return false; }
}

// ---------------- collections ----------------
Dictionary<String^, Object^>^ Store::Users() { return J::M(Store::Data, "users"); }
ArrayList^ Store::Posts() { return J::L(Store::Data, "posts"); }
Dictionary<String^, Object^>^ Store::Msgs() { return J::M(Store::Data, "msgs"); }
Dictionary<String^, Object^>^ Store::Rd() { return J::M(Store::Data, "rd"); }
Dictionary<String^, Object^>^ Store::NotifsDict() { return J::M(Store::Data, "notifs"); }
Dictionary<String^, Object^>^ Store::Friends() { return J::M(Store::Data, "friends"); }
Dictionary<String^, Object^>^ Store::EventCfg() { return J::M(Store::Data, "ev"); }
Dictionary<String^, Object^>^ Store::McCfg() { return J::M(Store::Data, "mcEv"); }
Dictionary<String^, Object^>^ Store::EvItems() { return J::M(Store::Data, "evItems"); }

// ---------------- users / session ----------------
Dictionary<String^, Object^>^ Store::User(String^ u)
{
    if (String::IsNullOrEmpty(u)) return nullptr;
    Object^ v = nullptr;
    if (Store::Users()->TryGetValue(u, v)) return dynamic_cast<Dictionary<String^, Object^>^>(v);
    return nullptr;
}
Dictionary<String^, Object^>^ Store::MeObj() { return Store::User(Store::Me); }
bool Store::Exists(String^ u) { return Store::User(u) != nullptr; }
int Store::UserCount() { return Store::Users()->Count; }
long long Store::NextId()
{
    long long n = J::N(Store::Data, "n");
    if (n < 1) n = 1;
    J::PN(Store::Data, "n", n + 1);
    return n;
}

String^ Store::Register(String^ u, String^ pw, String^ d, int av, String^% err)
{
    u = u->ToLowerInvariant();
    if (!Utils::ValidUsername(u)) { err = "Tên đăng nhập: 3-20 ký tự, chỉ a-z, 0-9, _ và ."; return nullptr; }
    if (pw->Length < 4 || pw->Length > 64) { err = "Mật khẩu phải dài 4-64 ký tự"; return nullptr; }
    if (Store::Exists(u)) { err = "Tên đăng nhập đã tồn tại"; return nullptr; }
    String^ salt = Utils::RandSalt();
    Dictionary<String^, Object^>^ usr = gcnew Dictionary<String^, Object^>();
    J::P(usr, "d", d); J::P(usr, "b", ""); J::P(usr, "a", av);
    J::P(usr, "ai", ""); J::P(usr, "bn", "");
    J::P(usr, "pin", gcnew ArrayList()); J::P(usr, "sv", gcnew ArrayList());
    J::P(usr, "s", salt); J::P(usr, "h", Utils::HashPw(pw, salt));
    J::P(usr, "m", false); J::P(usr, "st", false);
    J::P(usr, "j", Utils::Now()); J::P(usr, "k", false);
    J::P(usr, "plus", false); J::P(usr, "trial", true);
    J::P(usr, "dec", 0); J::P(usr, "peff", 0); J::P(usr, "nc", ""); J::P(usr, "ne", 0); J::P(usr, "nf", 0);
    J::P(usr, "g", ""); J::P(usr, "gems", 0LL);
    J::P(usr, "own", gcnew Dictionary<String^, Object^>());
    Store::Users()[u] = usr;
    Store::Save();
    Store::SetSession(u);
    return u;
}

String^ Store::Login(String^ u, String^ pw, String^% err)
{
    u = u->ToLowerInvariant();
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr) { err = "Sai tên đăng nhập hoặc mật khẩu"; return nullptr; }
    String^ salt = J::S(usr, "s");
    if (J::S(usr, "h") != Utils::HashPw(pw, salt)) { err = "Sai tên đăng nhập hoặc mật khẩu"; return nullptr; }
    if (J::B(usr, "k")) { err = "Tài khoản này đã bị cấm"; return nullptr; }
    Store::SetSession(u);
    return u;
}

void Store::SetSession(String^ u)
{
    Store::Me = u;
    J::P(Store::Settings, "user", u);
    Store::SaveSettings();
}
void Store::ClearSession()
{
    Store::Me = nullptr;
    J::P(Store::Settings, "user", "");
    Store::SaveSettings();
}
bool Store::HasSession()
{
    return Store::Me != nullptr && Store::Exists(Store::Me) && !J::B(Store::User(Store::Me), "k");
}

bool Store::IsMod(String^ u)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    return usr != nullptr && (J::B(usr, "m") || J::B(usr, "st"));
}

// ---------------- profile ----------------
bool Store::ChangePw(String^ oldPw, String^ newPw, String^% err)
{
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    if (usr == nullptr) { err = "Phiên đã hết hạn"; return false; }
    String^ salt = J::S(usr, "s");
    if (J::S(usr, "h") != Utils::HashPw(oldPw, salt)) { err = "Mật khẩu hiện tại không đúng"; return false; }
    if (newPw->Length < 4 || newPw->Length > 64) { err = "Mật khẩu mới phải dài 4-64 ký tự"; return false; }
    String^ ns = Utils::RandSalt();
    J::P(usr, "s", ns);
    J::P(usr, "h", Utils::HashPw(newPw, ns));
    J::P(usr, "pwChg", Utils::Now());
    Store::Save();
    return true;
}

void Store::SetCosmetic(String^ kind, int val)
{
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    if (usr == nullptr) return;
    if (kind == "dec") J::P(usr, "dec", val);
    else if (kind == "peff") J::P(usr, "peff", val);
    Store::Save();
}

// ---------------- posts ----------------
Dictionary<String^, Object^>^ Store::PostById(long long id)
{
    ArrayList^ posts = Store::Posts();
    for (int i = 0; i < posts->Count; i++)
    {
        Dictionary<String^, Object^>^ p = dynamic_cast<Dictionary<String^, Object^>^>(posts[i]);
        if (p != nullptr && J::N(p, "i") == id) return p;
    }
    return nullptr;
}

static ArrayList^ ParseMentions(String^ text, String^ author)
{
    ArrayList^ out = gcnew ArrayList();
    if (String::IsNullOrEmpty(text)) return out;
    for (int i = 0; i < text->Length; i++)
    {
        if (text[i] != '@') continue;
        int j = i + 1;
        StringBuilder^ sb = gcnew StringBuilder();
        while (j < text->Length)
        {
            Char c = text[j];
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '.')
            {
                sb->Append(c); j++;
                if (sb->Length >= 20) break;
            }
            else break;
        }
        if (sb->Length >= 3)
        {
            String^ name = sb->ToString()->ToLowerInvariant();
            if (name != author && Store::Exists(name) && !out->Contains(name)) out->Add(name);
        }
    }
    return out;
}

Dictionary<String^, Object^>^ Store::AddPost(String^ text, ArrayList^ imgs, bool ns, long long% newId)
{
    Dictionary<String^, Object^>^ p = gcnew Dictionary<String^, Object^>();
    newId = Store::NextId();
    J::P(p, "i", newId);
    J::P(p, "a", Store::Me);
    J::P(p, "t", text);
    J::P(p, "x", Utils::Now());
    J::P(p, "R", gcnew Dictionary<String^, Object^>());
    J::P(p, "sh", gcnew ArrayList());
    J::P(p, "c", gcnew ArrayList());
    J::P(p, "imgs", imgs == nullptr ? gcnew ArrayList() : imgs);
    J::P(p, "ns", ns);
    Store::Posts()->Add(p);

    ArrayList^ m = ParseMentions(text, Store::Me);
    if (m->Count > 0)
    {
        J::P(p, "m", m);
        for (int i = 0; i < m->Count; i++)
        {
            Dictionary<String^, Object^>^ n = gcnew Dictionary<String^, Object^>();
            J::P(n, "t", "mention"); J::P(n, "f", Store::Me); J::P(n, "pid", newId);
            J::P(n, "sn", text->Length > 60 ? text->Substring(0, 60) : text);
            Store::Notify((String^)m[i], n);
        }
    }
    Store::TryQuest("p", 1);
    Store::GiveMcDirect(Store::Me, 3, "post", 20);
    Store::Save();
    return p;
}

bool Store::DeletePost(long long id)
{
    ArrayList^ posts = Store::Posts();
    for (int i = 0; i < posts->Count; i++)
    {
        Dictionary<String^, Object^>^ p = dynamic_cast<Dictionary<String^, Object^>^>(posts[i]);
        if (p != nullptr && J::N(p, "i") == id)
        {
            String^ author = J::S(p, "a");
            bool canDelete = author == Store::Me || Store::IsMod(Store::Me);
            if (!canDelete) return false;
            posts->RemoveAt(i);
            Store::Save();
            return true;
        }
    }
    return false;
}

bool Store::EditPost(long long id, String^ text)
{
    Dictionary<String^, Object^>^ p = Store::PostById(id);
    if (p == nullptr) return false;
    if (J::S(p, "a") != Store::Me && !Store::IsMod(Store::Me)) return false;
    J::P(p, "t", text);
    Store::Save();
    return true;
}

Dictionary<String^, Object^>^ Store::AddComment(long long pid, String^ text, long long% cid)
{
    Dictionary<String^, Object^>^ post = Store::PostById(pid);
    if (post == nullptr) return nullptr;
    Dictionary<String^, Object^>^ cm = gcnew Dictionary<String^, Object^>();
    cid = Store::NextId();
    J::P(cm, "i", cid); J::P(cm, "a", Store::Me); J::P(cm, "t", text); J::P(cm, "x", Utils::Now());
    J::L(post, "c")->Add(cm);
    String^ author = J::S(post, "a");
    if (author != Store::Me)
    {
        Dictionary<String^, Object^>^ n = gcnew Dictionary<String^, Object^>();
        J::P(n, "t", "cmt"); J::P(n, "f", Store::Me); J::P(n, "pid", pid);
        J::P(n, "sn", text->Length > 60 ? text->Substring(0, 60) : text);
        Store::Notify(author, n);
    }
    Store::TryQuest("r", 1);
    Store::GiveMcDirect(Store::Me, 2, "cmt", 30);
    Store::Save();
    return cm;
}

bool Store::DeleteComment(long long pid, long long cid)
{
    Dictionary<String^, Object^>^ post = Store::PostById(pid);
    if (post == nullptr) return false;
    ArrayList^ c = J::L(post, "c");
    for (int i = 0; i < c->Count; i++)
    {
        Dictionary<String^, Object^>^ cm = dynamic_cast<Dictionary<String^, Object^>^>(c[i]);
        if (cm != nullptr && J::N(cm, "i") == cid)
        {
            String^ author = J::S(cm, "a");
            if (author != Store::Me && !Store::IsMod(Store::Me)) return false;
            c->RemoveAt(i);
            Store::Save();
            return true;
        }
    }
    return false;
}

bool Store::ToggleReact(long long pid, String^ emo)
{
    Dictionary<String^, Object^>^ post = Store::PostById(pid);
    if (post == nullptr) return false;
    Dictionary<String^, Object^>^ R = J::M(post, "R");
    ArrayList^ arr = R->ContainsKey(emo) ? dynamic_cast<ArrayList^>(R[emo]) : nullptr;
    bool added;
    if (arr != nullptr && arr->Contains(Store::Me))
    {
        arr->Remove(Store::Me);
        if (arr->Count == 0) R->Remove(emo);
        added = false;
    }
    else
    {
        List<String^>^ keys = gcnew List<String^>();
        for each (KeyValuePair<String^, Object^> kv in R)
        {
            ArrayList^ a = dynamic_cast<ArrayList^>(kv.Value);
            if (a != nullptr && a->Contains(Store::Me)) keys->Add(kv.Key);
        }
        for each (String^ k in keys)
        {
            ArrayList^ a = (ArrayList^)R[k];
            a->Remove(Store::Me);
            if (a->Count == 0) R->Remove(k);
        }
        if (arr == nullptr) { arr = gcnew ArrayList(); R[emo] = arr; }
        arr->Add(Store::Me);
        added = true;

        String^ author = J::S(post, "a");
        if (author != Store::Me)
        {
            Dictionary<String^, Object^>^ n = gcnew Dictionary<String^, Object^>();
            J::P(n, "t", "like"); J::P(n, "f", Store::Me); J::P(n, "pid", pid); J::P(n, "e", emo);
            Store::Notify(author, n);
            Dictionary<String^, Object^>^ g = Store::TryQuest("g", 1);
            if (g != nullptr)
            {
                Dictionary<String^, Object^>^ gn = gcnew Dictionary<String^, Object^>();
                J::P(gn, "t", "gem"); J::P(gn, "f", Store::Me);
                J::P(gn, "n", J::N(g, "reward")); J::P(gn, "lab", J::S(g, "label")); J::P(gn, "emo", J::S(g, "emo"));
                Store::Notify(author, gn);
            }
            Store::GiveMcDirect(author, 2, "got", 30);
        }
        Store::TryQuest("r", 1);
    }
    Store::Save();
    return added;
}

bool Store::ToggleSave(long long pid)
{
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    if (usr == nullptr) return false;
    ArrayList^ sv = J::L(usr, "sv");
    bool saved;
    if (sv->Contains(pid)) { sv->Remove(pid); saved = false; }
    else { sv->Add(pid); saved = true; }
    Store::Save();
    return saved;
}

ArrayList^ Store::SavedPosts()
{
    ArrayList^ sv = J::L(Store::MeObj(), "sv");
    ArrayList^ out = gcnew ArrayList();
    for (int i = sv->Count - 1; i >= 0; i--)
    {
        long long pid = (long long)Convert::ToInt64(sv[i]);
        Dictionary<String^, Object^>^ p = Store::PostById(pid);
        if (p != nullptr) out->Add(p);
    }
    return out;
}

// ---------------- chat ----------------
ArrayList^ Store::GetConvs()
{
    ArrayList^ out = gcnew ArrayList();
    Dictionary<String^, Object^>^ msgs = Store::Msgs();
    for each (KeyValuePair<String^, Object^> kv in msgs)
    {
        array<String^>^ parts = kv.Key->Split('|');
        if (parts->Length != 2) continue;
        if (parts[0] != Store::Me && parts[1] != Store::Me) continue;
        String^ other = parts[0] == Store::Me ? parts[1] : parts[0];
        if (!Store::Exists(other)) continue;
        Dictionary<String^, Object^>^ conv = gcnew Dictionary<String^, Object^>();
        J::P(conv, "other", other);
        ArrayList^ arr = dynamic_cast<ArrayList^>(kv.Value);
        Dictionary<String^, Object^>^ last = (arr != nullptr && arr->Count > 0) ? dynamic_cast<Dictionary<String^, Object^>^>(arr[arr->Count - 1]) : nullptr;
        J::P(conv, "last", last == nullptr ? "" : J::S(last, "t"));
        J::P(conv, "lastAt", last == nullptr ? 0LL : J::N(last, "x"));
        Dictionary<String^, Object^>^ mk = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::Rd(), kv.Key));
        long long since = mk == nullptr ? 0 : J::N(mk, Store::Me);
        int unread = 0;
        if (arr != nullptr)
            for (int i = 0; i < arr->Count; i++)
            {
                Dictionary<String^, Object^>^ m = dynamic_cast<Dictionary<String^, Object^>^>(arr[i]);
                if (m != nullptr && J::S(m, "f") != Store::Me && J::N(m, "x") > since) unread++;
            }
        J::P(conv, "unread", unread);
        out->Add(conv);
    }
    // insertion sort by lastAt desc
    for (int i = 1; i < out->Count; i++)
    {
        Object^ x = out[i];
        long long xAt = J::N((Dictionary<String^, Object^>^)x, "lastAt");
        int j = i - 1;
        while (j >= 0 && J::N((Dictionary<String^, Object^>^)out[j], "lastAt") < xAt) { out[j + 1] = out[j]; j--; }
        out[j + 1] = x;
    }
    return out;
}

ArrayList^ Store::GetMsgs(String^ other)
{
    array<String^>^ names = gcnew array<String^> { Store::Me, other };
    Array::Sort(names);
    String^ key = String::Join("|", names);
    Object^ v = J::G(Store::Msgs(), key);
    ArrayList^ arr = dynamic_cast<ArrayList^>(v);
    Dictionary<String^, Object^>^ mk = J::M(Store::Rd(), key);
    J::PN(mk, Store::Me, Utils::Now());
    Store::Save();
    ArrayList^ out = gcnew ArrayList();
    if (arr != nullptr)
        for (int i = Math::Max(0, arr->Count - 100); i < arr->Count; i++) out->Add(arr[i]);
    return out;
}

bool Store::SendMsg(String^ to, String^ text)
{
    if (to == Store::Me) return false;
    if (String::IsNullOrEmpty(text)) return false;
    if (!Store::Exists(to)) return false;
    array<String^>^ names = gcnew array<String^> { Store::Me, to };
    Array::Sort(names);
    String^ key = String::Join("|", names);
    ArrayList^ arr = J::L(Store::Msgs(), key);
    Dictionary<String^, Object^>^ m = gcnew Dictionary<String^, Object^>();
    J::P(m, "f", Store::Me); J::P(m, "t", text); J::P(m, "x", Utils::Now());
    arr->Add(m);
    Dictionary<String^, Object^>^ mk = J::M(Store::Rd(), key);
    J::PN(mk, Store::Me, Utils::Now());
    Store::Save();
    return true;
}

int Store::UnreadTotal()
{
    int n = 0;
    Dictionary<String^, Object^>^ msgs = Store::Msgs();
    for each (KeyValuePair<String^, Object^> kv in msgs)
    {
        array<String^>^ parts = kv.Key->Split('|');
        if (parts->Length != 2) continue;
        if (parts[0] != Store::Me && parts[1] != Store::Me) continue;
        ArrayList^ arr = dynamic_cast<ArrayList^>(kv.Value);
        if (arr == nullptr) continue;
        Dictionary<String^, Object^>^ mk = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::Rd(), kv.Key));
        long long since = mk == nullptr ? 0 : J::N(mk, Store::Me);
        for (int i = 0; i < arr->Count; i++)
        {
            Dictionary<String^, Object^>^ m = dynamic_cast<Dictionary<String^, Object^>^>(arr[i]);
            if (m != nullptr && J::S(m, "f") != Store::Me && J::N(m, "x") > since) n++;
        }
    }
    return n;
}

// ---------------- notifications ----------------
ArrayList^ Store::Notifs()
{
    if (Store::Me == nullptr) return gcnew ArrayList();
    Dictionary<String^, Object^>^ nf = Store::NotifsDict();
    Object^ v = J::G(nf, Store::Me);
    ArrayList^ arr = dynamic_cast<ArrayList^>(v);
    if (arr == nullptr) { arr = gcnew ArrayList(); nf[Store::Me] = arr; }
    return arr;
}
void Store::Notify(String^ u, Dictionary<String^, Object^>^ n)
{
    if (String::IsNullOrEmpty(u) || n == nullptr) return;
    J::P(n, "i", Store::NextId());
    J::P(n, "x", Utils::Now());
    Dictionary<String^, Object^>^ nf = Store::NotifsDict();
    ArrayList^ arr = dynamic_cast<ArrayList^>(J::G(nf, u));
    if (arr == nullptr) { arr = gcnew ArrayList(); nf[u] = arr; }
    arr->Add(n);
    while (arr->Count > 40) arr->RemoveAt(0);
}
int Store::UnreadNotifs()
{
    long long seen = J::N(Store::Settings, "lastNotifSeen");
    int n = 0;
    ArrayList^ list = Store::Notifs();
    for (int i = 0; i < list->Count; i++)
    {
        Dictionary<String^, Object^>^ nn = dynamic_cast<Dictionary<String^, Object^>^>(list[i]);
        if (nn != nullptr && J::N(nn, "x") > seen) n++;
    }
    return n;
}
void Store::MarkNotifsSeen()
{
    J::PN(Store::Settings, "lastNotifSeen", Utils::Now());
    Store::SaveSettings();
}

// ---------------- friends ----------------
bool Store::SendReq(String^ to)
{
    if (to == Store::Me || !Store::Exists(to)) return false;
    Dictionary<String^, Object^>^ me = J::M(Store::Friends(), Store::Me);
    ArrayList^ out = J::L(me, "out");
    if (out->Contains(to)) return false;
    out->Add(to);
    Dictionary<String^, Object^>^ th = J::M(Store::Friends(), to);
    J::L(th, "in")->Add(Store::Me);
    Dictionary<String^, Object^>^ n = gcnew Dictionary<String^, Object^>();
    J::P(n, "t", "req"); J::P(n, "f", Store::Me);
    Store::Notify(to, n);
    Store::Save();
    return true;
}
bool Store::AcceptReq(String^ from)
{
    Dictionary<String^, Object^>^ me = J::M(Store::Friends(), Store::Me);
    J::L(me, "in")->Remove(from);
    J::L(me, "out")->Add(from);
    Dictionary<String^, Object^>^ th = J::M(Store::Friends(), from);
    J::L(th, "out")->Add(Store::Me);
    J::L(th, "in")->Remove(Store::Me);
    Dictionary<String^, Object^>^ n = gcnew Dictionary<String^, Object^>();
    J::P(n, "t", "reqok"); J::P(n, "f", Store::Me);
    Store::Notify(from, n);
    Store::Save();
    return true;
}
bool Store::RejectReq(String^ from)
{
    Dictionary<String^, Object^>^ me = J::M(Store::Friends(), Store::Me);
    J::L(me, "in")->Remove(from);
    Dictionary<String^, Object^>^ th = J::M(Store::Friends(), from);
    J::L(th, "out")->Remove(Store::Me);
    Store::Save();
    return true;
}
bool Store::RemoveFriend(String^ u)
{
    Dictionary<String^, Object^>^ me = J::M(Store::Friends(), Store::Me);
    J::L(me, "out")->Remove(u);
    Dictionary<String^, Object^>^ th = J::M(Store::Friends(), u);
    J::L(th, "out")->Remove(Store::Me);
    J::L(th, "in")->Remove(Store::Me);
    Store::Save();
    return true;
}
String^ Store::Rel(String^ a, String^ b)
{
    Dictionary<String^, Object^>^ A = J::M(Store::Friends(), a);
    Dictionary<String^, Object^>^ B = J::M(Store::Friends(), b);
    bool aOutB = J::L(A, "out")->Contains(b);
    bool bOutA = J::L(B, "out")->Contains(a);
    if (aOutB && bOutA) return "friend";
    if (J::L(A, "in")->Contains(b)) return "in";
    if (aOutB) return "out";
    return "none";
}

// ---------------- economy ----------------
long long Store::Gems(String^ u)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    return usr == nullptr ? 0 : J::N(usr, "gems");
}
bool Store::Owns(String^ u, String^ id)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr) return false;
    Dictionary<String^, Object^>^ own = dynamic_cast<Dictionary<String^, Object^>^>(J::G(usr, "own"));
    return own != nullptr && own->ContainsKey(id);
}
void Store::Grant(String^ u, String^ id)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr) return;
    Dictionary<String^, Object^>^ own = J::M(usr, "own");
    own[id] = 1;
}
bool Store::EventEnabled()
{
    Dictionary<String^, Object^>^ ev = Store::EventCfg();
    return !J::H(ev, "enabled") || J::B(ev, "enabled");
}
bool Store::DrawEnabled()
{
    Dictionary<String^, Object^>^ ev = Store::EventCfg();
    return !J::H(ev, "drawEnabled") || J::B(ev, "drawEnabled");
}
bool Store::McEnabled()
{
    Dictionary<String^, Object^>^ ev = Store::McCfg();
    return !J::H(ev, "enabled") || J::B(ev, "enabled");
}

bool Store::PlusOn(String^ u)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    return Store::UserPlus(usr);
}
bool Store::UserPlus(Dictionary<String^, Object^>^ usr)
{
    if (usr == nullptr) return false;
    if (!J::B(usr, "plus")) return false;
    long long pe = J::N(usr, "plusEnd");
    if (pe == 0) return true;
    if (Utils::Now() >= pe) { J::P(usr, "plus", false); Store::Save(); return false; }
    return true;
}
long long Store::PlusEndMs(String^ u)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr || !J::B(usr, "plus")) return 0;
    long long pe = J::N(usr, "plusEnd");
    return pe;
}
void Store::GrantPlus(String^ u, int days)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr) return;
    long long now = Utils::Now();
    if (days <= 0)
    {
        J::P(usr, "plus", true); J::P(usr, "plusEnd", 0LL);
        if (!J::H(usr, "ps")) J::P(usr, "ps", now);
    }
    else
    {
        long long base = Math::Max(now, J::N(usr, "plusEnd"));
        J::PN(usr, "plusEnd", base + (long long)days * 86400000LL);
        J::P(usr, "plus", true);
        if (!J::H(usr, "ps")) J::P(usr, "ps", now);
    }
    Store::Save();
}
int Store::DisplayDec(Dictionary<String^, Object^>^ u)
{
    int dec = (int)J::N(u, "dec");
    if (dec <= 0) return 0;
    if (Store::UserPlus(u)) return dec;
    if (Store::Owns(Store::Me, "dec" + Ui::Str(dec))) return dec;
    return 0;
}
int Store::DisplayPf(Dictionary<String^, Object^>^ u)
{
    int pf = (int)J::N(u, "peff");
    if (pf <= 0) return 0;
    if (Store::UserPlus(u)) return pf;
    if (pf > 10 && Store::Owns(Store::Me, "pf" + Ui::Str(pf))) return pf;
    return 0;
}

static Dictionary<String^, Object^>^ McS(Dictionary<String^, Object^>^ usr)
{
    long long day = Utils::Now() / 86400000LL;
    Dictionary<String^, Object^>^ s = dynamic_cast<Dictionary<String^, Object^>^>(J::G(usr, "mcs"));
    if (s == nullptr || J::N(s, "d") != day)
    {
        s = gcnew Dictionary<String^, Object^>();
        J::P(s, "d", day); J::P(s, "post", 0); J::P(s, "like", 0); J::P(s, "cmt", 0); J::P(s, "got", 0); J::P(s, "q", 0);
        J::P(usr, "mcs", s);
    }
    return s;
}

long long Store::GiveMcDirect(String^ u, long long n, String^ key, int cap)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (!Store::McEnabled() || usr == nullptr || J::B(usr, "k")) return 0;
    Dictionary<String^, Object^>^ s = McS(usr);
    long long c = J::N(s, key);
    if (cap > 0 && c >= cap) return 0;
    J::PN(s, key, c + 1);
    long long amt = (long long)Math::Round(n * (Store::UserPlus(usr) ? 1.5 : 1.0));
    if (amt < 1) amt = 1;
    J::PN(usr, "mc", J::N(usr, "mc") + amt);
    J::PN(usr, "mcTot", J::N(usr, "mcTot") + amt);
    return amt;
}

long long Store::McBalance(String^ u)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    return usr == nullptr ? 0 : J::N(usr, "mc");
}

Dictionary<String^, Object^>^ Store::McDailyLogin(String^% msg)
{
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    if (usr == nullptr) return nullptr;
    long long today = Utils::Now() / 86400000LL;
    if (J::N(usr, "mcLoginDay") == today) { msg = "Bạn đã điểm danh hôm nay rồi 🌕"; return nullptr; }
    long long streak = 1;
    if (J::N(usr, "mcStreakLast") == today - 1) streak = J::N(usr, "mcStreak") + 1;
    J::PN(usr, "mcStreak", streak);
    J::PN(usr, "mcStreakLast", today);
    J::PN(usr, "mcLoginDay", today);
    long long gained = Store::GiveMcDirect(Store::Me, 5, "login", 0);
    long long bonus = 0;
    if (streak % 7 == 0) bonus = Store::GiveMcDirect(Store::Me, 50, "login", 0);
    Store::Save();
    Dictionary<String^, Object^>^ r = gcnew Dictionary<String^, Object^>();
    J::P(r, "gained", gained); J::P(r, "bonus", bonus); J::P(r, "streak", streak);
    return r;
}

Dictionary<String^, Object^>^ Store::TryQuest(String^ qk, int add)
{
    if (!Store::EventEnabled()) return nullptr;
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    if (usr == nullptr) return nullptr;
    long long day = Utils::Now() / 86400000LL;
    Dictionary<String^, Object^>^ qs = dynamic_cast<Dictionary<String^, Object^>^>(J::G(usr, "qs"));
    if (qs == nullptr || J::N(qs, "d") != day)
    {
        qs = gcnew Dictionary<String^, Object^>();
        J::P(qs, "d", day); J::P(qs, "p", 0); J::P(qs, "r", 0); J::P(qs, "g", 0);
        J::P(qs, "pd", false); J::P(qs, "rd", false); J::P(qs, "gd", false);
        J::P(usr, "qs", qs);
    }
    long long cur = J::N(qs, qk) + add;
    J::PN(qs, qk, cur);
    for each (Quest^ meta in Catalog::Quests)
    {
        if (meta->K != qk) continue;
        String^ dk = qk + "d";
        if (!J::B(qs, dk) && cur >= meta->Need)
        {
            J::P(qs, dk, true);
            long long rw = meta->Reward * (Store::PlusOn(Store::Me) ? 2 : 1);
            J::PN(usr, "gems", J::N(usr, "gems") + rw);
            Store::GiveMcDirect(Store::Me, 10 + (gcnew Random())->Next(11), "q", 3);
            Dictionary<String^, Object^>^ r = gcnew Dictionary<String^, Object^>();
            J::P(r, "reward", rw); J::P(r, "label", meta->Label); J::P(r, "emo", meta->Emo);
            return r;
        }
        return nullptr;
    }
    return nullptr;
}

bool Store::BuyItem(String^ id, String^% err)
{
    if (!Store::EventEnabled()) { err = "Cửa hàng Gems đang tạm đóng ⛔"; return false; }
    ShopItem^ it = Catalog::FindItem(id);
    if (it == nullptr) { err = "Không tìm thấy sản phẩm"; return false; }
    Dictionary<String^, Object^>^ evIt = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::EvItems(), id));
    bool on = it->On;
    if (evIt != nullptr && J::H(evIt, "on")) on = J::B(evIt, "on");
    if (!on) { err = "Sản phẩm hiện đang tạm ngừng bán"; return false; }
    int cost = it->Cost;
    if (evIt != nullptr && J::H(evIt, "cost")) cost = (int)J::N(evIt, "cost");
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    long long gems = J::N(usr, "gems");
    if (gems < cost) { err = String::Format("Không đủ Gems ({0}/{1})", gems, cost); return false; }
    if (it->Type == "plus")
    {
        J::PN(usr, "gems", gems - cost);
        Store::GrantPlus(Store::Me, it->Idx);
        Store::Save();
        return true;
    }
    if (Store::Owns(Store::Me, it->Id)) { err = "Bạn đã sở hữu sản phẩm này rồi"; return false; }
    J::PN(usr, "gems", gems - cost);
    Store::Grant(Store::Me, it->Id);
    Store::Save();
    return true;
}

bool Store::BuyMcItem(String^ id, String^% err)
{
    if (!Store::McEnabled()) { err = "Sự kiện Trung Thu đang đóng cửa 🌕"; return false; }
    ShopItem^ it = nullptr;
    for each (ShopItem^ m in Catalog::McShop) if (m->Id == id) { it = m; break; }
    if (it == nullptr) { err = "Không tìm thấy sản phẩm"; return false; }
    if (it->Type == "pick") { err = "Bạn cần chọn một khung để đổi (mở bằng nút bên phải)"; return false; }
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    int cost = it->Cost;
    if (Store::PlusOn(Store::Me)) cost = (int)Math::Round(cost * 0.8);
    long long mc = J::N(usr, "mc");
    if (mc < cost) { err = String::Format("Không đủ bánh Trung thu ({0}/{1})", mc, cost); return false; }
    if (Store::Owns(Store::Me, it->Id)) { err = "Bạn đã sở hữu sản phẩm này rồi"; return false; }
    J::PN(usr, "mc", mc - cost);
    Store::Grant(Store::Me, it->Id);
    Store::Save();
    return true;
}

bool Store::McPick(int tier, String^ targetId, String^% err)
{
    if (!Store::McEnabled()) { err = "Sự kiện Trung Thu đang đóng cửa 🌕"; return false; }
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    int lo = 0, hi = 80, cost = 150;
    if (tier == 2) { lo = 120; hi = 300; cost = 255; }
    if (Store::PlusOn(Store::Me)) cost = (int)Math::Round(cost * 0.8);
    long long mc = J::N(usr, "mc");
    if (mc < cost) { err = String::Format("Không đủ bánh Trung thu ({0}/{1})", mc, cost); return false; }
    ShopItem^ it = Catalog::FindItem(targetId);
    if (it == nullptr || it->Cost < lo || it->Cost > hi) { err = "Mục tiêu không hợp lệ cho hạng này"; return false; }
    if (Store::Owns(Store::Me, it->Id)) { err = "Bạn đã sở hữu sản phẩm này rồi"; return false; }
    J::PN(usr, "mc", mc - cost);
    Store::Grant(Store::Me, it->Id);
    Store::Save();
    return true;
}

Dictionary<String^, Object^>^ Store::DrawLucky(String^% err)
{
    if (!Store::EventEnabled()) { err = "Cửa hàng Gems đang tạm đóng ⛔"; return nullptr; }
    if (!Store::DrawEnabled()) { err = "Rút thăm đang đóng cửa 🎰"; return nullptr; }
    Dictionary<String^, Object^>^ usr = Store::MeObj();
    long long cost = Store::PlusOn(Store::Me) ? 40 : 50;
    long long gems = J::N(usr, "gems");
    if (gems < cost) { err = String::Format("Không đủ Gems ({0}/{1})", gems, cost); return nullptr; }

    double noWin = 40.0;
    List<double>^ ws = gcnew List<double>();
    List<ShopItem^>^ its = gcnew List<ShopItem^>();
    for each (ShopItem^ it in Catalog::Items)
    {
        if (Store::Owns(Store::Me, it->Id)) continue;
        double w = it->Limited ? 0.25 : (155.0 / (double)it->Cost);
        ws->Add(w); its->Add(it);
        noWin += w;
    }
    double ps = 0.0;
    for each (ShopItem^ pit in Catalog::PlusItems) ps += pit->P;
    double jp = 0.0005;
    double tot = noWin / (1.0 - ps - jp);

    double r = (gcnew Random())->NextDouble() * tot;
    double acc = 0.0;
    ShopItem^ picked = nullptr;
    bool jackpot = false;
    for (int i = 0; i < ws->Count; i++) { acc += ws[i]; if (r < acc) { picked = its[i]; break; } }
    if (picked == nullptr)
    {
        acc += jp * tot;
        if (r < acc) jackpot = true;
        else
            for each (ShopItem^ pit in Catalog::PlusItems)
            {
                if (pit->P <= 0.0) continue;
                acc += pit->P * noWin / (1.0 - ps - jp);
                if (r < acc) { picked = pit; break; }
            }
    }

    J::PN(usr, "gems", gems - cost);
    Dictionary<String^, Object^>^ r0 = gcnew Dictionary<String^, Object^>();
    J::P(r0, "cost", cost);
    J::P(r0, "gems", gems - cost);

    if (picked == nullptr && !jackpot)
    {
        Store::Save();
        J::P(r0, "none", true);
        return r0;
    }
    if (jackpot)
    {
        J::PN(usr, "gems", J::N(usr, "gems") + 5000);
        J::P(r0, "jackpot", true); J::P(r0, "value", 5000LL);
        J::P(r0, "emo", "🍀"); J::P(r0, "name", "5000 Gems");
        Store::Save();
        return r0;
    }
    if (picked->Type == "plus")
    {
        Store::GrantPlus(Store::Me, picked->Idx);
        J::P(r0, "plus", true); J::P(r0, "name", picked->Name); J::P(r0, "dur", picked->Idx);
        Store::Save();
        return r0;
    }
    Store::Grant(Store::Me, picked->Id);
    J::P(r0, "none", false); J::P(r0, "id", picked->Id);
    J::P(r0, "emo", picked->Emo); J::P(r0, "name", picked->Name); J::P(r0, "limited", picked->Limited);
    Store::Save();
    return r0;
}

// ---------------- admin ----------------
void Store::SetBanned(String^ u, bool b)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr) return;
    J::P(usr, "k", b);
    Store::Save();
}
void Store::AddGems(String^ u, long long amt)
{
    Dictionary<String^, Object^>^ usr = Store::User(u);
    if (usr == nullptr) return;
    J::PN(usr, "gems", Math::Max(0LL, J::N(usr, "gems") + amt));
    Store::Save();
}
void Store::ToggleEvent(bool on) { J::P(Store::EventCfg(), "enabled", on); Store::Save(); }
void Store::ToggleDraw(bool on) { J::P(Store::EventCfg(), "drawEnabled", on); Store::Save(); }
void Store::ToggleMc(bool on) { J::P(Store::McCfg(), "enabled", on); Store::Save(); }
void Store::SetItemOn(String^ id, bool on)
{
    Dictionary<String^, Object^>^ o = J::M(Store::EvItems(), id);
    J::P(o, "on", on);
    Store::Save();
}
void Store::SetItemCost(String^ id, int cost)
{
    Dictionary<String^, Object^>^ o = J::M(Store::EvItems(), id);
    J::P(o, "cost", cost);
    Store::Save();
}
