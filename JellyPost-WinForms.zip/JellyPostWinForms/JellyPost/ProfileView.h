#pragma once
#include "pch.h"

public ref class ProfileView : public UserControl
{
public:
    ProfileView();
    void ShowSelf();
    void OpenProfile(String^ u);
    void RefreshView();
protected:
    virtual void OnResize(EventArgs^ e) override;
private:
    void RebuildSelf();
    void RebuildOther();
    void RefreshPosts(String^ author);
    void OnAction(String^ action, Object^ arg);
    void OnSaveProfile(Object^ s, EventArgs^ e);
    void OnChangePw(Object^ s, EventArgs^ e);
    void OnPickAv(Object^ s, EventArgs^ e);
    void OnFriendBtn(Object^ s, EventArgs^ e);
    void OnChatBtn(Object^ s, EventArgs^ e);
    void OnEquipDec(Object^ s, EventArgs^ e);
    void OnEquipPf(Object^ s, EventArgs^ e);
    void OnUnEquip(Object^ s, EventArgs^ e);

    Panel^ _wrap;
    Panel^ _page;
    String^ _viewUser;
    TextBox^ _dName;
    TextBox^ _bio;
    FlowLayoutPanel^ _avGrid;
    int _av;
    Button^ _selAv;
    HashSet<long long>^ _cmtOpen;
    int _padd;
};
