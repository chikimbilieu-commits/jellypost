#pragma once
#include "pch.h"

public ref class AdminView : public UserControl
{
public:
    AdminView();
    void RefreshView();
protected:
    virtual void OnResize(EventArgs^ e) override;
private:
    void Rebuild();
    void OnSearch(Object^ s, EventArgs^ e);
    void OnToggle(Object^ s, EventArgs^ e);
    void OnUserBtn(Object^ s, EventArgs^ e);
    void OnItemBtn(Object^ s, EventArgs^ e);
    void OnItemCost(Object^ s, EventArgs^ e);

    Panel^ _wrap;
    Panel^ _page;
    TextBox^ _search;
    String^ _q;
    int _padd;
};
