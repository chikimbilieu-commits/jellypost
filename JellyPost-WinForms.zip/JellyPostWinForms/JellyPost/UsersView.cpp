#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "UsersView.h"

UsersView::UsersView()
{
    this->BackColor = Theme::Bg;
    _q = "";

    Panel^ top = gcnew Panel();
    top->Dock = DockStyle::Top;
    top->Height = 56;
    top->BackColor = Theme::Card;
    this->Controls->Add(top);

    Label^ title = Ui::Lbl("👥  Tìm bạn", 12.0f, true, Theme::Text);
    title->Location = Drawing::Point(16, 12);
    top->Controls->Add(title);

    _search = gcnew TextBox();
    _search->BackColor = Theme::Card2;
    _search->ForeColor = Theme::Text;
    _search->BorderStyle = BorderStyle::FixedSingle;
    _search->Location = Drawing::Point(120, 12);
    _search->Width = 260;
    _search->Height = 28;
    _search->TextChanged += gcnew EventHandler(this, &UsersView::OnSearch);
    top->Controls->Add(_search);

    _wrap = gcnew Panel();
    _wrap->Dock = DockStyle::Fill;
    _wrap->BackColor = Theme::Bg;
    _wrap->AutoScroll = true;
    this->Controls->Add(_wrap);
    _list = gcnew Panel();
    _list->BackColor = Theme::Bg;
    _wrap->Controls->Add(_list);
}

void UsersView::OnSearch(Object^ s, EventArgs^)
{
    _q = Utils::NormVn(_search->Text);
    Rebuild();
}

void UsersView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    Rebuild();
}

void UsersView::RefreshView()
{
    Rebuild();
}

void UsersView::Rebuild()
{
    _list->Controls->Clear();
    int w = Math::Max(480, this->ClientSize.Width - 24);
    _list->Width = w;
    int y = 8;

    Dictionary<String^, Object^>^ users = Store::Users();
    List<String^>^ names = gcnew List<String^>();
    for each (KeyValuePair<String^, Object^> kv in users) names->Add(kv.Key);
    names->Sort();

    int shown = 0;
    for (int i = 0; i < names->Count; i++)
    {
        String^ u = names[i];
        Dictionary<String^, Object^>^ usr = Store::User(u);
        if (usr == nullptr) continue;
        if (_q != "")
        {
            String^ dn = Utils::NormVn(J::S(usr, "d"));
            if (dn->IndexOf(_q) < 0 && Utils::NormVn(u)->IndexOf(_q) < 0) continue;
        }
        shown++;

        Panel^ row = gcnew Panel();
        row->BackColor = Theme::Card;
        row->Width = w - 16;
        row->Height = 58;
        row->Location = Drawing::Point(8, y);
        row->Cursor = Cursors::Hand;
        row->Click += gcnew EventHandler(this, &UsersView::OnOpen);
        row->Tag = u;
        _list->Controls->Add(row);

        AvatarControl^ av = gcnew AvatarControl();
        av->SetData((int)J::N(usr, "a"), J::S(usr, "ai"), Store::DisplayDec(usr), 40);
        av->Location = Drawing::Point(10, 9);
        av->Click += gcnew EventHandler(this, &UsersView::OnOpen);
        av->Tag = u;
        row->Controls->Add(av);

        StringBuilder^ nm = gcnew StringBuilder();
        nm->Append(J::S(usr, "d"));
        if (J::B(usr, "st")) nm->Append("  [STAFF]");
        if (J::B(usr, "m")) nm->Append("  [ADMIN]");
        Label^ name = Ui::Lbl(nm->ToString(), 10.0f, true, Theme::Text);
        name->Location = Drawing::Point(60, 8);
        name->Tag = u;
        name->Click += gcnew EventHandler(this, &UsersView::OnOpen);
        row->Controls->Add(name);
        Label^ un = Ui::Lbl("@" + u, 8.5f, false, Theme::Muted);
        un->Location = Drawing::Point(60, 30);
        un->Tag = u;
        un->Click += gcnew EventHandler(this, &UsersView::OnOpen);
        row->Controls->Add(un);

        if (u == Store::Me)
        {
            Label^ me = Ui::Lbl("(bạn)", 9.0f, true, Theme::Accent);
            me->Location = Drawing::Point(w - 130, 18);
            row->Controls->Add(me);
        }
        else
        {
            String^ rel = Store::Rel(Store::Me, u);
            String^ btnTxt = "";
            String^ op = "";
            Color bc = Theme::Accent;
            bool white = true;
            if (rel == "friend") { btnTxt = "Kết bạn ✓"; op = "none"; bc = Theme::Card2; white = false; }
            else if (rel == "in") { btnTxt = "Chấp nhận"; op = "accept"; bc = Theme::Green; }
            else if (rel == "out") { btnTxt = "Đã gửi lời mời"; op = "none"; bc = Theme::Card2; white = false; }
            else { btnTxt = "+ Kết bạn"; op = "send"; }

            Button^ b = Ui::Btn(btnTxt, 108, 30, bc, white ? Color::White : Theme::Muted, !white);
            b->Tag = op + ":" + u;
            if (op != "none")
                b->Click += gcnew EventHandler(this, &UsersView::OnRowBtn);
            b->Location = Drawing::Point(w - 134, 14);
            row->Controls->Add(b);
            if (rel == "friend")
            {
                Button^ unf = Ui::Btn("Huỷ", 56, 30, Theme::Card2, Theme::Danger, false);
                unf->FlatAppearance->BorderSize = 1;
                unf->FlatAppearance->BorderColor = Theme::Border;
                unf->Tag = "unfriend:" + u;
                unf->Click += gcnew EventHandler(this, &UsersView::OnRowBtn);
                unf->Location = Drawing::Point(w - 198, 14);
                row->Controls->Add(unf);
            }
        }
        y += 64;
    }
    if (shown == 0)
    {
        Label^ n = Ui::Lbl(_q == "" ? "Chưa có người dùng nào" : "Không tìm thấy kết quả", 10.0f, false, Theme::Muted);
        n->Location = Drawing::Point(16, 16);
        _list->Controls->Add(n);
        y += 40;
    }
    _list->Height = y + 8;
}

void UsersView::OnOpen(Object^ s, EventArgs^)
{
    Control^ c = (Control^)s;
    AppCtx::Nav("profile", (String^)c->Tag);
}

void UsersView::OnRowBtn(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ v = (String^)b->Tag;
    int colon = v->IndexOf(':');
    String^ op = v->Substring(0, colon);
    String^ u = v->Substring(colon + 1);
    if (op == "send") { if (!Store::SendReq(u)) { Ui::Warn("Không thể gửi lời mời"); } else Toast::Show("Đã gửi lời mời kết bạn", true); }
    else if (op == "accept") { Store::AcceptReq(u); Toast::Show("Đã kết bạn 🎉", true); }
    else if (op == "unfriend") { if (Ui::Confirm("Huỷ kết bạn với @" + u + "?")) Store::RemoveFriend(u); }
    AppCtx::Win->RefreshTopbar();
    Rebuild();
}
