#pragma once
#include "pch.h"

public ref class UsersView : public UserControl
{
public:
    UsersView();
    void RefreshView();
protected:
    virtual void OnResize(EventArgs^ e) override;
private:
    void Rebuild();
    void OnSearch(Object^ s, EventArgs^ e);
    void OnRowBtn(Object^ s, EventArgs^ e);
    void OnOpen(Object^ s, EventArgs^ e);

    Panel^ _wrap;
    Panel^ _list;
    TextBox^ _search;
    String^ _q;
};
