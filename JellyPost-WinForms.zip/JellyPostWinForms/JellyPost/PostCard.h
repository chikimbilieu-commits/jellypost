#pragma once
#include "pch.h"

public ref class PostCard : public UserControl
{
public:
    PostCard();
    void Set(Dictionary<String^, Object^>^ post);
    void SetWidth(int w);
    void SetCmtOpen(bool open);
    long long Pid;
private:
    void Build();
    void Layout();
    void BuildComments(int yPos);
    void OnReact(Object^ s, EventArgs^ e);
    void OnNameClick(Object^ s, EventArgs^ e);
    void OnSaveClick(Object^ s, EventArgs^ e);
    void OnDelClick(Object^ s, EventArgs^ e);
    void OnEditClick(Object^ s, EventArgs^ e);
    void OnCmtClick(Object^ s, EventArgs^ e);
    void OnSendCmt(Object^ s, EventArgs^ e);
    void OnDelCmt(Object^ s, EventArgs^ e);
    void OnImgClick(Object^ s, EventArgs^ e);

    Dictionary<String^, Object^>^ _p;
    int _w;
    ArrayList^ _dyn;
    AvatarControl^ _av;
    Label^ _name;
    Label^ _time;
    Label^ _txt;
    Panel^ _imgsP;
    FlowLayoutPanel^ _reactP;
    Panel^ _cmtP;
    TextBox^ _cmtBox;
    Button^ _saveBtn;
    bool _cmtOpen;
    long long _pid;
};
