#pragma once
#include "pch.h"

public ref class EventView : public UserControl
{
public:
    EventView();
    void RefreshView();
protected:
    virtual void OnResize(EventArgs^ e) override;
private:
    void Rebuild();
    void OnLogin(Object^ s, EventArgs^ e);
    void OnBuy(Object^ s, EventArgs^ e);
    void OnPick(Object^ s, EventArgs^ e);
    void OnPickSel(Object^ s, EventArgs^ e);
    void PickDialog(int tier, int cost);

    Panel^ _wrap;
    Panel^ _page;
    int _padd;
};
