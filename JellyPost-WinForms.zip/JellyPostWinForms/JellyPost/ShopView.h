#pragma once
#include "pch.h"

public ref class ShopView : public UserControl
{
public:
    ShopView();
    void RefreshView();
protected:
    virtual void OnResize(EventArgs^ e) override;
private:
    void Rebuild();
    void OnBuy(Object^ s, EventArgs^ e);
    void OnDraw(Object^ s, EventArgs^ e);
    void OnBuyPlus(Object^ s, EventArgs^ e);

    Panel^ _wrap;
    Panel^ _page;
    Label^ _gemsLbl;
    int _padd;
};
