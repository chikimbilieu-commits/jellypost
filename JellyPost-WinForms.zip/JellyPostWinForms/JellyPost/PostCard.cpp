#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "PostCard.h"

// ===================== zoom image form =====================
ref class ZoomForm : public Form
{
public:
    ZoomForm(String^ src)
    {
        this->Text = "Xem ảnh";
        this->StartPosition = FormStartPosition::CenterScreen;
        this->BackColor = Color::FromArgb(8, 8, 12);
        this->ClientSize = Drawing::Size(760, 600);
        PictureBox^ pb = gcnew PictureBox();
        pb->Dock = DockStyle::Fill;
        pb->SizeMode = PictureBoxSizeMode::Zoom;
        this->Controls->Add(pb);
        Img::LoadAsync(pb, src, 1600, 1200);
    }
};

PostCard::PostCard()
{
    _w = 640;
    _cmtOpen = false;
    _pid = 0;
    this->BackColor = Theme::Card;
    this->AutoScroll = false;
    _dyn = gcnew ArrayList();

    _av = gcnew AvatarControl();
    _av->Location = Drawing::Point(12, 12);
    this->Controls->Add(_av);

    _name = Ui::Lbl("", 10.5f, true, Theme::Accent);
    _name->AutoSize = true;
    _name->Location = Drawing::Point(60, 14);
    _name->Cursor = Cursors::Hand;
    _name->Click += gcnew EventHandler(this, &PostCard::OnNameClick);
    this->Controls->Add(_name);

    _time = Ui::Lbl("", 8.5f, false, Theme::Muted);
    _time->AutoSize = true;
    _time->Anchor = AnchorStyles::Top | AnchorStyles::Right;
    this->Controls->Add(_time);

    _txt = Ui::Lbl("", 10.0f, false, Theme::Text);
    _txt->AutoSize = false;
    _txt->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
    this->Controls->Add(_txt);

    _imgsP = gcnew Panel();
    _imgsP->BackColor = Theme::Card;
    _imgsP->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
    this->Controls->Add(_imgsP);

    _reactP = gcnew FlowLayoutPanel();
    _reactP->FlowDirection = FlowDirection::LeftToRight;
    _reactP->WrapContents = false;
    _reactP->Height = 34;
    _reactP->BackColor = Theme::Card;
    _reactP->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
    this->Controls->Add(_reactP);

    _saveBtn = Ui::GhostBtn("💾", 34, 28);
    _saveBtn->Anchor = AnchorStyles::Top | AnchorStyles::Right;
    _saveBtn->Click += gcnew EventHandler(this, &PostCard::OnSaveClick);
    this->Controls->Add(_saveBtn);
}

void PostCard::SetWidth(int w)
{
    _w = w;
    this->Width = w;
    _txt->Width = w - 78;
    _txt->Height = Ui::MeasureText(_txt->Text, _txt->Font, _txt->Width);
    _imgsP->Width = w - 76;
    _reactP->Width = w - 120;
    Layout();
}

void PostCard::SetCmtOpen(bool open)
{
    if (_cmtOpen == open) return;
    _cmtOpen = open;
    Layout();
}

void PostCard::Set(Dictionary<String^, Object^>^ post)
{
    _p = post;
    _pid = J::N(post, "i");
    Pid = _pid;
    Dictionary<String^, Object^>^ author = Store::User(J::S(post, "a"));
    int av = author == nullptr ? 0 : (int)J::N(author, "a");
    String^ ai = author == nullptr ? "" : J::S(author, "ai");
    int dec = Store::DisplayDec(author == nullptr ? gcnew Dictionary<String^, Object^>() : author);
    _av->SetData(av, ai, dec, 40);

    StringBuilder^ nm = gcnew StringBuilder();
    nm->Append(J::S(post, "a"));
    if (author != nullptr)
    {
        if (J::B(author, "st")) nm->Append("  [STAFF]");
        if (J::B(author, "m")) nm->Append("  [ADMIN]");
        if (Store::UserPlus(author)) nm->Append("  ⭐");
    }
    if (J::B(post, "ns")) nm->Append("  🔞");
    _name->Text = nm->ToString();
    _name->Tag = J::S(post, "a");

    _time->Text = Utils::TimeAgo(J::N(post, "x"));
    _time->Location = Drawing::Point(_w - 150, 16);
    _txt->Text = J::S(post, "t");
    _txt->Height = Ui::MeasureText(_txt->Text, _txt->Font, _txt->Width);
    _txt->Location = Drawing::Point(60, 46);

    Layout();
}

void PostCard::Layout()
{
    // remove previous transient controls
    for (int i = 0; i < _dyn->Count; i++)
    {
        Control^ c = (Control^)_dyn[i];
        this->Controls->Remove(c);
        c->Dispose();
    }
    _dyn->Clear();

    int y = 46 + _txt->Height + 6;

    // images
    _imgsP->Controls->Clear();
    ArrayList^ imgs = dynamic_cast<ArrayList^>(J::G(_p, "imgs"));
    int nImg = imgs == nullptr ? 0 : imgs->Count;
    if (nImg > 0)
    {
        int imgSz = nImg == 1 ? Math::Min(_w - 90, 520) : 200;
        for (int i = 0; i < nImg; i++)
        {
            String^ src = (String^)imgs[i];
            if (String::IsNullOrEmpty(src)) continue;
            PictureBox^ pb = gcnew PictureBox();
            pb->Size = Drawing::Size(imgSz, imgSz);
            pb->BackColor = Theme::Card2;
            pb->SizeMode = PictureBoxSizeMode::Zoom;
            pb->Cursor = Cursors::Hand;
            pb->Tag = src;
            pb->Click += gcnew EventHandler(this, &PostCard::OnImgClick);
            pb->Location = Drawing::Point((i % 2) * (imgSz + 6), (i / 2) * (imgSz + 6));
            _imgsP->Controls->Add(pb);
            Img::LoadAsync(pb, src, imgSz * 2, imgSz * 2);
        }
        int cols = nImg == 1 ? 1 : 2;
        _imgsP->Height = ((nImg + cols - 1) / cols) * (imgSz + 6);
        _imgsP->Visible = true;
    }
    else { _imgsP->Height = 0; _imgsP->Visible = false; }
    _imgsP->Location = Drawing::Point(60, y);
    y += _imgsP->Height;

    // music card
    Dictionary<String^, Object^>^ song = dynamic_cast<Dictionary<String^, Object^>^>(J::G(_p, "song"));
    if (song != nullptr)
    {
        String^ t = J::S(song, "title");
        String^ ar = J::S(song, "artist");
        if (t != "")
        {
            Label^ songL = Ui::Lbl("🎵  " + t + (ar == "" ? "" : " — " + ar), 9.5f, true, Theme::Green);
            songL->AutoSize = false;
            songL->Width = _w - 90;
            songL->Height = 30;
            songL->TextAlign = ContentAlignment::MiddleLeft;
            songL->BackColor = Theme::Card2;
            songL->Location = Drawing::Point(60, y);
            this->Controls->Add(songL);
            _dyn->Add(songL);
            y += 36;
        }
    }

    // reactions
    _reactP->Location = Drawing::Point(54, y);
    _reactP->Controls->Clear();
    Dictionary<String^, Object^>^ R = dynamic_cast<Dictionary<String^, Object^>^>(J::G(_p, "R"));
    for (int i = 0; i < Catalog::Reactions->Length; i++)
    {
        String^ emo = Catalog::Reactions[i];
        ArrayList^ arr = (R != nullptr && R->ContainsKey(emo)) ? dynamic_cast<ArrayList^>(R[emo]) : nullptr;
        int cnt = arr == nullptr ? 0 : arr->Count;
        bool me = arr != nullptr && arr->Contains(Store::Me);
        Button^ b = Ui::Btn(emo + (cnt > 0 ? " " + cnt.ToString() : ""), 58, 30,
            me ? Theme::AccentSoft : Theme::Card2, me ? Theme::Accent : Theme::Text, me);
        b->Tag = emo;
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = Theme::Border;
        b->Click += gcnew EventHandler(this, &PostCard::OnReact);
        _reactP->Controls->Add(b);
    }
    y += 34;

    // action row
    Button^ cmtBtn = Ui::Btn("💬  Bình luận", 96, 28, Color::Transparent, Theme::Muted, false);
    cmtBtn->TextAlign = ContentAlignment::MiddleLeft;
    cmtBtn->Click += gcnew EventHandler(this, &PostCard::OnCmtClick);
    cmtBtn->Location = Drawing::Point(58, y);
    this->Controls->Add(cmtBtn);
    _dyn->Add(cmtBtn);

    _saveBtn->Location = Drawing::Point(_w - 46, y);
    _saveBtn->Text = (Store::MeObj() != nullptr && J::L(Store::MeObj(), "sv")->Contains(_pid)) ? "🔖" : "💾";

    bool canDel = J::S(_p, "a") == Store::Me || Store::IsMod(Store::Me);
    if (canDel)
    {
        Button^ delBtn = Ui::Btn("🗑", 34, 26, Color::Transparent, Theme::Danger, false);
        delBtn->Tag = _pid;
        delBtn->Click += gcnew EventHandler(this, &PostCard::OnDelClick);
        delBtn->Location = Drawing::Point(_w - 84, y);
        this->Controls->Add(delBtn);
        _dyn->Add(delBtn);
    }
    if (J::S(_p, "a") == Store::Me)
    {
        Button^ editBtn = Ui::Btn("✏️", 34, 26, Color::Transparent, Theme::Muted, false);
        editBtn->Tag = _pid;
        editBtn->Click += gcnew EventHandler(this, &PostCard::OnEditClick);
        editBtn->Location = Drawing::Point(_w - 122, y);
        this->Controls->Add(editBtn);
        _dyn->Add(editBtn);
    }
    y += 34;

    // comments
    int cmtH = 0;
    if (_cmtOpen)
    {
        BuildComments(y);
        cmtH = _cmtP->Height;
    }
    y += cmtH;

    this->Height = y + 6;
}

void PostCard::BuildComments(int yPos)
{
    if (_cmtP != nullptr) { this->Controls->Remove(_cmtP); _cmtP->Dispose(); }
    _cmtP = gcnew Panel();
    _cmtP->BackColor = Theme::Card2;
    _cmtP->Width = _w - 16;
    _cmtP->Location = Drawing::Point(8, yPos);
    this->Controls->Add(_cmtP);
    _dyn->Add(_cmtP);
    int y = 8;
    ArrayList^ c = dynamic_cast<ArrayList^>(J::G(_p, "c"));
    if (c != nullptr)
        for (int i = 0; i < c->Count; i++)
        {
            Dictionary<String^, Object^>^ cm = dynamic_cast<Dictionary<String^, Object^>^>(c[i]);
            if (cm == nullptr) continue;
            Label^ row = Ui::Lbl("", 9.0f, false, Theme::Text);
            row->AutoSize = false;
            row->Width = _cmtP->Width - 56;
            row->Text = J::S(cm, "a") + "  " + J::S(cm, "t");
            row->Height = Math::Max(20, Ui::MeasureText(row->Text, row->Font, row->Width));
            row->Location = Drawing::Point(10, y);
            _cmtP->Controls->Add(row);
            bool canDel = J::S(cm, "a") == Store::Me || Store::IsMod(Store::Me);
            if (canDel)
            {
                Button^ x = Ui::Btn("✕", 22, 20, Color::Transparent, Theme::Danger, true);
                x->Tag = (long long)J::N(cm, "i");
                x->Click += gcnew EventHandler(this, &PostCard::OnDelCmt);
                x->Location = Drawing::Point(_cmtP->Width - 34, y);
                _cmtP->Controls->Add(x);
            }
            y += row->Height + 2;
        }
    _cmtBox = gcnew TextBox();
    _cmtBox->BackColor = Theme::Card;
    _cmtBox->ForeColor = Theme::Text;
    _cmtBox->BorderStyle = BorderStyle::FixedSingle;
    _cmtBox->Location = Drawing::Point(10, y + 4);
    _cmtBox->Width = _cmtP->Width - 78;
    _cmtBox->Height = 30;
    _cmtP->Controls->Add(_cmtBox);
    Button^ send = Ui::AccentBtn("Gửi", 56, 30);
    send->Location = Drawing::Point(_cmtP->Width - 66, y + 4);
    send->Click += gcnew EventHandler(this, &PostCard::OnSendCmt);
    _cmtP->Controls->Add(send);
    _cmtP->Height = y + 44;
}

void PostCard::OnImgClick(Object^ s, EventArgs^)
{
    PictureBox^ pb = (PictureBox^)s;
    ZoomForm^ z = gcnew ZoomForm((String^)pb->Tag);
    z->ShowDialog(this);
}

void PostCard::OnNameClick(Object^ s, EventArgs^)
{
    Label^ l = (Label^)s;
    Bus::Emit("prof", (String^)l->Tag);
}

void PostCard::OnReact(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    Bus::Emit("react:" + Ui::Str(_pid), (String^)b->Tag);
}

void PostCard::OnSaveClick(Object^ s, EventArgs^)
{
    Bus::Emit("save", _pid);
}

void PostCard::OnDelClick(Object^ s, EventArgs^)
{
    Bus::Emit("del", _pid);
}

void PostCard::OnEditClick(Object^ s, EventArgs^)
{
    Bus::Emit("edit", _pid);
}

void PostCard::OnCmtClick(Object^ s, EventArgs^)
{
    Bus::Emit("cmt", _pid);
}

void PostCard::OnSendCmt(Object^ s, EventArgs^)
{
    String^ t = Utils::Clean(_cmtBox->Text, 500);
    if (t == "") return;
    Bus::Emit("cmtadd:" + Ui::Str(_pid), t);
}

void PostCard::OnDelCmt(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    long long cid = (long long)Convert::ToInt64(b->Tag);
    Bus::Emit("cmtdel:" + Ui::Str(_pid), cid);
}
