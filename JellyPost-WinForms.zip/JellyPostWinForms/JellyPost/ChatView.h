#pragma once
#include "pch.h"

public ref class ChatView : public UserControl
{
public:
    ChatView();
    void RefreshView();
    void OpenConv(String^ other);
    void RefreshConvs();
    void LoadMsgs();
protected:
    virtual void OnResize(EventArgs^ e) override;
private:
    void OnConvClick(Object^ s, EventArgs^ e);
    void OnSend(Object^ s, EventArgs^ e);
    void OnKey(Object^ s, KeyEventArgs^ e);

    Panel^ _convP;
    Panel^ _msgWrap;
    Panel^ _msgList;
    TextBox^ _input;
    String^ _other;
    Label^ _empty;
};
