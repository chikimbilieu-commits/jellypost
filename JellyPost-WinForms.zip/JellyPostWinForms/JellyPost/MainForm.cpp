#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "MainForm.h"
#include "AuthForm.h"
#include "PostCard.h"
#include "FeedView.h"
#include "ChatView.h"
#include "ProfileView.h"
#include "ShopView.h"
#include "EventView.h"
#include "UsersView.h"
#include "AdminView.h"
#include "NotifForm.h"

MainForm::MainForm()
{
    this->Text = "Jelly Post 💜";
    this->StartPosition = FormStartPosition::CenterScreen;
    this->ClientSize = Drawing::Size(1180, 760);
    this->MinimumSize = Drawing::Size(880, 560);
    this->BackColor = Theme::Bg;
    this->ForeColor = Theme::Text;
    this->Font = Ui::F(9.5f, false);
    this->KeyPreview = true;

    AppCtx::Win = this;
    _navBtns = gcnew Dictionary<String^, Button^>();
    _feed = nullptr; _chat = nullptr; _profile = nullptr;
    _shop = nullptr; _event = nullptr; _users = nullptr; _admin = nullptr;
    _current = "";

    BuildShell();
    GoTo("feed", nullptr);
}

// ===================== shell =====================
void MainForm::BuildShell()
{
    // ---------- top bar ----------
    _topbar = gcnew Panel();
    _topbar->Dock = DockStyle::Top;
    _topbar->Height = 56;
    _topbar->BackColor = Theme::Card;
    this->Controls->Add(_topbar);

    Label^ logo = Ui::Lbl("Jelly Post 💜", 15.0f, true, Theme::Accent);
    logo->Location = Drawing::Point(16, 15);
    _topbar->Controls->Add(logo);

    // right cluster (laid out right-to-left)
    int right = this->ClientSize.Width - 16;
    Button^ logoutBtn = Ui::Btn("Đăng xuất", 92, 32, Theme::Card2, Theme::Text, false);
    logoutBtn->FlatAppearance->BorderSize = 1;
    logoutBtn->FlatAppearance->BorderColor = Theme::Border;
    logoutBtn->Click += gcnew EventHandler(this, &MainForm::Logout);
    logoutBtn->Location = Drawing::Point(right - 92, 12); _topbar->Controls->Add(logoutBtn);
    right -= 92 + 10;

    Button^ themeBtn = Ui::Btn(Theme::Dark ? "☀️" : "🌙", 38, 32, Theme::Card2, Theme::Text, false);
    themeBtn->FlatAppearance->BorderSize = 1;
    themeBtn->FlatAppearance->BorderColor = Theme::Border;
    themeBtn->Click += gcnew EventHandler(this, &MainForm::ToggleTheme);
    themeBtn->Location = Drawing::Point(right - 38, 12); _topbar->Controls->Add(themeBtn);
    right -= 38 + 10;

    Button^ bellBtn = Ui::Btn("🔔", 38, 32, Theme::Card2, Theme::Text, false);
    bellBtn->FlatAppearance->BorderSize = 1;
    bellBtn->FlatAppearance->BorderColor = Theme::Border;
    bellBtn->Click += gcnew EventHandler(this, &MainForm::ShowNotifs);
    bellBtn->Location = Drawing::Point(right - 38, 12); _topbar->Controls->Add(bellBtn);
    _bellBadge = Ui::Lbl("", 8.0f, true, Color::White);
    _bellBadge->BackColor = Theme::Danger;
    _bellBadge->AutoSize = false;
    _bellBadge->Size = Drawing::Size(18, 18);
    _bellBadge->TextAlign = ContentAlignment::MiddleCenter;
    _bellBadge->Visible = false;
    _bellBadge->Location = Drawing::Point(right - 16, 6);
    _topbar->Controls->Add(_bellBadge);
    right -= 38 + 10;

    _gemsLbl = Ui::Lbl("💎 0", 10.5f, true, Color::White);
    _gemsLbl->AutoSize = false;
    _gemsLbl->Size = Drawing::Size(150, 32);
    _gemsLbl->TextAlign = ContentAlignment::MiddleRight;
    _gemsLbl->Location = Drawing::Point(right - 150, 12);
    _topbar->Controls->Add(_gemsLbl);
    right -= 150 + 10;

    _meAv = gcnew AvatarControl();
    _meAv->Location = Drawing::Point(right - 40, 8);
    _topbar->Controls->Add(_meAv);

    _meName = Ui::Lbl("", 10.5f, true, Theme::Text);
    _meName->AutoSize = false;
    _meName->Size = Drawing::Size(170, 32);
    _meName->TextAlign = ContentAlignment::MiddleLeft;
    _meName->Location = Drawing::Point(right - 210, 12);
    _topbar->Controls->Add(_meName);

    _mePlus = Ui::Lbl("⭐", 10.0f, true, Color::FromArgb(250, 204, 21));
    _mePlus->AutoSize = true;
    _mePlus->Visible = false;
    _topbar->Controls->Add(_mePlus);

    // ---------- sidebar ----------
    _sidebar = gcnew Panel();
    _sidebar->Dock = DockStyle::Left;
    _sidebar->Width = 212;
    _sidebar->BackColor = Theme::Card;
    this->Controls->Add(_sidebar);

    int y = 8;
    _sidebar->Controls->Add(MakeNav("feed", "🏠  Bảng tin"));
    _sidebar->Controls->Add(MakeNav("chat", "💬  Tin nhắn"));
    _sidebar->Controls->Add(MakeNav("profile", "👤  Hồ sơ"));
    _sidebar->Controls->Add(MakeNav("saved", "🔖  Đã lưu"));
    _sidebar->Controls->Add(MakeNav("shop", "💎  Cửa hàng Gems"));
    _sidebar->Controls->Add(MakeNav("event", "🥮  Sự kiện Trung Thu"));
    _sidebar->Controls->Add(MakeNav("users", "👥  Tìm bạn"));
    if (Store::IsMod(Store::Me)) _sidebar->Controls->Add(MakeNav("admin", "🛠️  Quản trị"));

    Label^ ver = Ui::Lbl("Bản Windows 1.0", 8.0f, false, Theme::Muted);
    ver->Location = Drawing::Point(16, this->ClientSize.Height - 40);
    _sidebar->Controls->Add(ver);

    // chat unread badge on nav
    _chatBadge = Ui::Lbl("", 8.0f, true, Color::White);
    _chatBadge->BackColor = Theme::Danger;
    _chatBadge->AutoSize = false;
    _chatBadge->Size = Drawing::Size(18, 18);
    _chatBadge->TextAlign = ContentAlignment::MiddleCenter;
    _chatBadge->Visible = false;
    _chatBadge->Location = Drawing::Point(178, 78);
    _sidebar->Controls->Add(_chatBadge);

    // ---------- content ----------
    _content = gcnew Panel();
    _content->Dock = DockStyle::Fill;
    _content->BackColor = Theme::Bg;
    this->Controls->Add(_content);

    RefreshTopbar();
}

Button^ MainForm::MakeNav(String^ key, String^ text)
{
    Button^ b = Ui::Btn(text, 196, 42, Color::Transparent, Theme::Text, false);
    b->TextAlign = ContentAlignment::MiddleLeft;
    b->FlatAppearance->BorderSize = 0;
    b->Font = Ui::F(10.5f, false);
    b->Tag = key;
    b->Location = Drawing::Point(8, 8 + 50 * _navBtns->Count);
    b->Click += gcnew EventHandler(this, &MainForm::OnNavClick);
    _navBtns[key] = b;
    return b;
}

void MainForm::OnNavClick(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    GoTo((String^)b->Tag, nullptr);
}

void MainForm::HighlightNav(String^ key)
{
    for each (KeyValuePair<String^, Button^> kv in _navBtns)
        kv.Value->BackColor = kv.Key == key ? Theme::AccentSoft : Color::Transparent;
}

void MainForm::ApplyBadges()
{
    int chat = Store::UnreadTotal();
    _chatBadge->Text = chat > 99 ? "99+" : chat.ToString();
    _chatBadge->Visible = chat > 0;
    int nf = Store::UnreadNotifs();
    _bellBadge->Text = nf > 99 ? "99+" : nf.ToString();
    _bellBadge->Visible = nf > 0;
    bool ev = Store::EventEnabled();
    bool mc = Store::McEnabled();
    if (_navBtns->ContainsKey("shop"))
        _navBtns["shop"]->Text = (ev ? "" : "⛔ ") + "💎  Cửa hàng Gems";
    if (_navBtns->ContainsKey("event"))
        _navBtns["event"]->Text = (mc ? "" : "⛔ ") + "🥮  Sự kiện Trung Thu";
}

void MainForm::RefreshTopbar()
{
    Dictionary<String^, Object^>^ me = Store::MeObj();
    if (me == nullptr) return;
    long long gems = Store::Gems(Store::Me);
    _gemsLbl->Text = "💎 " + Ui::Fmt(gems);
    _meName->Text = J::S(me, "d");
    _meAv->SetData((int)J::N(me, "a"), J::S(me, "ai"), Store::DisplayDec(me), 40);
    _mePlus->Visible = Store::PlusOn(Store::Me);
    int pw = _meName->Location.X - 20;
    _mePlus->Location = Drawing::Point(pw - 4, 16);
    ApplyBadges();
}

void MainForm::RefreshAll()
{
    RefreshTopbar();
    if (_current == "feed") { EnsureFeed(); _feed->RefreshView(); }
    else if (_current == "saved") { EnsureFeed(); _feed->RefreshView(); }
    else if (_current == "chat") { EnsureChat(); _chat->RefreshView(); }
    else if (_current == "profile") { EnsureProfile(); _profile->RefreshView(); }
    else if (_current == "shop") { EnsureShop(); _shop->RefreshView(); }
    else if (_current == "event") { EnsureEvent(); _event->RefreshView(); }
    else if (_current == "users") { EnsureUsers(); _users->RefreshView(); }
    else if (_current == "admin") { EnsureAdmin(); _admin->RefreshView(); }
}

// ===================== navigation =====================
void MainForm::Show(Control^ v)
{
    _content->Controls->Clear();
    v->Dock = DockStyle::Fill;
    _content->Controls->Add(v);
}

void MainForm::EnsureFeed() { if (_feed == nullptr) _feed = gcnew FeedView(); }
void MainForm::EnsureChat() { if (_chat == nullptr) _chat = gcnew ChatView(); }
void MainForm::EnsureProfile() { if (_profile == nullptr) _profile = gcnew ProfileView(); }
void MainForm::EnsureShop() { if (_shop == nullptr) _shop = gcnew ShopView(); }
void MainForm::EnsureEvent() { if (_event == nullptr) _event = gcnew EventView(); }
void MainForm::EnsureUsers() { if (_users == nullptr) _users = gcnew UsersView(); }
void MainForm::EnsureAdmin() { if (_admin == nullptr) _admin = gcnew AdminView(); }

void MainForm::GoTo(String^ view, Object^ arg)
{
    _current = view;
    HighlightNav(view);
    ApplyBadges();
    if (view == "feed") { EnsureFeed(); Show(_feed); _feed->ShowFeed(); }
    else if (view == "saved") { EnsureFeed(); Show(_feed); _feed->ShowSaved(); }
    else if (view == "chat")
    {
        EnsureChat();
        Show(_chat);
        _chat->RefreshView();
        if (arg != nullptr && arg->ToString() != "") _chat->OpenConv(arg->ToString());
    }
    else if (view == "profile")
    {
        EnsureProfile();
        Show(_profile);
        if (arg != nullptr && arg->ToString() != Store::Me) _profile->OpenProfile(arg->ToString());
        else _profile->ShowSelf();
    }
    else if (view == "shop") { EnsureShop(); Show(_shop); _shop->RefreshView(); }
    else if (view == "event") { EnsureEvent(); Show(_event); _event->RefreshView(); }
    else if (view == "users") { EnsureUsers(); Show(_users); _users->RefreshView(); }
    else if (view == "admin") { EnsureAdmin(); Show(_admin); _admin->RefreshView(); }
}

void MainForm::OpenChat(String^ other) { GoTo("chat", other); }

// ===================== top bar actions =====================
void MainForm::ShowNotifs()
{
    NotifForm^ f = gcnew NotifForm();
    f->ShowDialog(this);
    RefreshTopbar();
}

void MainForm::ToggleTheme()
{
    Theme::Set(!Theme::Dark);
    J::P(Store::Settings, "dark", Theme::Dark);
    try
    {
        JavaScriptSerializer^ ser = gcnew JavaScriptSerializer();
        File::WriteAllText(Store::SettingsPath, ser->Serialize(Store::Settings), Encoding::UTF8);
    }
    catch (Exception^) { }
    Application::Restart();
}

void MainForm::Logout()
{
    if (!Ui::Confirm("Bạn có chắc muốn đăng xuất khỏi Jelly Post?")) return;
    Store::ClearSession();
    Application::Restart();
}

void AppCtx::Nav(String^ view, Object^ arg)
{
    if (AppCtx::Win != nullptr) AppCtx::Win->GoTo(view, arg);
}
