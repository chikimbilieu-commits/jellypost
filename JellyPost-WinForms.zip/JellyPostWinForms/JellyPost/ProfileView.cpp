#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "PostCard.h"
#include "ProfileView.h"

ProfileView::ProfileView()
{
    this->BackColor = Theme::Bg;
    _viewUser = Store::Me;
    _av = 0;
    _selAv = nullptr;
    _cmtOpen = gcnew HashSet<long long>();
    _padd = 24;

    _wrap = gcnew Panel();
    _wrap->Dock = DockStyle::Fill;
    _wrap->BackColor = Theme::Bg;
    _wrap->AutoScroll = true;
    this->Controls->Add(_wrap);

    _page = gcnew Panel();
    _page->BackColor = Theme::Bg;
    _wrap->Controls->Add(_page);
}

void ProfileView::ShowSelf()
{
    _viewUser = Store::Me;
    Bus::H = gcnew Action<String^, Object^>(this, &ProfileView::OnAction);
    RebuildSelf();
    AppCtx::Win->RefreshTopbar();
}

void ProfileView::OpenProfile(String^ u)
{
    _viewUser = u;
    Bus::H = gcnew Action<String^, Object^>(this, &ProfileView::OnAction);
    RebuildOther();
}

void ProfileView::RefreshView()
{
    if (_viewUser == Store::Me) RebuildSelf();
    else RebuildOther();
}

void ProfileView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    _page->Width = Math::Max(360, this->ClientSize.Width - 28);
}

// ===================== self =====================
void ProfileView::RebuildSelf()
{
    _page->Controls->Clear();
    _page->Width = Math::Max(360, this->ClientSize.Width - 28);
    Dictionary<String^, Object^>^ me = Store::MeObj();
    if (me == nullptr) return;

    int y = 12;
    int cw = _page->Width - 2 * _padd;

    // header card
    Panel^ head = gcnew Panel();
    head->BackColor = Theme::Card;
    head->Location = Drawing::Point(_padd, y);
    head->Width = cw;
    head->Height = 96;
    _page->Controls->Add(head);

    AvatarControl^ av = gcnew AvatarControl();
    av->SetData((int)J::N(me, "a"), J::S(me, "ai"), Store::DisplayDec(me), 72);
    av->Location = Drawing::Point(16, 12);
    head->Controls->Add(av);

    Label^ name = Ui::Lbl(J::S(me, "d"), 15.0f, true, Theme::Text);
    name->Location = Drawing::Point(100, 14);
    head->Controls->Add(name);
    StringBuilder^ tags = gcnew StringBuilder();
    if (J::B(me, "st")) tags->Append("[STAFF]  ");
    if (J::B(me, "m")) tags->Append("[ADMIN]  ");
    if (Store::PlusOn(Store::Me)) tags->Append("⭐ Plus  ");
    Label^ tagL = Ui::Lbl(tags->ToString(), 9.0f, true, Theme::Green);
    tagL->Location = Drawing::Point(100, 42);
    head->Controls->Add(tagL);
    Label^ info = Ui::Lbl("@" + Store::Me + "  ·  💎 " + Ui::Fmt(Store::Gems(Store::Me)) + "  ·  🥮 " + Ui::Fmt(Store::McBalance(Store::Me)), 9.0f, false, Theme::Muted);
    info->Location = Drawing::Point(100, 64);
    head->Controls->Add(info);
    y += 104;

    // edit section
    Panel^ ed = gcnew Panel();
    ed->BackColor = Theme::Card;
    ed->Location = Drawing::Point(_padd, y);
    ed->Width = cw;
    _page->Controls->Add(ed);
    int ey = 12;
    Label^ t1 = Ui::Lbl("✏️  Chỉnh sửa hồ sơ", 11.0f, true, Theme::Text);
    t1->Location = Drawing::Point(14, ey); ed->Controls->Add(t1); ey += 28;

    Label^ l1 = Ui::Lbl("Tên hiển thị", 9.0f, true, Theme::Muted);
    l1->Location = Drawing::Point(14, ey); ed->Controls->Add(l1); ey += 20;
    _dName = gcnew TextBox();
    _dName->Text = J::S(me, "d");
    _dName->BackColor = Theme::Card2; _dName->ForeColor = Theme::Text;
    _dName->BorderStyle = BorderStyle::FixedSingle;
    _dName->Location = Drawing::Point(14, ey); _dName->Width = cw - 28; _dName->Height = 28;
    ed->Controls->Add(_dName); ey += 38;

    Label^ l2 = Ui::Lbl("Giới thiệu", 9.0f, true, Theme::Muted);
    l2->Location = Drawing::Point(14, ey); ed->Controls->Add(l2); ey += 20;
    _bio = gcnew TextBox();
    _bio->Text = J::S(me, "b");
    _bio->Multiline = true;
    _bio->BackColor = Theme::Card2; _bio->ForeColor = Theme::Text;
    _bio->BorderStyle = BorderStyle::FixedSingle;
    _bio->Location = Drawing::Point(14, ey); _bio->Width = cw - 28; _bio->Height = 60;
    ed->Controls->Add(_bio); ey += 72;

    Button^ save = Ui::AccentBtn("💾  Lưu thay đổi", 150, 34);
    save->Location = Drawing::Point(14, ey); save->Click += gcnew EventHandler(this, &ProfileView::OnSaveProfile);
    ed->Controls->Add(save); ey += 46;
    ed->Height = ey + 6;
    y += ed->Height + 12;

    // avatar picker
    Panel^ ap = gcnew Panel();
    ap->BackColor = Theme::Card;
    ap->Location = Drawing::Point(_padd, y);
    ap->Width = cw;
    _page->Controls->Add(ap);
    int ay = 12;
    Label^ t2 = Ui::Lbl("😊  Ảnh đại diện", 11.0f, true, Theme::Text);
    t2->Location = Drawing::Point(14, ay); ap->Controls->Add(t2); ay += 30;
    _avGrid = gcnew FlowLayoutPanel();
    _avGrid->FlowDirection = FlowDirection::LeftToRight;
    _avGrid->WrapContents = true;
    _avGrid->BackColor = Theme::Card;
    _avGrid->Location = Drawing::Point(14, ay);
    _avGrid->Width = cw - 28;
    ap->Controls->Add(_avGrid);
    for (int i = 0; i < Catalog::AvEmoji->Length; i++)
    {
        Button^ b = Ui::Btn(Catalog::AvEmoji[i], 40, 40, Theme::Card2, Theme::Text, false);
        b->Font = gcnew Font("Segoe UI Emoji", 15.0f, FontStyle::Regular, GraphicsUnit::Pixel);
        b->Tag = i;
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = Theme::Border;
        b->Click += gcnew EventHandler(this, &ProfileView::OnPickAv);
        _avGrid->Controls->Add(b);
    }
    ay += 96;
    ap->Height = ay + 6;
    y += ap->Height + 12;

    // password
    Panel^ pw = gcnew Panel();
    pw->BackColor = Theme::Card;
    pw->Location = Drawing::Point(_padd, y);
    pw->Width = cw;
    _page->Controls->Add(pw);
    int py = 12;
    Label^ t3 = Ui::Lbl("🔒  Đổi mật khẩu", 11.0f, true, Theme::Text);
    t3->Location = Drawing::Point(14, py); pw->Controls->Add(t3); py += 28;
    Label^ w1 = Ui::Lbl("Mật khẩu hiện tại", 9.0f, true, Theme::Muted);
    w1->Location = Drawing::Point(14, py); pw->Controls->Add(w1); py += 20;
    TextBox^ oldPw = gcnew TextBox();
    oldPw->UseSystemPasswordChar = true;
    oldPw->BackColor = Theme::Card2; oldPw->ForeColor = Theme::Text;
    oldPw->BorderStyle = BorderStyle::FixedSingle;
    oldPw->Location = Drawing::Point(14, py); oldPw->Width = cw - 28; oldPw->Height = 28;
    oldPw->Tag = "oldpw";
    pw->Controls->Add(oldPw); py += 38;
    Label^ w2 = Ui::Lbl("Mật khẩu mới", 9.0f, true, Theme::Muted);
    w2->Location = Drawing::Point(14, py); pw->Controls->Add(w2); py += 20;
    TextBox^ newPw = gcnew TextBox();
    newPw->UseSystemPasswordChar = true;
    newPw->BackColor = Theme::Card2; newPw->ForeColor = Theme::Text;
    newPw->BorderStyle = BorderStyle::FixedSingle;
    newPw->Location = Drawing::Point(14, py); newPw->Width = cw - 28; newPw->Height = 28;
    newPw->Tag = "newpw";
    pw->Controls->Add(newPw); py += 38;
    Label^ w3 = Ui::Lbl("Nhập lại mật khẩu mới", 9.0f, true, Theme::Muted);
    w3->Location = Drawing::Point(14, py); pw->Controls->Add(w3); py += 20;
    TextBox^ newPw2 = gcnew TextBox();
    newPw2->UseSystemPasswordChar = true;
    newPw2->BackColor = Theme::Card2; newPw2->ForeColor = Theme::Text;
    newPw2->BorderStyle = BorderStyle::FixedSingle;
    newPw2->Location = Drawing::Point(14, py); newPw2->Width = cw - 28; newPw2->Height = 28;
    newPw2->Tag = "newpw2";
    pw->Controls->Add(newPw2); py += 38;
    Button^ pwBtn = Ui::AccentBtn("Đổi mật khẩu", 140, 32);
    pwBtn->Tag = oldPw;
    pwBtn->Click += gcnew EventHandler(this, &ProfileView::OnChangePw);
    pwBtn->Location = Drawing::Point(14, py);
    pw->Controls->Add(pwBtn); py += 44;
    pw->Height = py + 6;
    y += pw->Height + 12;

    // cosmetics
    Panel^ cos = gcnew Panel();
    cos->BackColor = Theme::Card;
    cos->Location = Drawing::Point(_padd, y);
    cos->Width = cw;
    _page->Controls->Add(cos);
    int cy = 12;
    Label^ t4 = Ui::Lbl("🎨  Trang phục của tôi", 11.0f, true, Theme::Text);
    t4->Location = Drawing::Point(14, cy); cos->Controls->Add(t4); cy += 28;

    Label^ d1 = Ui::Lbl("Khung đại diện (đang dùng: #" + Ui::Str(J::N(me, "dec")) + ")", 9.0f, true, Theme::Muted);
    d1->Location = Drawing::Point(14, cy); cos->Controls->Add(d1); cy += 22;
    int drow = 0;
    for each (ShopItem^ it in Catalog::Items)
    {
        if (it->Type != "dec") continue;
        if (!Store::Owns(Store::Me, it->Id)) continue;
        Button^ b = Ui::Btn(it->Emo + " " + it->Name, 170, 30, Theme::Card2, Theme::Text, false);
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = ((int)J::N(me, "dec") == it->Idx) ? Theme::Accent : Theme::Border;
        b->Tag = it->Idx;
        b->Click += gcnew EventHandler(this, &ProfileView::OnEquipDec);
        b->Location = Drawing::Point(14 + (drow % 2) * 180, cy);
        cos->Controls->Add(b);
        drow++;
        if (drow % 2 == 0) cy += 36;
    }
    if (drow % 2 != 0) cy += 36;
    if (drow == 0) { Label^ none = Ui::Lbl("Bạn chưa sở hữu khung nào — ghé Cửa hàng Gems nhé 💎", 8.5f, false, Theme::Muted); none->Location = Drawing::Point(14, cy); cos->Controls->Add(none); cy += 26; }
    Button^ undec = Ui::Btn("Không khung", 100, 28, Theme::Card2, Theme::Muted, false);
    undec->FlatAppearance->BorderSize = 1;
    undec->FlatAppearance->BorderColor = Theme::Border;
    undec->Click += gcnew EventHandler(this, &ProfileView::OnUnEquip);
    undec->Tag = "dec";
    undec->Location = Drawing::Point(14, cy);
    cos->Controls->Add(undec); cy += 40;

    Label^ d2 = Ui::Lbl("Hiệu ứng hồ sơ (đang dùng: #" + Ui::Str(J::N(me, "peff")) + ")", 9.0f, true, Theme::Muted);
    d2->Location = Drawing::Point(14, cy); cos->Controls->Add(d2); cy += 22;
    int prow = 0;
    for each (ShopItem^ it in Catalog::Items)
    {
        if (it->Type != "peff") continue;
        if (!Store::Owns(Store::Me, it->Id)) continue;
        Button^ b = Ui::Btn(it->Emo + " " + it->Name, 170, 30, Theme::Card2, Theme::Text, false);
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = ((int)J::N(me, "peff") == it->Idx) ? Theme::Accent : Theme::Border;
        b->Tag = it->Idx;
        b->Click += gcnew EventHandler(this, &ProfileView::OnEquipPf);
        b->Location = Drawing::Point(14 + (prow % 2) * 180, cy);
        cos->Controls->Add(b);
        prow++;
        if (prow % 2 == 0) cy += 36;
    }
    if (prow % 2 != 0) cy += 36;
    if (prow == 0) { Label^ none2 = Ui::Lbl("Bạn chưa sở hữu hiệu ứng nào", 8.5f, false, Theme::Muted); none2->Location = Drawing::Point(14, cy); cos->Controls->Add(none2); cy += 26; }
    Button^ unpf = Ui::Btn("Không hiệu ứng", 100, 28, Theme::Card2, Theme::Muted, false);
    unpf->FlatAppearance->BorderSize = 1;
    unpf->FlatAppearance->BorderColor = Theme::Border;
    unpf->Click += gcnew EventHandler(this, &ProfileView::OnUnEquip);
    unpf->Tag = "peff";
    unpf->Location = Drawing::Point(14, cy);
    cos->Controls->Add(unpf); cy += 44;
    cos->Height = cy + 6;
    y += cos->Height + 12;

    // own posts
    Label^ t5 = Ui::Lbl("📝  Bài viết của tôi", 12.0f, true, Theme::Text);
    t5->Location = Drawing::Point(_padd, y); _page->Controls->Add(t5); y += 28;
    _page->Height = y + 60;
    RefreshPosts(Store::Me);
}

// ===================== other user =====================
void ProfileView::RebuildOther()
{
    _page->Controls->Clear();
    _page->Width = Math::Max(360, this->ClientSize.Width - 28);
    Dictionary<String^, Object^>^ u = Store::User(_viewUser);
    if (u == nullptr) return;
    int cw = _page->Width - 2 * _padd;
    int y = 12;

    Panel^ head = gcnew Panel();
    head->BackColor = Theme::Card;
    head->Location = Drawing::Point(_padd, y);
    head->Width = cw;
    head->Height = 150;
    _page->Controls->Add(head);

    AvatarControl^ av = gcnew AvatarControl();
    av->SetData((int)J::N(u, "a"), J::S(u, "ai"), Store::DisplayDec(u), 84);
    av->Location = Drawing::Point(16, 16);
    head->Controls->Add(av);

    StringBuilder^ nm = gcnew StringBuilder();
    nm->Append(J::S(u, "d"));
    if (J::B(u, "st")) nm->Append("  [STAFF]");
    if (J::B(u, "m")) nm->Append("  [ADMIN]");
    if (Store::UserPlus(u)) nm->Append("  ⭐");
    Label^ name = Ui::Lbl(nm->ToString(), 14.0f, true, Theme::Text);
    name->Location = Drawing::Point(112, 16);
    head->Controls->Add(name);
    Label^ uname = Ui::Lbl("@" + _viewUser, 9.0f, false, Theme::Muted);
    uname->Location = Drawing::Point(112, 44);
    head->Controls->Add(uname);
    Label^ bio = Ui::Lbl(J::S(u, "b") == "" ? "(chưa có giới thiệu)" : J::S(u, "b"), 9.5f, false, Theme::Text);
    bio->AutoSize = false;
    bio->Width = cw - 140;
    bio->Height = 36;
    bio->Location = Drawing::Point(112, 66);
    head->Controls->Add(bio);

    // friend button
    String^ rel = Store::Rel(Store::Me, _viewUser);
    Button^ fb = nullptr;
    if (_viewUser != Store::Me)
    {
        if (rel == "friend")
        {
            fb = Ui::Btn("💬  Nhắn tin", 130, 34, Theme::Accent, Color::White, true);
            fb->Click += gcnew EventHandler(this, &ProfileView::OnChatBtn);
            fb->Location = Drawing::Point(16, 104);
            head->Controls->Add(fb);
            Button^ ub = Ui::Btn("Huỷ kết bạn", 110, 34, Theme::Card2, Theme::Danger, false);
            ub->FlatAppearance->BorderSize = 1;
            ub->FlatAppearance->BorderColor = Theme::Border;
            ub->Tag = "unfriend";
            ub->Click += gcnew EventHandler(this, &ProfileView::OnFriendBtn);
            ub->Location = Drawing::Point(156, 104);
            head->Controls->Add(ub);
        }
        else if (rel == "in")
        {
            Button^ ab = Ui::Btn("✅  Chấp nhận", 130, 34, Theme::Green, Color::White, true);
            ab->Tag = "accept";
            ab->Click += gcnew EventHandler(this, &ProfileView::OnFriendBtn);
            ab->Location = Drawing::Point(16, 104);
            head->Controls->Add(ab);
            Button^ rb = Ui::Btn("❌  Từ chối", 110, 34, Theme::Card2, Theme::Muted, false);
            rb->FlatAppearance->BorderSize = 1;
            rb->FlatAppearance->BorderColor = Theme::Border;
            rb->Tag = "reject";
            rb->Click += gcnew EventHandler(this, &ProfileView::OnFriendBtn);
            rb->Location = Drawing::Point(156, 104);
            head->Controls->Add(rb);
        }
        else if (rel == "out")
        {
            Label^ w = Ui::Lbl("⏳  Đã gửi lời mời kết bạn", 9.5f, false, Theme::Muted);
            w->Location = Drawing::Point(16, 110);
            head->Controls->Add(w);
        }
        else
        {
            Button^ ab = Ui::Btn("➕  Kết bạn", 130, 34, Theme::Accent, Color::White, true);
            ab->Tag = "send";
            ab->Click += gcnew EventHandler(this, &ProfileView::OnFriendBtn);
            ab->Location = Drawing::Point(16, 104);
            head->Controls->Add(ab);
        }
    }
    y += 158;

    Label^ t5 = Ui::Lbl("📝  Bài viết của @" + _viewUser, 12.0f, true, Theme::Text);
    t5->Location = Drawing::Point(_padd, y); _page->Controls->Add(t5); y += 28;
    _page->Height = y + 60;
    RefreshPosts(_viewUser);
}

void ProfileView::RefreshPosts(String^ author)
{
    // remove old post cards (they were added directly to _page)
    ArrayList^ toRemove = gcnew ArrayList();
    for each (Control^ c in _page->Controls)
        if (c->Tag != nullptr && c->Tag->ToString() == "post") toRemove->Add(c);
    for (int i = 0; i < toRemove->Count; i++)
    {
        Control^ c = (Control^)toRemove[i];
        _page->Controls->Remove(c);
        c->Dispose();
    }
    ArrayList^ src = Store::Posts();
    ArrayList^ mine = gcnew ArrayList();
    for (int i = 0; i < src->Count; i++)
    {
        Dictionary<String^, Object^>^ p = dynamic_cast<Dictionary<String^, Object^>^>(src[i]);
        if (p != nullptr && J::S(p, "a") == author) mine->Add(p);
    }
    for (int i = 0; i < mine->Count; i++)
        for (int j = i + 1; j < mine->Count; j++)
        {
            Dictionary<String^, Object^>^ a = dynamic_cast<Dictionary<String^, Object^>^>(mine[i]);
            Dictionary<String^, Object^>^ b = dynamic_cast<Dictionary<String^, Object^>^>(mine[j]);
            if (a != nullptr && b != nullptr && J::N(b, "x") > J::N(a, "x")) { mine[i] = b; mine[j] = a; }
        }
    int y = _page->Height - 60 + 4;
    for (int i = 0; i < Math::Min(mine->Count, 100); i++)
    {
        Dictionary<String^, Object^>^ p = dynamic_cast<Dictionary<String^, Object^>^>(mine[i]);
        if (p == nullptr) continue;
        PostCard^ c = gcnew PostCard();
        c->Set(p);
        c->SetWidth(_page->Width - 2 * _padd);
        if (_cmtOpen->Contains(J::N(p, "i"))) c->SetCmtOpen(true);
        c->Tag = "post";
        c->Location = Drawing::Point(_padd, y);
        _page->Controls->Add(c);
        y += c->Height + 10;
    }
    if (mine->Count == 0)
    {
        Label^ n = Ui::Lbl("Chưa có bài viết nào", 9.5f, false, Theme::Muted);
        n->Tag = "post";
        n->Location = Drawing::Point(_padd, y);
        _page->Controls->Add(n);
        y += 30;
    }
    _page->Height = y + 10;
}

// ===================== handlers =====================
void ProfileView::OnSaveProfile(Object^ s, EventArgs^)
{
    String^ d = Utils::Clean(_dName->Text, 30);
    if (d == "") { Ui::Warn("Tên hiển thị không được để trống"); return; }
    String^ b = Utils::Clean(_bio->Text, 300);
    Dictionary<String^, Object^>^ me = Store::MeObj();
    J::P(me, "d", d);
    J::P(me, "b", b);
    J::P(me, "a", _av);
    Store::Save();
    AppCtx::Win->RefreshTopbar();
    Toast::Show("Đã lưu hồ sơ ✨", true);
}

void ProfileView::OnChangePw(Object^ s, EventArgs^)
{
    Button^ btn = (Button^)s;
    TextBox^ oldPw = (TextBox^)btn->Tag;
    TextBox^ newPw = nullptr;
    TextBox^ newPw2 = nullptr;
    for each (Control^ c in btn->Parent->Controls)
    {
        TextBox^ tb = dynamic_cast<TextBox^>(c);
        if (tb == nullptr) continue;
        if (tb->Tag != nullptr && tb->Tag->ToString() == "newpw") newPw = tb;
        else if (tb->Tag != nullptr && tb->Tag->ToString() == "newpw2") newPw2 = tb;
    }
    if (newPw == nullptr || newPw2 == nullptr) return;
    if (newPw->Text != newPw2->Text) { Ui::Warn("Mật khẩu mới nhập lại không khớp"); return; }
    String^ err = "";
    if (!Store::ChangePw(oldPw->Text, newPw->Text, err)) { Ui::Warn(err); return; }
    Toast::Show("Đã đổi mật khẩu 🔒", true);
    oldPw->Text = ""; newPw->Text = ""; newPw2->Text = "";
}

void ProfileView::OnPickAv(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    _av = (int)b->Tag;
    if (_selAv != nullptr) { _selAv->BackColor = Theme::Card2; _selAv->FlatAppearance->BorderColor = Theme::Border; }
    _selAv = b;
    _selAv->BackColor = Theme::AccentSoft;
    _selAv->FlatAppearance->BorderColor = Theme::Accent;
}

void ProfileView::OnFriendBtn(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ op = (String^)b->Tag;
    if (op == "send") { if (!Store::SendReq(_viewUser)) { Ui::Warn("Không thể gửi lời mời"); return; } Toast::Show("Đã gửi lời mời kết bạn", true); }
    else if (op == "accept") { Store::AcceptReq(_viewUser); Toast::Show("Đã kết bạn 🎉", true); }
    else if (op == "reject") { Store::RejectReq(_viewUser); Toast::Show("Đã từ chối lời mời", true); }
    else if (op == "unfriend") { if (!Ui::Confirm("Huỷ kết bạn với @" + _viewUser + "?")) return; Store::RemoveFriend(_viewUser); }
    RebuildOther();
    AppCtx::Win->RefreshTopbar();
}

void ProfileView::OnChatBtn(Object^ s, EventArgs^)
{
    AppCtx::Nav("chat", _viewUser);
}

void ProfileView::OnEquipDec(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    Store::SetCosmetic("dec", (int)b->Tag);
    Toast::Show("Đã trang bị khung", true);
    RebuildSelf();
}

void ProfileView::OnEquipPf(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    Store::SetCosmetic("peff", (int)b->Tag);
    Toast::Show("Đã trang bị hiệu ứng", true);
    RebuildSelf();
}

void ProfileView::OnUnEquip(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    Store::SetCosmetic(b->Tag->ToString(), 0);
    RebuildSelf();
}

// ===================== action bus (for post cards) =====================
void ProfileView::OnAction(String^ action, Object^ arg)
{
    if (action->StartsWith("react:"))
    {
        long long pid = Convert::ToInt64(action->Substring(6));
        Store::ToggleReact(pid, (String^)arg);
        AppCtx::Win->RefreshTopbar();
        RefreshView();
    }
    else if (action == "save")
    {
        Store::ToggleSave((long long)Convert::ToInt64(arg));
        RefreshView();
    }
    else if (action == "del")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        if (!Ui::Confirm("Xóa bài viết này?")) return;
        Store::DeletePost(pid);
        RefreshView();
    }
    else if (action == "edit")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        Dictionary<String^, Object^>^ p = Store::PostById(pid);
        if (p == nullptr) return;
        String^ nt = Ui::Prompt("Sửa bài viết", "Nội dung:", J::S(p, "t"));
        if (nt == nullptr) return;
        nt = Utils::Clean(nt, 3000);
        if (nt == "") return;
        Store::EditPost(pid, nt);
        RefreshView();
    }
    else if (action == "cmt")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        if (_cmtOpen->Contains(pid)) _cmtOpen->Remove(pid);
        else _cmtOpen->Add(pid);
        RefreshView();
    }
    else if (action->StartsWith("cmtadd:"))
    {
        long long pid = Convert::ToInt64(action->Substring(7));
        long long cid = 0;
        Store::AddComment(pid, (String^)arg, cid);
        AppCtx::Win->RefreshTopbar();
        RefreshView();
    }
    else if (action->StartsWith("cmtdel:"))
    {
        long long pid = Convert::ToInt64(action->Substring(7));
        Store::DeleteComment(pid, (long long)Convert::ToInt64(arg));
        RefreshView();
    }
    else if (action == "prof")
    {
        AppCtx::Nav("profile", arg);
    }
}
