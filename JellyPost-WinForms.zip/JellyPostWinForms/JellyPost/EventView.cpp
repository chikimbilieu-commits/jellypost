#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "EventView.h"

EventView::EventView()
{
    this->BackColor = Theme::Bg;
    _padd = 24;
    _wrap = gcnew Panel();
    _wrap->Dock = DockStyle::Fill;
    _wrap->BackColor = Theme::Bg;
    _wrap->AutoScroll = true;
    this->Controls->Add(_wrap);
    _page = gcnew Panel();
    _page->BackColor = Theme::Bg;
    _wrap->Controls->Add(_page);
}

void EventView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    _page->Width = Math::Max(400, this->ClientSize.Width - 28);
}

void EventView::RefreshView()
{
    Rebuild();
}

void EventView::Rebuild()
{
    _page->Controls->Clear();
    _page->Width = Math::Max(400, this->ClientSize.Width - 28);
    int cw = _page->Width - 2 * _padd;
    int y = 12;

    if (!Store::McEnabled())
    {
        Label^ off = Ui::Lbl("🌕  Sự kiện Trung Thu đang đóng cửa", 13.0f, true, Theme::Danger);
        off->Location = Drawing::Point(_padd, y); _page->Controls->Add(off);
        _page->Height = y + 60;
        return;
    }

    // balance + login card
    Panel^ bal = gcnew Panel();
    bal->BackColor = Theme::Card;
    bal->Location = Drawing::Point(_padd, y);
    bal->Width = cw;
    bal->Height = 92;
    _page->Controls->Add(bal);
    Label^ b1 = Ui::Lbl("🥮  Bánh Trung thu của bạn", 9.0f, false, Theme::Muted);
    b1->Location = Drawing::Point(16, 12); bal->Controls->Add(b1);
    Label^ mcL = Ui::Lbl(Ui::Fmt(Store::McBalance(Store::Me)) + " 🥮", 18.0f, true, Theme::Accent);
    mcL->Location = Drawing::Point(16, 34); bal->Controls->Add(mcL);

    Button^ login = Ui::AccentBtn("☀️  Điểm danh mỗi ngày (+5 🥮)", 210, 38);
    login->Click += gcnew EventHandler(this, &EventView::OnLogin);
    login->Location = Drawing::Point(cw - 230, 26);
    bal->Controls->Add(login);
    long long streakN = J::N(Store::MeObj(), "mcStreak");
    Label^ streak = Ui::Lbl("Liên tiếp: " + streakN.ToString() + " ngày  ·  cứ 7 ngày +50 🥮", 8.5f, false, Theme::Muted);
    streak->Location = Drawing::Point(cw - 230, 68);
    bal->Controls->Add(streak);
    y += 104;

    Label^ t5 = Ui::Lbl("🛍️  Quầy đổi quà Trung Thu", 12.0f, true, Theme::Text);
    t5->Location = Drawing::Point(_padd, y); _page->Controls->Add(t5); y += 30;

    FlowLayoutPanel^ grid = gcnew FlowLayoutPanel();
    grid->FlowDirection = FlowDirection::LeftToRight;
    grid->WrapContents = true;
    grid->BackColor = Theme::Bg;
    grid->Location = Drawing::Point(_padd, y);
    grid->Width = cw;
    _page->Controls->Add(grid);

    for each (ShopItem^ it in Catalog::McShop)
    {
        bool owned = Store::Owns(Store::Me, it->Id);
        int cost = it->Cost;
        if (Store::PlusOn(Store::Me)) cost = (int)Math::Round(cost * 0.8);
        Panel^ card = gcnew Panel();
        card->BackColor = Theme::Card;
        card->Width = 240;
        card->Height = 118;
        card->Margin = Padding(0, 0, 10, 10);
        grid->Controls->Add(card);
        Label^ emo = Ui::Lbl(it->Emo, 20.0f, false, Theme::Text);
        emo->Location = Drawing::Point(12, 10); card->Controls->Add(emo);
        Label^ nm = Ui::Lbl(it->Name, 9.0f, true, Theme::Text);
        nm->AutoSize = false;
        nm->Width = 216;
        nm->Height = 30;
        nm->Location = Drawing::Point(8, 44); card->Controls->Add(nm);
        if (it->Type == "pick")
        {
            Label^ pr = Ui::Lbl(Ui::Str(cost) + " 🥮  (tự chọn)", 9.0f, true, Theme::Accent);
            pr->Location = Drawing::Point(8, 76); card->Controls->Add(pr);
            if (!owned)
            {
                Button^ buy = Ui::Btn("Chọn khung", 90, 28, Theme::Accent, Color::White, true);
                buy->Tag = it;
                buy->Click += gcnew EventHandler(this, &EventView::OnPick);
                buy->Location = Drawing::Point(140, 84);
                card->Controls->Add(buy);
            }
            else
            {
                Label^ have = Ui::Lbl("✅ Đã có", 8.5f, true, Theme::Green);
                have->Location = Drawing::Point(156, 90); card->Controls->Add(have);
            }
        }
        else
        {
            Label^ pr = Ui::Lbl(owned ? "Đã sở hữu" : Ui::Str(cost) + " 🥮", 9.0f, true, owned ? Theme::Green : Theme::Accent);
            pr->Location = Drawing::Point(8, 76); card->Controls->Add(pr);
            if (!owned)
            {
                Button^ buy = Ui::Btn("Đổi", 70, 28, Theme::Accent, Color::White, true);
                buy->Tag = it->Id;
                buy->Click += gcnew EventHandler(this, &EventView::OnBuy);
                buy->Location = Drawing::Point(162, 84);
                card->Controls->Add(buy);
            }
        }
    }
    int rows = (int)Math::Ceiling((double)Catalog::McShop->Count / Math::Max(1, cw / 250));
    grid->Height = rows * 128;
    y += grid->Height + 16;

    _page->Height = y + 12;
}

void EventView::OnLogin(Object^ s, EventArgs^)
{
    String^ msg = "";
    Dictionary<String^, Object^>^ r = Store::McDailyLogin(msg);
    if (r == nullptr) { Ui::Info(msg); return; }
    long long gained = J::N(r, "gained");
    long long bonus = J::N(r, "bonus");
    long long streak = J::N(r, "streak");
    String^ txt = "Bạn nhận được " + Ui::Str(gained) + " 🥮! (liên tiếp " + Ui::Str(streak) + " ngày)";
    if (bonus > 0) txt += "\n🎉 THƯỞNG CHUỖI 7 NGÀY: +" + Ui::Str(bonus) + " 🥮!";
    Ui::Info(txt);
    AppCtx::Win->RefreshTopbar();
    Rebuild();
}

void EventView::OnBuy(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ err = "";
    if (!Store::BuyMcItem((String^)b->Tag, err)) { Ui::Warn(err); return; }
    AppCtx::Win->RefreshTopbar();
    Toast::Show("Đã đổi quà! 🎉", true);
    Rebuild();
}

void EventView::OnPick(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    ShopItem^ it = (ShopItem^)b->Tag;
    PickDialog(it->PickT, it->Cost);
}

// ===================== pick dialog =====================
ref class PickData
{
public:
    int Tier;
    String^ Id;
};

void EventView::PickDialog(int tier, int cost)
{
    int lo = 0, hi = 80;
    if (tier == 2) { lo = 120; hi = 300; }
    if (Store::PlusOn(Store::Me)) cost = (int)Math::Round(cost * 0.8);

    Form^ f = gcnew Form();
    f->Text = "Chọn khung — " + Ui::Str(cost) + " 🥮";
    f->StartPosition = FormStartPosition::CenterParent;
    f->ClientSize = Drawing::Size(480, 420);
    f->BackColor = Theme::Bg;
    f->ForeColor = Theme::Text;
    f->Font = Ui::F(9.5f, false);
    f->MinimizeBox = false;
    f->MaximizeBox = false;
    f->FormBorderStyle = FormBorderStyle::FixedDialog;

    Label^ hint = Ui::Lbl("Chọn một khung trong khoảng " + Ui::Str(lo) + "–" + Ui::Str(hi) + " 💎 mà bạn chưa sở hữu:", 9.5f, false, Theme::Muted);
    hint->Location = Drawing::Point(14, 12);
    f->Controls->Add(hint);

    FlowLayoutPanel^ grid = gcnew FlowLayoutPanel();
    grid->Location = Drawing::Point(14, 40);
    grid->Size = Drawing::Size(452, 340);
    grid->FlowDirection = FlowDirection::LeftToRight;
    grid->WrapContents = true;
    grid->BackColor = Theme::Bg;
    grid->AutoScroll = true;
    f->Controls->Add(grid);

    for each (ShopItem^ it in Catalog::Items)
    {
        if (it->Type != "dec" && it->Type != "peff") continue;
        if (it->Cost < lo || it->Cost > hi) continue;
        if (Store::Owns(Store::Me, it->Id)) continue;
        Button^ b = Ui::Btn(it->Emo + "  " + it->Name + "  (" + Ui::Str(it->Cost) + " 💎)", 210, 34, Theme::Card2, Theme::Text, false);
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = Theme::Border;
        PickData^ pd = gcnew PickData();
        pd->Tier = tier;
        pd->Id = it->Id;
        b->Tag = pd;
        b->Click += gcnew EventHandler(this, &EventView::OnPickSel);
        grid->Controls->Add(b);
    }
    f->ShowDialog(this);
}

void EventView::OnPickSel(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    Form^ f = b->FindForm();
    PickData^ pd = (PickData^)b->Tag;
    if (f != nullptr) f->Close();
    String^ err = "";
    if (!Store::McPick(pd->Tier, pd->Id, err)) { Ui::Warn(err); return; }
    AppCtx::Win->RefreshTopbar();
    Toast::Show("Đã đổi quà! 🎉", true);
    Rebuild();
}
