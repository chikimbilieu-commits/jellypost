#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "ChatView.h"

ChatView::ChatView()
{
    this->BackColor = Theme::Bg;
    _other = "";
    _empty = nullptr;

    // left: conversations
    Panel^ left = gcnew Panel();
    left->Dock = DockStyle::Left;
    left->Width = 250;
    left->BackColor = Theme::Card;
    this->Controls->Add(left);

    Label^ title = Ui::Lbl("💬  Tin nhắn", 12.0f, true, Theme::Text);
    title->Location = Drawing::Point(14, 12);
    left->Controls->Add(title);

    _convP = gcnew Panel();
    _convP->Dock = DockStyle::Fill;
    _convP->BackColor = Theme::Card;
    _convP->AutoScroll = true;
    _convP->Location = Drawing::Point(0, 44);
    left->Controls->Add(_convP);

    // right: messages
    Panel^ right = gcnew Panel();
    right->Dock = DockStyle::Fill;
    right->BackColor = Theme::Bg;
    this->Controls->Add(right);

    Panel^ inputBar = gcnew Panel();
    inputBar->Dock = DockStyle::Bottom;
    inputBar->Height = 58;
    inputBar->BackColor = Theme::Card;
    right->Controls->Add(inputBar);

    _input = gcnew TextBox();
    _input->Multiline = true;
    _input->BackColor = Theme::Card2;
    _input->ForeColor = Theme::Text;
    _input->BorderStyle = BorderStyle::FixedSingle;
    _input->Location = Drawing::Point(12, 10);
    _input->Width = 640;
    _input->Height = 38;
    _input->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
    inputBar->Controls->Add(_input);

    Button^ send = Ui::AccentBtn("Gửi", 80, 38);
    send->Anchor = AnchorStyles::Top | AnchorStyles::Right;
    send->Location = Drawing::Point(680, 10);
    send->Click += gcnew EventHandler(this, &ChatView::OnSend);
    inputBar->Controls->Add(send);

    _msgWrap = gcnew Panel();
    _msgWrap->Dock = DockStyle::Fill;
    _msgWrap->BackColor = Theme::Bg;
    _msgWrap->AutoScroll = true;
    right->Controls->Add(_msgWrap);

    _msgList = gcnew Panel();
    _msgList->BackColor = Theme::Bg;
    _msgWrap->Controls->Add(_msgList);

    _input->KeyDown += gcnew KeyEventHandler(this, &ChatView::OnKey);
}

void ChatView::OnKey(Object^ s, KeyEventArgs^ e)
{
    if (e->KeyCode == Keys::Enter && !e->Shift)
    {
        OnSend(nullptr, EventArgs::Empty);
        e->SuppressKeyPress = true;
    }
}

void ChatView::RefreshView()
{
    RefreshConvs();
    LoadMsgs();
}

void ChatView::RefreshConvs()
{
    _convP->Controls->Clear();
    ArrayList^ convs = Store::GetConvs();
    int y = 4;
    for (int i = 0; i < convs->Count; i++)
    {
        Dictionary<String^, Object^>^ cv = dynamic_cast<Dictionary<String^, Object^>^>(convs[i]);
        if (cv == nullptr) continue;
        String^ other = J::S(cv, "other");
        Dictionary<String^, Object^>^ u = Store::User(other);
        bool sel = other == _other;
        Panel^ row = gcnew Panel();
        row->Width = 238;
        row->Height = 52;
        row->BackColor = sel ? Theme::AccentSoft : Theme::Card;
        row->Cursor = Cursors::Hand;
        row->Tag = other;
        row->Click += gcnew EventHandler(this, &ChatView::OnConvClick);
        row->Location = Drawing::Point(6, y);
        _convP->Controls->Add(row);

        Label^ nm = Ui::Lbl(u == nullptr ? other : J::S(u, "d"), 9.5f, true, Theme::Text);
        nm->Location = Drawing::Point(8, 5);
        nm->Tag = other;
        nm->Click += gcnew EventHandler(this, &ChatView::OnConvClick);
        row->Controls->Add(nm);

        Label^ last = Ui::Lbl("", 8.5f, false, Theme::Muted);
        last->AutoSize = false;
        last->Width = 176;
        last->Height = 16;
        last->Text = J::S(cv, "last");
        last->Location = Drawing::Point(8, 27);
        last->Tag = other;
        last->Click += gcnew EventHandler(this, &ChatView::OnConvClick);
        row->Controls->Add(last);

        int unread = (int)J::N(cv, "unread");
        if (unread > 0 && other != _other)
        {
            Label^ badge = Ui::Lbl(unread > 99 ? "99+" : unread.ToString(), 8.0f, true, Color::White);
            badge->BackColor = Theme::Danger;
            badge->AutoSize = false;
            badge->Size = Drawing::Size(20, 18);
            badge->TextAlign = ContentAlignment::MiddleCenter;
            badge->Location = Drawing::Point(204, y + 6);
            _convP->Controls->Add(badge);
        }
        y += 56;
    }
    if (convs->Count == 0)
    {
        Label^ n = Ui::Lbl("Chưa có cuộc trò chuyện nào", 9.5f, false, Theme::Muted);
        n->Location = Drawing::Point(12, 20);
        _convP->Controls->Add(n);
    }
}

void ChatView::OnConvClick(Object^ s, EventArgs^)
{
    Control^ c = (Control^)s;
    OpenConv((String^)c->Tag);
}

void ChatView::OpenConv(String^ other)
{
    _other = other;
    RefreshConvs();
    LoadMsgs();
    AppCtx::Win->RefreshTopbar();
}

void ChatView::LoadMsgs()
{
    _msgList->Controls->Clear();
    _msgList->Width = Math::Max(this->ClientSize.Width - 24, 600);
    if (_other == "")
    {
        _msgWrap->AutoScroll = false;
        Label^ n = Ui::Lbl("Chọn một cuộc trò chuyện ở bên trái 👈", 11.0f, false, Theme::Muted);
        n->Location = Drawing::Point(24, 24);
        _msgList->Controls->Add(n);
        return;
    }
    ArrayList^ msgs = Store::GetMsgs(_other);
    int y = 10;
    for (int i = 0; i < msgs->Count; i++)
    {
        Dictionary<String^, Object^>^ m = dynamic_cast<Dictionary<String^, Object^>^>(msgs[i]);
        if (m == nullptr) continue;
        bool mine = J::S(m, "f") == Store::Me;
        int w = Math::Min(460, Math::Max(120, this->ClientSize.Width - 300));
        Label^ b = Ui::Lbl("", 9.5f, false, mine ? Color::White : Theme::Text);
        b->AutoSize = false;
        b->Text = J::S(m, "t");
        b->Width = w;
        b->Height = Math::Max(24, Ui::MeasureText(b->Text, b->Font, w - 24) + 6);
        b->BackColor = mine ? Theme::Accent : Theme::Card;
        b->Padding = Padding(8, 4, 8, 4);
        int lw = _msgList->Width;
        b->Location = mine ? Drawing::Point(Math::Max(16, lw - 40 - w), y) : Drawing::Point(16, y);
        _msgList->Controls->Add(b);
        Label^ meta = Ui::Lbl(mine ? Store::Me + " · " + Utils::TimeAgo(J::N(m, "x"))
                                   : J::S(m, "f") + " · " + Utils::TimeAgo(J::N(m, "x")), 8.0f, false, Theme::Muted);
        meta->AutoSize = true;
        meta->Location = mine ? Drawing::Point(Math::Max(16, lw - 40 - w), y + b->Height)
                              : Drawing::Point(20, y + b->Height);
        _msgList->Controls->Add(meta);
        y += b->Height + meta->Height + 14;
    }
    _msgList->Height = y + 10;
    _msgWrap->AutoScroll = true;
    // scroll to bottom
    if (_msgWrap->VerticalScroll->Maximum > 0)
        _msgWrap->VerticalScroll->Value = _msgWrap->VerticalScroll->Maximum;
    _msgWrap->PerformLayout();
}

void ChatView::OnSend(Object^ s, EventArgs^)
{
    if (_other == "") return;
    String^ t = Utils::Clean(_input->Text, 2000);
    if (t == "") return;
    Store::SendMsg(_other, t);
    _input->Text = "";
    LoadMsgs();
}

void ChatView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    LoadMsgs();
}
