#pragma once
#include "pch.h"

public ref class AuthForm : public Form
{
public:
    AuthForm();
private:
    void Build();
    void ShowTab(bool login);
    void DoLogin();
    void DoRegister();
    void FillAvatars();
    void SelectAvatar(int idx);
    void StyleField(TextBox^ tb);
    void OnEnter(Object^ s, EventArgs^ e);
    void OnExit(Object^ s, EventArgs^ e);

    Button^ _loginTab;
    Button^ _regTab;
    Panel^ _body;
    TextBox^ _user;
    TextBox^ _pass;
    TextBox^ _ru;
    TextBox^ _rp1;
    TextBox^ _rp2;
    TextBox^ _rd;
    FlowLayoutPanel^ _avGrid;
    int _av;
    Button^ _selAv;
};
