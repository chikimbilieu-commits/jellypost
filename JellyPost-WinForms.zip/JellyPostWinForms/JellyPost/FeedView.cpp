#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "FeedView.h"

FeedView::FeedView()
{
    this->BackColor = Theme::Bg;
    _saved = false;
    _attach = gcnew ArrayList();
    _cmtOpen = gcnew HashSet<long long>();

    // scroll container
    Panel^ sc = gcnew Panel();
    sc->Dock = DockStyle::Fill;
    sc->BackColor = Theme::Bg;
    sc->AutoScroll = true;
    this->Controls->Add(sc);

    _list = gcnew Panel();
    _list->BackColor = Theme::Bg;
    sc->Controls->Add(_list);

    BuildComposer();
}

void FeedView::BuildComposer()
{
    _composer = gcnew Panel();
    _composer->BackColor = Theme::Card;
    _composer->Height = 150;
    _composer->Padding = Padding(0);
    _composer->Dock = DockStyle::Top;
    this->Controls->Add(_composer);

    _modeLbl = Ui::Lbl("Bảng tin", 13.0f, true, Theme::Text);
    _modeLbl->Location = Drawing::Point(16, 10);
    _composer->Controls->Add(_modeLbl);

    _txt = gcnew TextBox();
    _txt->Multiline = true;
    _txt->BackColor = Theme::Card2;
    _txt->ForeColor = Theme::Text;
    _txt->BorderStyle = BorderStyle::FixedSingle;
    _txt->Location = Drawing::Point(16, 38);
    _txt->Width = 480;
    _txt->Height = 56;
    _txt->Font = Ui::F(9.5f, false);
    _txt->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
    _composer->Controls->Add(_txt);
    Button^ postBtn = Ui::AccentBtn("Đăng", 90, 34);
    postBtn->Location = Drawing::Point(16, 104);
    postBtn->Click += gcnew EventHandler(this, &FeedView::OnPost);
    _composer->Controls->Add(postBtn);

    Button^ attachBtn = Ui::GhostBtn("📷  Đính kèm ảnh", 130, 34);
    attachBtn->Location = Drawing::Point(116, 104);
    attachBtn->Click += gcnew EventHandler(this, &FeedView::OnAttach);
    _composer->Controls->Add(attachBtn);

    _imgPrev = gcnew FlowLayoutPanel();
    _imgPrev->FlowDirection = FlowDirection::LeftToRight;
    _imgPrev->WrapContents = false;
    _imgPrev->BackColor = Theme::Card;
    _imgPrev->AutoScroll = true;
    _imgPrev->Location = Drawing::Point(16, 150);
    _imgPrev->Size = Drawing::Size(520, 56);
    _imgPrev->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
    _composer->Controls->Add(_imgPrev);
}

void FeedView::OnAttach(Object^ s, EventArgs^)
{
    OpenFileDialog^ dlg = gcnew OpenFileDialog();
    dlg->Multiselect = true;
    dlg->Filter = "Hình ảnh|*.png;*.jpg;*.jpeg;*.gif;*.webp;*.bmp|Tất cả|*.*";
    if (dlg->ShowDialog(this) != DialogResult::OK) return;
    String^ dir = Path::Combine(Store::DataDir(), "imgs");
    Directory::CreateDirectory(dir);
    for each (String^ f in dlg->FileNames)
    {
        try
        {
            String^ ext = Path::GetExtension(f);
            String^ name = Utils::NewToken()->Substring(0, 12) + ext;
            String^ dst = Path::Combine(dir, name);
            File::Copy(f, dst, true);
            _attach->Add(dst);
            AddPreview(dst);
        }
        catch (Exception^) { }
    }
}

void FeedView::AddPreview(String^ path)
{
    PictureBox^ pb = gcnew PictureBox();
    pb->Size = Drawing::Size(52, 52);
    pb->SizeMode = PictureBoxSizeMode::Zoom;
    pb->BackColor = Theme::Card2;
    pb->Cursor = Cursors::Hand;
    pb->Tag = path;
    pb->Click += gcnew EventHandler(this, &FeedView::OnRemoveImg);
    _imgPrev->Controls->Add(pb);
    Img::LoadAsync(pb, path, 160, 160);
    _composer->Height = 216;
}

void FeedView::OnRemoveImg(Object^ s, EventArgs^)
{
    PictureBox^ pb = (PictureBox^)s;
    String^ path = (String^)pb->Tag;
    _attach->Remove(path);
    _imgPrev->Controls->Remove(pb);
    pb->Dispose();
    if (_attach->Count == 0) _composer->Height = 150;
}

void FeedView::OnPost(Object^ s, EventArgs^)
{
    String^ t = Utils::Clean(_txt->Text, 3000);
    if (t == "" && _attach->Count == 0) { Toast::Show("Nội dung trống", false); return; }
    long long nid = 0;
    Store::AddPost(t, _attach, false, nid);
    _txt->Text = "";
    _attach->Clear();
    _imgPrev->Controls->Clear();
    _composer->Height = 150;
    AppCtx::Win->RefreshTopbar();
    Toast::Show("Đã đăng bài! 🎉", true);
    RefreshList();
}

// ===================== modes =====================
void FeedView::ShowFeed()
{
    _saved = false;
    _modeLbl->Text = "Bảng tin";
    _composer->Visible = true;
    Bus::H = gcnew Action<String^, Object^>(this, &FeedView::OnAction);
    RefreshList();
}

void FeedView::ShowSaved()
{
    _saved = true;
    _modeLbl->Text = "Bài viết đã lưu";
    _composer->Visible = false;
    Bus::H = gcnew Action<String^, Object^>(this, &FeedView::OnAction);
    RefreshList();
}

void FeedView::RefreshView()
{
    Bus::H = gcnew Action<String^, Object^>(this, &FeedView::OnAction);
    if (_saved) { _modeLbl->Text = "Bài viết đã lưu"; _composer->Visible = false; }
    else { _modeLbl->Text = "Bảng tin"; _composer->Visible = true; }
    RefreshList();
}

void FeedView::RefreshList()
{
    RebuildCards();
}

void FeedView::RebuildCards()
{
    _list->Controls->Clear();
    ArrayList^ src = _saved ? Store::SavedPosts() : Store::Posts();
    // copy + sort newest first
    ArrayList^ posts = gcnew ArrayList();
    int take = Math::Min(src->Count, 2000);
    for (int i = 0; i < take; i++) posts->Add(src[i]);
    for (int i = 0; i < posts->Count; i++)
        for (int j = i + 1; j < posts->Count; j++)
        {
            Dictionary<String^, Object^>^ a = dynamic_cast<Dictionary<String^, Object^>^>(posts[i]);
            Dictionary<String^, Object^>^ b = dynamic_cast<Dictionary<String^, Object^>^>(posts[j]);
            if (a != nullptr && b != nullptr && J::N(b, "x") > J::N(a, "x"))
            {
                posts[i] = b; posts[j] = a;
            }
        }
    int y = 8;
    for (int i = 0; i < posts->Count; i++)
    {
        Dictionary<String^, Object^>^ p = dynamic_cast<Dictionary<String^, Object^>^>(posts[i]);
        if (p == nullptr) continue;
        PostCard^ c = gcnew PostCard();
        c->Set(p);
        if (_cmtOpen->Contains(J::N(p, "i"))) c->SetCmtOpen(true);
        c->Location = Drawing::Point(8, y);
        _list->Controls->Add(c);
        y += c->Height + 10;
    }
    _list->Height = y + 8;
    SetWidths();
}

void FeedView::SetWidths()
{
    int w = Math::Max(320, this->ClientSize.Width - 24);
    _list->Width = w;
    for each (Control^ c in _list->Controls)
    {
        PostCard^ pc = dynamic_cast<PostCard^>(c);
        if (pc != nullptr) pc->SetWidth(w - 16);
    }
}

void FeedView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    SetWidths();
}

void FeedView::AddCard(Dictionary<String^, Object^>^ p)
{
    PostCard^ c = gcnew PostCard();
    c->Set(p);
    _list->Controls->Add(c);
}

// ===================== action bus =====================
void FeedView::OnAction(String^ action, Object^ arg)
{
    if (action->StartsWith("react:"))
    {
        long long pid = Convert::ToInt64(action->Substring(6));
        String^ emo = (String^)arg;
        Store::ToggleReact(pid, emo);
        AppCtx::Win->RefreshTopbar();
        RefreshList();
    }
    else if (action == "save")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        Store::ToggleSave(pid);
        RefreshList();
    }
    else if (action == "del")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        if (!Ui::Confirm("Xóa bài viết này?")) return;
        Store::DeletePost(pid);
        RefreshList();
    }
    else if (action == "edit")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        Dictionary<String^, Object^>^ p = Store::PostById(pid);
        if (p == nullptr) return;
        String^ nt = Ui::Prompt("Sửa bài viết", "Nội dung:", J::S(p, "t"));
        if (nt == nullptr) return;
        nt = Utils::Clean(nt, 3000);
        if (nt == "") return;
        Store::EditPost(pid, nt);
        RefreshList();
    }
    else if (action == "cmt")
    {
        long long pid = (long long)Convert::ToInt64(arg);
        if (_cmtOpen->Contains(pid)) _cmtOpen->Remove(pid);
        else _cmtOpen->Add(pid);
        RefreshList();
    }
    else if (action->StartsWith("cmtadd:"))
    {
        long long pid = Convert::ToInt64(action->Substring(7));
        String^ t = (String^)arg;
        long long cid = 0;
        Store::AddComment(pid, t, cid);
        AppCtx::Win->RefreshTopbar();
        RefreshList();
    }
    else if (action->StartsWith("cmtdel:"))
    {
        long long pid = Convert::ToInt64(action->Substring(7));
        long long cid = (long long)Convert::ToInt64(arg);
        Store::DeleteComment(pid, cid);
        RefreshList();
    }
    else if (action == "prof")
    {
        AppCtx::Nav("profile", arg);
    }
}
