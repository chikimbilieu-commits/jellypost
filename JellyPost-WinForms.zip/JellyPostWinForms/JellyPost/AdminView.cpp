#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "AdminView.h"

AdminView::AdminView()
{
    this->BackColor = Theme::Bg;
    _padd = 24;
    _q = "";
    _wrap = gcnew Panel();
    _wrap->Dock = DockStyle::Fill;
    _wrap->BackColor = Theme::Bg;
    _wrap->AutoScroll = true;
    this->Controls->Add(_wrap);
    _page = gcnew Panel();
    _page->BackColor = Theme::Bg;
    _wrap->Controls->Add(_page);
}

void AdminView::OnResize(EventArgs^ e)
{
    UserControl::OnResize(e);
    _page->Width = Math::Max(400, this->ClientSize.Width - 28);
}

void AdminView::OnSearch(Object^ s, EventArgs^)
{
    _q = Utils::NormVn(_search->Text);
    Rebuild();
}

void AdminView::RefreshView()
{
    Rebuild();
}

void AdminView::Rebuild()
{
    _page->Controls->Clear();
    _page->Width = Math::Max(400, this->ClientSize.Width - 28);
    int cw = _page->Width - 2 * _padd;
    int y = 12;

    Label^ t0 = Ui::Lbl("🛠️  Bảng điều khiển quản trị", 13.0f, true, Theme::Text);
    t0->Location = Drawing::Point(_padd, y); _page->Controls->Add(t0); y += 34;

    // toggles
    Panel^ tg = gcnew Panel();
    tg->BackColor = Theme::Card;
    tg->Location = Drawing::Point(_padd, y);
    tg->Width = cw;
    tg->Height = 104;
    _page->Controls->Add(tg);
    int ty = 12;
    Label^ t1 = Ui::Lbl("Công tắc hệ thống", 10.5f, true, Theme::Text);
    t1->Location = Drawing::Point(14, ty); tg->Controls->Add(t1); ty += 30;
    Button^ bEv = Ui::Btn(Store::EventEnabled() ? "✅  Cửa hàng Gems: ĐANG MỞ" : "⛔  Cửa hàng Gems: ĐÓNG", 220, 32,
        Store::EventEnabled() ? Theme::Green : Theme::Danger, Color::White, true);
    bEv->Tag = "ev"; bEv->Click += gcnew EventHandler(this, &AdminView::OnToggle);
    bEv->Location = Drawing::Point(14, ty); tg->Controls->Add(bEv);
    Button^ bDr = Ui::Btn(Store::DrawEnabled() ? "✅  Rút thăm: ĐANG MỞ" : "⛔  Rút thăm: ĐÓNG", 220, 32,
        Store::DrawEnabled() ? Theme::Green : Theme::Danger, Color::White, true);
    bDr->Tag = "dr"; bDr->Click += gcnew EventHandler(this, &AdminView::OnToggle);
    bDr->Location = Drawing::Point(244, ty); tg->Controls->Add(bDr);
    Button^ bMc = Ui::Btn(Store::McEnabled() ? "✅  Sự kiện Trung Thu: ĐANG MỞ" : "⛔  Sự kiện Trung Thu: ĐÓNG", 220, 32,
        Store::McEnabled() ? Theme::Green : Theme::Danger, Color::White, true);
    bMc->Tag = "mc"; bMc->Click += gcnew EventHandler(this, &AdminView::OnToggle);
    bMc->Location = Drawing::Point(474, ty); tg->Controls->Add(bMc);
    y += tg->Height + 12;

    // user search
    _search = gcnew TextBox();
    _search->BackColor = Theme::Card2;
    _search->ForeColor = Theme::Text;
    _search->BorderStyle = BorderStyle::FixedSingle;
    _search->Location = Drawing::Point(_padd, y);
    _search->Width = 260;
    _search->Height = 28;
    _search->TextChanged += gcnew EventHandler(this, &AdminView::OnSearch);
    _page->Controls->Add(_search);
    y += 38;

    // users
    Dictionary<String^, Object^>^ users = Store::Users();
    List<String^>^ names = gcnew List<String^>();
    for each (KeyValuePair<String^, Object^> kv in users) names->Add(kv.Key);
    names->Sort();
    for (int i = 0; i < names->Count; i++)
    {
        String^ u = names[i];
        Dictionary<String^, Object^>^ usr = Store::User(u);
        if (usr == nullptr) continue;
        if (_q != "" && Utils::NormVn(u)->IndexOf(_q) < 0 && Utils::NormVn(J::S(usr, "d"))->IndexOf(_q) < 0) continue;
        bool banned = J::B(usr, "k");

        Panel^ row = gcnew Panel();
        row->BackColor = Theme::Card;
        row->Location = Drawing::Point(_padd, y);
        row->Width = cw;
        row->Height = 46;
        _page->Controls->Add(row);

        Label^ name = Ui::Lbl(J::S(usr, "d") + "  @" + u + (banned ? "  🚫" : ""), 9.5f, true, banned ? Theme::Danger : Theme::Text);
        name->Location = Drawing::Point(12, 12);
        row->Controls->Add(name);
        Label^ gems = Ui::Lbl("💎 " + Ui::Fmt(Store::Gems(u)), 9.0f, false, Theme::Muted);
        gems->Location = Drawing::Point(300, 12);
        row->Controls->Add(gems);
        Label^ mc = Ui::Lbl("🥮 " + Ui::Fmt(Store::McBalance(u)), 9.0f, false, Theme::Muted);
        mc->Location = Drawing::Point(380, 12);
        row->Controls->Add(mc);

        int bx = cw - 240;
        Button^ g100 = Ui::Btn("+100 💎", 64, 26, Theme::Card2, Theme::Accent, true);
        g100->FlatAppearance->BorderSize = 1;
        g100->FlatAppearance->BorderColor = Theme::Border;
        g100->Tag = "g100:" + u; g100->Click += gcnew EventHandler(this, &AdminView::OnUserBtn);
        g100->Location = Drawing::Point(bx, 10); row->Controls->Add(g100); bx += 70;
        Button^ g1000 = Ui::Btn("+1000 💎", 70, 26, Theme::Card2, Theme::Accent, true);
        g1000->FlatAppearance->BorderSize = 1;
        g1000->FlatAppearance->BorderColor = Theme::Border;
        g1000->Tag = "g1000:" + u; g1000->Click += gcnew EventHandler(this, &AdminView::OnUserBtn);
        g1000->Location = Drawing::Point(bx, 10); row->Controls->Add(g1000); bx += 76;
        if (u != Store::Me && !J::B(usr, "m"))
        {
            Button^ ban = Ui::Btn(banned ? "Gỡ cấm" : "Cấm", 62, 26, banned ? Theme::Green : Theme::Danger,
                Color::White, true);
            ban->Tag = (banned ? "unban:" : "ban:") + u; ban->Click += gcnew EventHandler(this, &AdminView::OnUserBtn);
            ban->Location = Drawing::Point(bx, 10); row->Controls->Add(ban);
        }
        y += 52;
    }

    // items
    y += 8;
    Label^ t2 = Ui::Lbl("Sản phẩm Cửa hàng Gems", 10.5f, true, Theme::Text);
    t2->Location = Drawing::Point(_padd, y); _page->Controls->Add(t2); y += 30;
    for each (ShopItem^ it in Catalog::Items)
    {
        Dictionary<String^, Object^>^ evIt = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::EvItems(), it->Id));
        bool on = it->On;
        if (evIt != nullptr && J::H(evIt, "on")) on = J::B(evIt, "on");
        int cost = it->Cost;
        if (evIt != nullptr && J::H(evIt, "cost")) cost = (int)J::N(evIt, "cost");

        Panel^ row = gcnew Panel();
        row->BackColor = Theme::Card;
        row->Location = Drawing::Point(_padd, y);
        row->Width = cw;
        row->Height = 40;
        _page->Controls->Add(row);

        Label^ name = Ui::Lbl(it->Emo + "  " + it->Name + "  (" + Ui::Str(cost) + " 💎)", 9.0f, true, Theme::Text);
        name->Location = Drawing::Point(12, 10);
        row->Controls->Add(name);

        Button^ tog = Ui::Btn(on ? "Đang bán" : "Ngừng bán", 90, 26, on ? Theme::Green : Theme::Card2,
            on ? Color::White : Theme::Muted, true);
        tog->FlatAppearance->BorderSize = 1;
        tog->FlatAppearance->BorderColor = Theme::Border;
        tog->Tag = "it:" + it->Id; tog->Click += gcnew EventHandler(this, &AdminView::OnItemBtn);
        tog->Location = Drawing::Point(cw - 200, 7); row->Controls->Add(tog);
        Button^ price = Ui::Btn("💲 Giá", 56, 26, Theme::Card2, Theme::Accent, true);
        price->FlatAppearance->BorderSize = 1;
        price->FlatAppearance->BorderColor = Theme::Border;
        price->Tag = "cost:" + it->Id; price->Click += gcnew EventHandler(this, &AdminView::OnItemCost);
        price->Location = Drawing::Point(cw - 100, 7); row->Controls->Add(price);
        y += 46;
    }

    _page->Height = y + 12;
}

void AdminView::OnToggle(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ k = (String^)b->Tag;
    if (k == "ev") Store::ToggleEvent(!Store::EventEnabled());
    else if (k == "dr") Store::ToggleDraw(!Store::DrawEnabled());
    else if (k == "mc") Store::ToggleMc(!Store::McEnabled());
    Toast::Show("Đã cập nhật công tắc", true);
    AppCtx::Win->RefreshAll();
}

void AdminView::OnUserBtn(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ v = (String^)b->Tag;
    int colon = v->IndexOf(':');
    String^ op = v->Substring(0, colon);
    String^ u = v->Substring(colon + 1);
    if (op == "ban") { if (Ui::Confirm("Cấm tài khoản @" + u + "?")) { Store::SetBanned(u, true); if (u == Store::Me) { Store::ClearSession(); Application::Restart(); } } }
    else if (op == "unban") Store::SetBanned(u, false);
    else if (op == "g100") Store::AddGems(u, 100);
    else if (op == "g1000") Store::AddGems(u, 1000);
    Toast::Show("Đã cập nhật", true);
    Rebuild();
}

void AdminView::OnItemBtn(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ id = ((String^)b->Tag)->Substring(3);
    ShopItem^ it = Catalog::FindItem(id);
    Dictionary<String^, Object^>^ evIt = dynamic_cast<Dictionary<String^, Object^>^>(J::G(Store::EvItems(), id));
    bool on = it == nullptr ? true : it->On;
    if (evIt != nullptr && J::H(evIt, "on")) on = J::B(evIt, "on");
    Store::SetItemOn(id, !on);
    Rebuild();
}

void AdminView::OnItemCost(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    String^ id = ((String^)b->Tag)->Substring(5);
    ShopItem^ it = Catalog::FindItem(id);
    String^ v = Ui::Prompt("Đổi giá", "Giá mới (Gems):", it->Cost.ToString());
    if (v == nullptr) return;
    int cost = 0;
    if (!Int32::TryParse(v, cost) || cost < 1) { Ui::Warn("Giá không hợp lệ"); return; }
    Store::SetItemCost(id, cost);
    Rebuild();
}
