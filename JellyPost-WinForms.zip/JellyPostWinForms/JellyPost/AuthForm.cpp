#include "pch.h"
#include "Core.h"
#include "Store.h"
#include "AuthForm.h"

AuthForm::AuthForm()
{
    this->Text = "Jelly Post — Đăng nhập";
    this->FormBorderStyle = FormBorderStyle::FixedDialog;
    this->MaximizeBox = false;
    this->MinimizeBox = false;
    this->StartPosition = FormStartPosition::CenterScreen;
    this->ClientSize = Drawing::Size(420, 560);
    this->BackColor = Theme::Bg;
    this->ForeColor = Theme::Text;
    this->Font = Ui::F(9.5f, false);
    this->ShowInTaskbar = false;
    _av = 0;
    _selAv = nullptr;
    Build();
}

void AuthForm::StyleField(TextBox^ tb)
{
    tb->BackColor = Theme::Card2;
    tb->ForeColor = Theme::Text;
    tb->BorderStyle = BorderStyle::FixedSingle;
    tb->Font = Ui::F(10.0f, false);
    tb->Height = 32;
    tb->TabStop = true;
}

void AuthForm::Build()
{
    // brand
    Label^ logo = Ui::Lbl("Jelly Post 💜", 22.0f, true, Theme::Accent);
    logo->AutoSize = true;
    logo->Location = Drawing::Point(30, 22);
    this->Controls->Add(logo);

    Label^ sub = Ui::Lbl("Mạng xã hội cho Windows", 10.0f, false, Theme::Muted);
    sub->AutoSize = true;
    sub->Location = Drawing::Point(32, 56);
    this->Controls->Add(sub);

    // tabs
    _loginTab = Ui::Btn("Đăng nhập", 170, 38, Theme::Accent, Color::White, true);
    _regTab = Ui::Btn("Đăng ký", 170, 38, Theme::Card2, Theme::Text, false);
    _loginTab->Location = Drawing::Point(20, 92);
    _regTab->Location = Drawing::Point(190, 92);
    _loginTab->FlatAppearance->BorderSize = 0;
    _regTab->FlatAppearance->BorderSize = 1;
    _regTab->FlatAppearance->BorderColor = Theme::Border;
    _loginTab->Click += gcnew EventHandler(this, &AuthForm::OnEnter);
    _regTab->Click += gcnew EventHandler(this, &AuthForm::OnExit);
    this->Controls->Add(_loginTab);
    this->Controls->Add(_regTab);

    _body = gcnew Panel();
    _body->Location = Drawing::Point(20, 140);
    _body->Size = Drawing::Size(380, 400);
    _body->BackColor = Theme::Bg;
    this->Controls->Add(_body);

    // ----- login fields -----
    _user = gcnew TextBox();
    _pass = gcnew TextBox();
    StyleField(_user);
    StyleField(_pass);
    _pass->UseSystemPasswordChar = true;

    Button^ loginBtn = Ui::AccentBtn("Đăng nhập", 180, 40);
    loginBtn->Click += gcnew EventHandler(this, &AuthForm::DoLogin);

    Label^ hint = Ui::Lbl("Quản trị viên mặc định: jellypost / jellypost", 8.5f, false, Theme::Muted);

    // ----- register fields -----
    _ru = gcnew TextBox();
    _rp1 = gcnew TextBox();
    _rp2 = gcnew TextBox();
    _rd = gcnew TextBox();
    StyleField(_ru); StyleField(_rp1); StyleField(_rp2); StyleField(_rd);
    _rp1->UseSystemPasswordChar = true;
    _rp2->UseSystemPasswordChar = true;

    _avGrid = gcnew FlowLayoutPanel();
    _avGrid->FlowDirection = FlowDirection::LeftToRight;
    _avGrid->WrapContents = true;
    _avGrid->AutoScroll = true;
    _avGrid->BackColor = Theme::Bg;
    _avGrid->Size = Drawing::Size(380, 130);

    Button^ regBtn = Ui::AccentBtn("Tạo tài khoản", 180, 40);
    regBtn->Click += gcnew EventHandler(this, &AuthForm::DoRegister);

    // register container (hidden by default)
    Panel^ regP = gcnew Panel();
    regP->BackColor = Theme::Bg;
    regP->Dock = DockStyle::Fill;
    regP->Tag = "regP";
    _body->Controls->Add(regP);

    // ----- login layout -----
    Panel^ loginP = gcnew Panel();
    loginP->BackColor = Theme::Bg;
    loginP->Dock = DockStyle::Fill;
    loginP->Tag = "loginP";
    _body->Controls->Add(loginP);

    int y = 6;
    Label^ l1 = Ui::Lbl("Tên đăng nhập", 9.5f, true, Theme::Text);
    l1->Location = Drawing::Point(0, y); loginP->Controls->Add(l1); y += 22;
    _user->Location = Drawing::Point(0, y); _user->Width = 360; loginP->Controls->Add(_user); y += 46;
    Label^ l2 = Ui::Lbl("Mật khẩu", 9.5f, true, Theme::Text);
    l2->Location = Drawing::Point(0, y); loginP->Controls->Add(l2); y += 22;
    _pass->Location = Drawing::Point(0, y); _pass->Width = 360; loginP->Controls->Add(_pass); y += 52;
    loginBtn->Location = Drawing::Point(0, y); loginBtn->Width = 360; loginP->Controls->Add(loginBtn); y += 52;
    hint->Location = Drawing::Point(0, y); loginP->Controls->Add(hint);

    // ----- register layout -----
    y = 6;
    Label^ rr1 = Ui::Lbl("Tên đăng nhập (a-z, 0-9, _ .)", 8.5f, true, Theme::Text);
    rr1->Location = Drawing::Point(0, y); regP->Controls->Add(rr1); y += 20;
    _ru->Location = Drawing::Point(0, y); _ru->Width = 360; regP->Controls->Add(_ru); y += 44;
    Label^ rr2 = Ui::Lbl("Tên hiển thị", 8.5f, true, Theme::Text);
    rr2->Location = Drawing::Point(0, y); regP->Controls->Add(rr2); y += 20;
    _rd->Location = Drawing::Point(0, y); _rd->Width = 360; regP->Controls->Add(_rd); y += 44;
    Label^ rr3 = Ui::Lbl("Mật khẩu (4-64 ký tự)", 8.5f, true, Theme::Text);
    rr3->Location = Drawing::Point(0, y); regP->Controls->Add(rr3); y += 20;
    _rp1->Location = Drawing::Point(0, y); _rp1->Width = 360; regP->Controls->Add(_rp1); y += 44;
    Label^ rr4 = Ui::Lbl("Nhập lại mật khẩu", 8.5f, true, Theme::Text);
    rr4->Location = Drawing::Point(0, y); regP->Controls->Add(rr4); y += 20;
    _rp2->Location = Drawing::Point(0, y); _rp2->Width = 360; regP->Controls->Add(_rp2); y += 48;
    Label^ rr5 = Ui::Lbl("Chọn ảnh đại diện", 8.5f, true, Theme::Text);
    rr5->Location = Drawing::Point(0, y); regP->Controls->Add(rr5); y += 20;
    _avGrid->Location = Drawing::Point(0, y); regP->Controls->Add(_avGrid); y += 138;
    regBtn->Location = Drawing::Point(0, y); regBtn->Width = 360; regP->Controls->Add(regBtn);

    FillAvatars();

    ShowTab(true);
    _pass->KeyDown += gcnew KeyEventHandler(this, &AuthForm::OnKey);
    _rp2->KeyDown += gcnew KeyEventHandler(this, &AuthForm::OnKey);
    this->AcceptButton = loginBtn;
}

void AuthForm::OnKey(Object^ s, KeyEventArgs^ e)
{
    if (e->KeyCode == Keys::Enter)
    {
        if (_loginTab->BackColor == Theme::Accent) DoLogin();
        else DoRegister();
    }
}

void AuthForm::FillAvatars()
{
    for (int i = 0; i < Catalog::AvEmoji->Length; i++)
    {
        Button^ b = Ui::Btn(Catalog::AvEmoji[i], 44, 44, Theme::Card2, Theme::Text, false);
        b->Font = gcnew Font("Segoe UI Emoji", 16.0f, FontStyle::Regular, GraphicsUnit::Pixel);
        b->Tag = i;
        b->FlatAppearance->BorderSize = 1;
        b->FlatAppearance->BorderColor = Theme::Border;
        b->Click += gcnew EventHandler(this, &AuthForm::OnAvatar);
        _avGrid->Controls->Add(b);
    }
    SelectAvatar(0);
}

void AuthForm::OnAvatar(Object^ s, EventArgs^)
{
    Button^ b = (Button^)s;
    SelectAvatar((int)b->Tag);
}

void AuthForm::SelectAvatar(int idx)
{
    _av = idx;
    if (_selAv != nullptr) { _selAv->BackColor = Theme::Card2; _selAv->FlatAppearance->BorderColor = Theme::Border; }
    _selAv = (Button^)_avGrid->Controls[idx];
    _selAv->BackColor = Theme::AccentSoft;
    _selAv->FlatAppearance->BorderColor = Theme::Accent;
    _selAv->FlatAppearance->BorderSize = 2;
}

void AuthForm::OnEnter(Object^ s, EventArgs^)
{
    ShowTab(true);
}
void AuthForm::OnExit(Object^ s, EventArgs^)
{
    ShowTab(false);
}

void AuthForm::ShowTab(bool login)
{
    _loginTab->BackColor = login ? Theme::Accent : Theme::Card2;
    _loginTab->ForeColor = login ? Color::White : Theme::Text;
    _regTab->BackColor = login ? Theme::Card2 : Theme::Accent;
    _regTab->ForeColor = login ? Theme::Text : Color::White;
    for each (Control^ c in _body->Controls)
    {
        String^ tag = c->Tag == nullptr ? "" : c->Tag->ToString();
        if (tag == "regP") c->Visible = !login;
        else c->Visible = login;
    }
}

void AuthForm::DoLogin()
{
    String^ u = Utils::Clean(_user->Text, 20);
    String^ pw = _pass->Text;
    if (u == "" || pw == "") { Ui::Warn("Vui lòng nhập tên đăng nhập và mật khẩu"); return; }
    String^ err = "";
    if (Store::Login(u, pw, err) == nullptr) { Ui::Warn(err); return; }
    this->DialogResult = DialogResult::OK;
    this->Close();
}

void AuthForm::DoRegister()
{
    String^ u = Utils::Clean(_ru->Text, 20)->ToLowerInvariant();
    String^ d = Utils::Clean(_rd->Text, 30);
    String^ p1 = _rp1->Text;
    String^ p2 = _rp2->Text;
    if (u == "") { Ui::Warn("Vui lòng nhập tên đăng nhập"); return; }
    if (d == "") { Ui::Warn("Vui lòng nhập tên hiển thị"); return; }
    if (p1 != p2) { Ui::Warn("Mật khẩu nhập lại không khớp"); return; }
    String^ err = "";
    if (Store::Register(u, p1, d, _av, err) == nullptr) { Ui::Warn(err); return; }
    this->DialogResult = DialogResult::OK;
    this->Close();
}
