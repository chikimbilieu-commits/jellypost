#include "pch.h"

using namespace System;
using namespace System::Reflection;
using namespace System::Runtime::CompilerServices;
using namespace System::Runtime::InteropServices;
using namespace System::Security::Permissions;

[assembly:AssemblyTitleAttribute(L"JellyPost")];
[assembly:AssemblyDescriptionAttribute(L"Jelly Post — Mạng xã hội (bản WinForms cho Windows)")];
[assembly:AssemblyConfigurationAttribute(L"")];
[assembly:AssemblyCompanyAttribute(L"Jelly Post")];
[assembly:AssemblyProductAttribute(L"JellyPost")];
[assembly:AssemblyCopyrightAttribute(L"Copyright (c) 2026")];
[assembly:AssemblyTrademarkAttribute(L"")];
[assembly:AssemblyCultureAttribute(L"")];

[assembly:ComVisible(false)];
[assembly:GuidAttribute("3B8A9E1C-5D4F-4A7B-9C2E-6F1A8D0B4E3C")];
[assembly:AssemblyVersionAttribute("1.0.0.0")];
[assembly:AssemblyFileVersionAttribute("1.0.0.0")];
