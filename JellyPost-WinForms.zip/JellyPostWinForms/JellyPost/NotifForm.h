#pragma once
#include "pch.h"

public ref class NotifForm : public Form
{
public:
    NotifForm();
private:
    void Build();
    void OnOpen(Object^ s, EventArgs^ e);
    void OnClear(Object^ s, EventArgs^ e);
    void ClearAll();

    Panel^ _list;
    Label^ _badge;
};
