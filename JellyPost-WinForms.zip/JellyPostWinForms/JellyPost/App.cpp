#include "pch.h"
#include "Store.h"
#include "AuthForm.h"
#include "MainForm.h"
#include "Core.h"

using namespace System::Windows::Forms;

[STAThreadAttribute]
int main(array<String^>^ args)
{
    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);

    Store::Load();

    if (!Store::HasSession())
    {
        AuthForm^ af = gcnew AuthForm();
        if (af->ShowDialog() != System::Windows::Forms::DialogResult::OK) return 0;
    }

    MainForm^ mf = gcnew MainForm();
    AppCtx::Win = mf;
    Application::Run(mf);
    return 0;
}
