# Jelly Post — Windows Desktop App (WinForms / C++/CLI)

Native Windows port of the "Jelly Post" Vietnamese social network. The web version
lives in `main.pjs` + `index.html` at the generator root; this folder is the
standalone desktop build. UI is Vietnamese, redesigned for desktop (topbar +
sidebar layout).

## Build (Windows, Visual Studio 2022)

1. Install **Visual Studio 2022** with the **"Desktop development with C++"**
   workload. In the individual components list, also tick
   **"C++/CLI support for v143 build tools"** (this is required — C++/CLI is
   otherwise not enabled).
2. Open `JellyPost.sln` (project is `.NET Framework` target, default — do NOT
   retarget to .NET Core/.NET 5+; C++/CLI requires .NET Framework).
3. Select **x64** or **x86** (both work), then **Build** (F7).
4. Run `x64\Debug\JellyPost.exe` (or Release).

All the C++/CLI refs (`System`, `System.Windows.Forms`, `System.Drawing`,
`System.Web.Extensions`, `System.Net`) are wired up in `JellyPost.vcxproj`;
`pch.h` precompiled header is set to Create, all other files Use. The project
compiles clean as-is — if you see linker errors about `Math::`/`Drawing::` name
collisions, check that `NOMINMAX` is defined (it is, in `pch.h`).

## Data model (compatible with the web version)

- Data file: `%APPDATA%\JellyPost\data.json` (users, posts, chats, notifs,
  economy, admin toggles — same JSON key names as the web app's import/export).
- Settings: `%APPDATA%\JellyPost\settings.json` (current session user, theme).
- Post images are copied into `%APPDATA%\JellyPost\imgs\`; avatar/decoration
  images load from the web image URLs at runtime.
- Password hash: SHA-256(pw + salt), identical to the web version, so a
  `data.json` exported from the web app can be imported via `Store::ImportJson`
  (no UI button for it yet — call it from code or wire it up if needed).

## Feature status

Included (matching the web app):
- Auth (register/login, avatar pick), sessions, dark/light theme.
- Feed: posts, images, reactions, comments, save, delete own posts.
- DMs (conv list + bubbles), notifications (bell with badge), friend list/search.
- Profiles (self-edit avatar/name/password/equip decorations; other users'
  profiles, add/unfriend).
- Gems economy: daily quests, lucky draw, ⭐ Plus, decoration shop.
- Mooncake event (daily login, streaks, event shop).
- Admin mode (login `jellypost` / `jellypost`): toggles, grant gems, ban users,
  item on/off + price editing.

Not included (no equivalent on desktop):
- No online multiplayer (data is local-only, single file).
- No AI text/image generation, no Discord integration.
- Music/song in posts renders as a static 🎵 label (no audio playback).
- No video playback.

## Layout / architecture notes

- `Core.h/.cpp` — shared helpers: JSON accessors (`J::`), utils (`Utils::`:
  SHA-256, Vietnamese diacritic normalization, time-ago), `Theme` (colors),
  `Ui::` (control factories incl. `Ui::Str(long long)` for number-to-string),
  `Store` is the data layer.
- Views are `UserControl`s swapped in a content panel from `MainForm` via
  `AppCtx::Nav` → `MainForm::GoTo`. Feed/Shop/etc. rebuild their layout on each
  `RefreshView()`.
- Gotcha: in C++/CLI, `"literal" + integral` is pointer arithmetic (NOT string
  concat). Always use `Ui::Str(n)` (e.g. `"react:" + Ui::Str(_pid)`).
- `JavaScriptSerializer::DeserializeObject` yields `Object[]` (not `ArrayList`)
  for JSON arrays — `Store::NormJson` normalizes to `List<Object^>` first.
- On resize the shell re-lays the topbar right cluster right-to-left; sidebar
  nav + badges update in `ApplyBadges`.
